//
//  AddressBookAuthorizer.h
//  DrComputerITAddressBookWrapper
//
//  Created by Alberto De Luca on 05/12/12.
//  Copyright (c) 2012 Alberto De Luca. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AddressBook/AddressBook.h>

@interface AddressBookAuthorizer : NSObject

+(void)iOS6AddressBookAuthorizer:(ABAddressBookRef)ab;

@end
