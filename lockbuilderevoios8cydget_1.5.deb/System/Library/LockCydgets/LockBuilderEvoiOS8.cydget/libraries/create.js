function create() {
    var shape, color, name, size, height;
    shape = prompt('Type c for circle or s for square', '');
    color = "white";
    name = prompt('Short Name', '');
    if (shape === "c" || shape === "C") {
        size = prompt('Width of Circle', '');
        size = size + "px";
        height = size;
        start(shape, color, name, size, height);
    }
    if (shape === "s" || shape === "S") {
        size = prompt('Width of Square', '');
        size = size + "px";
        height = prompt('height of Square', '');
        start(shape, color, name, size, height);
    }
    closemenu();
}

function start(shape, color, name, size, height) {
    var saved, objcreate, sprepared, divst, itemst, ast, lits, linkFunctionts, ulst;
    objcreate = {};
    saved = localStorage.getItem('createdobjcreate');
    if (saved !== null) {
        objcreate = {};
        objcreate = JSON.parse(saved);
    }
    objcreate[name] = shape + ',' + color + ',' + name + ',' + size + ',' + height;
    sprepared = JSON.stringify(objcreate);
    localStorage.setItem('createdobjcreate', sprepared);
    divst = document.createElement("div");
    divst.style.width = size;
    divst.style.height = height;
    divst.style.background = color;
    if (shape === "c" || shape === "C") {
        divst.style.borderRadius = size;
        divst.style.position = "absolute";
        divst.style.top = "100px";
    }
    if (shape === "s" || shape === "S") {
        divst.style.position = "absolute";
        divst.style.top = "100px";
    }
    divst.className = "createditem";
    divst.id = name;
    itemst = document.getElementById('iwidgetcontainer');
    itemst.appendChild(divst);
    
    isLocked=localStorage.getItem('locked');
    if(isLocked!=null){}
    else{
     $('#' + name).touch();
    }
    
    ast = document.createElement("a");
    ast.id = "menu"+name;
    ast.appendChild(document.createTextNode(name));
    lits = document.createElement("li");
    lits.appendChild(ast);
    linkFunctionts = "set('" + name + "')";
    lits.setAttribute('onClick', linkFunctionts);
    ulst = document.getElementById("weathermenu");
    ulst.insertBefore(lits, document.getElementById("close"));
}

function set(el) {
    var hiddn = $('#' + el).css('display');
    if (hiddn === "block") {
        $('#' + el).css('display', 'none');
        $('#menu' + el).css('color', 'white');
    } else {
        $('#' + el).css('display', 'block');
        $('#menu' + el).css('color', 'grey');
    }
    saveweatherdisplay(el);
}

function getvalues(key, nvalue) {
    var kofs, c, n, s, h;
    nvalue = nvalue.split(',');
    kofs = nvalue[0];
    c = nvalue[1];
    n = nvalue[2];
    s = nvalue[3];
    h = nvalue[4];
    start(kofs, c, n, s, h);
}

var savedcreations, objsavedcreate;
savedcreations = localStorage.getItem('createdobjcreate');
if (savedcreations !== null) {
    objsavedcreate = JSON.parse(savedcreations);
    $.each(objsavedcreate, function (key, value) {
        getvalues(key, value);
    });
}



function deleteitem() {
    var curelsv, newsavesv;
    curelsv = localStorage.getItem('curel');
    $('#' + curelsv).remove();
    $('#menu' + curelsv).remove();
    delete objsavedcreate[curelsv];
    newsavesv = JSON.stringify(objsavedcreate);
    localStorage.setItem('createdobjcreate', newsavesv);
    closehelper();
}

