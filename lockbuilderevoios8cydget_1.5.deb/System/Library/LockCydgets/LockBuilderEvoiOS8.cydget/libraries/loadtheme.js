var themematrix = "matrix(1, 0, 0, 1, 0, 0)";
var thememenu = 0;
var endloop;

function getthemecounts(thememenu,allthemes){
    var count1 = 0;
    var count2 = 12
    var ctarray=[]
    if(thememenu == 1){
        count1 = 0;
        count2 = 12
        if (allthemes[count2] == undefined) {endloop = "yes";thememenu = 0;}
        else{endloop="no";thememenu=thememenu;}
    }
    else if(thememenu == 2){
        count1 = 12;
        count2 = 24
        if (allthemes[count2] == undefined) {endloop = "yes";thememenu = 0;}
        else{endloop="no";thememenu=thememenu;}
    }
    else {
        thememenus = thememenu-1;
        var count1 = count1 + 12 * thememenus;
        var count2 = count2 + 12 * thememenus;
         if (allthemes[count2] == undefined) {endloop = "yes";thememenu = 0;}
         else{endloop="no";thememenu=thememenu}
    }
  ctarray=[Number(count1),Number(count2),endloop,thememenu];
  return ctarray;
}

function getthemecountspass(thememenu,allthemes){
    var count1 = 0;
    var count2 = 4
    var ctarray=[]
    if(thememenu == 1){
        count1 = 0;
        count2 = 4
        if (allthemes[count2] == undefined) {endloop = "yes";thememenu = 0;}
        else{endloop="no";thememenu=thememenu;}
    }
    else if(thememenu == 2){
        count1 = 8;
        count2 = 12
        if (allthemes[count2] == undefined) {endloop = "yes";thememenu = 0;}
        else{endloop="no";thememenu=thememenu;}
    }
    else {
        thememenus = thememenu-1;
        var count1 = count1 + 4 * thememenus;
        var count2 = count2 + 4 * thememenus;
         if (allthemes[count2] == undefined) {endloop = "yes";thememenu = 0;}
         else{endloop="no";thememenu=thememenu}
    }
  ctarray=[Number(count1),Number(count2),endloop,thememenu];
  return ctarray;
}

function createbuttons(count2,endloop,thememenu){
maindiv = document.getElementById('loadthemes');
if (count2 >= 12) {
    nextdiv = document.createElement("button");
    nextdiv.setAttribute('onclick', 'loadtheme()');
    if (endloop == "yes") {
        nextdiv.innerHTML = "Home";
        var prev=0;
        nextdiv.setAttribute('onclick', 'loadtheme('+prev+')');
    } else {
        nextdiv.innerHTML = "Next";
    }
    nextdiv.setAttribute(
        "style", "position:relative;z-index:20000000; border-radius:2px;width:150px; height:20px; margin-left:160px; margin-top:-20px; text-align:center; opacity:0.2;");
    nextdiv.id = "next";
    maindiv.appendChild(nextdiv);


    prevdiv = document.createElement("button");
    if (thememenu == 1) {} else {
        prevdiv.setAttribute('onclick', 'loadtheme(prev)');
    }

    prevdiv.setAttribute(
        "style", "position:relative;z-index:20000000; border-radius:2px; width:150px; height:20px; margin-left:5px; margin-top:-20px; text-align:center; opacity:0.2;");
    prevdiv.id = "prev";
    if (endloop == "yes") {
        prevdiv.innerHTML = "Prev";
    } else {
        if (thememenu == 1) { //if themes are on the first page hide the prev button.
            prevdiv.style.opacity = "0";
        } else {
            prevdiv.innerHTML = "Prev";
        }
    }
    maindiv.appendChild(prevdiv);
} else {}
}

function createpassbuttons(count2,endloop,thememenu){
    maindiv = document.getElementById('loadthemes');
    if (count2 >= 4) {
        nextdiv = document.createElement("button");
        if (endloop == "yes") {
            nextdiv.innerHTML = "Home";
            var prev=0;
            nextdiv.setAttribute('onclick', 'loadtheme('+prev+')');
        } else {
            nextdiv.innerHTML = "Next";
            nextdiv.setAttribute('onclick', 'loadtheme()');
        }
        nextdiv.setAttribute(
            "style", "position:relative;z-index:20000000; border-radius:2px;width:150px; height:20px; margin-left:160px; margin-top:-20px; text-align:center; opacity:0.2;");
        nextdiv.id = "next";
        maindiv.appendChild(nextdiv);
        prevdiv = document.createElement("button");
        if (thememenu == 1) {} else {
            prevdiv.setAttribute('onclick', 'loadtheme(prev)');
        }
        prevdiv.setAttribute(
            "style", "position:relative;z-index:20000000; border-radius:2px; width:150px; height:20px; margin-left:5px; margin-top:-20px; text-align:center; opacity:0.2;");
        prevdiv.id = "prev";
        if (endloop == "yes") {
            prevdiv.innerHTML = "Prev";
            thememenu = 0;
        } else {
            if (thememenu == 1) { //if themes are on the first page hide the prev button.
                prevdiv.style.opacity = "0";
            } else {
                prevdiv.innerHTML = "Prev";
            }
        }
        maindiv.appendChild(prevdiv);
    } else {}
}

function loadtheme(prev) {
    if(prev==0){
        thememenu=0;
    }
    $('.themes').remove();
    $('#next').remove();
    $('#prev').remove();
    var passcode=isPasscodeon();
    var allthemes = readplist('/var/mobile/Library/LBEvoThemes/');
    var themelength = allthemes.length;
    var fragment = document.createDocumentFragment();

    if (prev) {
        if (thememenu == 0) {
            thememenu++
        } else {
            thememenu--
        }
    } else {
        thememenu++
    }

    
    if(passcode){
        //var counts = getthemecountspass(thememenu,allthemes);
         var counts = getthemecounts(thememenu,allthemes); //loading all themes instead of 4.
    }
    else{
        var counts = getthemecounts(thememenu,allthemes);

    }

    var count1 = counts[0];
    var count2 = counts[1];
    var endloop = counts[2];

    //$('#loadthemes').touch();
    var fileroot, themeplist, ELBG, img, classname, divmkr, ids, thisname, maindiv;
    getEL('loadthemes').style.webkitTransform = themematrix;

    for (var i = count1; i < count2; i++) {
        ids = allthemes[i];
        try {
            themeplist = getthemebg(allthemes[i]);
            if (themeplist != null) {
                ElBG = themeplist;
                img = ElBG;
            }
        } catch (err) {
            alert("LBThemes" + err);
        }
        if (allthemes[i] == undefined) {} else {
            classname = "themes";
            divmkr = document.createElement('div');
            divmkr.id = "themes" + [i];
            ids = ids.slice('0', '-6');
                $(divmkr).addClass(classname).html('</br><img id="loadimg" class="needsclick" width="60" src="' + img + '" />' + ids).click(function() {
                thisname = this.textContent;
                thisname = thisname.replace(/ /g, '');
                thisname = thisname + ".plist";
                loading(thisname);
                $(".themes").remove();
            });
            fragment.appendChild(divmkr);
        }

    }
    closemenu();
    $('#themes').css('display', 'block');
    maindiv = document.getElementById('loadthemes');
    maindiv.appendChild(fragment);
    hidetm();
    blurbackground();

    if(passcode){
        createpassbuttons(count2,endloop,thememenu);
    }
    else{
        createbuttons(count2,endloop,thememenu);
    }


}

function loadpickedtheme(theme, name) {
    localStorage.setItem('curtheme',name);
    var themeplist = theme;
    try {
        var main = themeplist.MainElements;
        if (main == undefined || main == "null") {
            localStorage.removeItem('dragOBJ');
        } else {
            localStorage.setItem("dragOBJ", main);
        }

        var weathersave = themeplist.WeatherWallsave;
        if (weathersave == "yes") {
            localStorage.setItem('weatherwalls', weathersave);
            getBase64FromImageUrl("images/wallpaperinst.jpg");
            //window.location = window.location.href;
        } else {
            localStorage.removeItem('weatherwalls');
            //window.location = window.location.href;
        }

        var elLocked = themeplist.ElementsLocked;
        if (elLocked == "null") {
            localStorage.removeItem('locked');
        } else if (elLocked == undefined) {
            var isLocked;
            isLocked = loadLocal('locked');
            if (isLocked !== null) {
            localStorage.removeItem('locked');
            //$('#body').addClass('scaleup');
            } else {
            saveLocal('locked', 'yes');
            //$('#body').addClass('scale');

            }
        } else {
            localStorage.setItem("locked", elLocked);
        }

        var smstxtsv = themeplist.Smssv;
        if (smstxtsv == "null") {
            smstxtsv = " ";
        }
        localStorage.setItem("smstext", smstxtsv);

        var Ecapssv = themeplist.ElementCaps;
        if (Ecapssv == "null") {
            Ecapssv = " ";
        }
        localStorage.setItem("capsOBJ", Ecapssv);

        var Anisv = themeplist.Animation;
        if (Anisv == "null") {
            
            localStorage.removeItem('animations');
    localStorage.removeItem('hiddenbg');
    getEL('background').style.visibility="visible";
        } else {
            localStorage.setItem("animations", Anisv);
        }


        var mailtxtsv = themeplist.Mailsv;
        if (mailtxtsv == "null") {
            mailtxtsv = " ";
        }
        localStorage.setItem("mailtext", mailtxtsv);

        var phonetxtsv = themeplist.Phonesv;
        if (phonetxtsv == "null") {
            phonetxtsv = " ";
        }
        localStorage.setItem("phonetext", phonetxtsv);

        var twittertxtsv = themeplist.Twittersv;
        if (twittertxtsv == "null") {
            twittertxtsv = " ";
        }
        localStorage.setItem("twittertext", twittertxtsv);

        var tweetbottxtsv = themeplist.Tweetbotsv;
        if (tweetbottxtsv == "null") {
            tweetbottxtsv = " ";
        }
        localStorage.setItem("tweetbottext", tweetbottxtsv);

        var whatsapptxtsv = themeplist.Whatsappsv;
        if (whatsapptxtsv == "null") {
            whatsapptxtsv = " ";
        }
        localStorage.setItem("whatsapptext", whatsapptxtsv);

        var hideel = themeplist.HideElements;
        if (hideel == undefined || hideel == "null") {
            localStorage.removeItem('hideOBJ');
        } else {
            localStorage.setItem("hideOBJ", hideel);
        }

        var Iconimg = themeplist.IconImages;
        if (Iconimg == undefined || Iconimg == "null") {
            localStorage.removeItem('iconimgOBJ');
        } else {
            localStorage.setItem("iconimgOBJ", Iconimg);
        }

        var IconsList = themeplist.IconList;
        if (IconsList == undefined || IconsList == "null") {
            localStorage.removeItem('iconOBJ');
        } else {
            localStorage.setItem("iconOBJ", IconsList);
        }

        var ElColors = themeplist.ElementColors;
        if (ElColors == undefined || ElColors == "null") {
            localStorage.removeItem('colorOBJ');
        } else {
            localStorage.setItem("colorOBJ", ElColors);
        }

        var ElFonts = themeplist.ElementFonts;
        if (ElFonts == undefined || ElFonts == "null") {
            localStorage.removeItem('fontOBJ');
        } else {
            localStorage.setItem("fontOBJ", ElFonts);
        }

        var ElOpacity = themeplist.ElementOpacity;
        if (ElOpacity == undefined || ElOpacity == "null") {
            localStorage.removeItem('opacityOB');
        } else {
            localStorage.setItem("opacityOB", ElOpacity);
        }

        var ElScale = themeplist.ElementScale;
        if (ElScale == undefined || ElScale == "null") {
            localStorage.removeItem('scaleOBJ');
        } else {
            localStorage.setItem("scaleOBJ", ElScale);
        }


        var Shadow = themeplist.ElementShadow;
        if (Shadow == undefined || Shadow == "null") {
            localStorage.removeItem('shadowOBJ');
        } else {
            localStorage.setItem("shadowOBJ", Shadow);
        }

        var LsGL = themeplist.Lockscreen;
        if (LsGL == undefined || LsGL == "null") {
            localStorage.removeItem('lockscreenchosen');
        } else {
            localStorage.setItem("lockscreenchosen", LsGL);
        }

        var CIcon = themeplist.CustomIcon;
        if (CIcon == undefined || CIcon == "null") {
            localStorage.removeItem('newiconimgOBJ');
        } else {
            localStorage.setItem("newiconimgOBJ", CIcon);
        }

        var CWIcon = themeplist.CustomWeatherIcon;
        if (CWIcon == undefined || CWIcon == "null") {
            localStorage.removeItem('iconset');
        } else {
            localStorage.setItem("iconset", CWIcon);
        }

        var LsiW = themeplist.SelectediWidget;
        if (LsiW == undefined || LsiW == "null") {
            localStorage.removeItem('objiwidgets');
        } else {
            localStorage.setItem("objiwidgets", LsiW);
        }

        var Citem = themeplist.CreatedItem;
        if (Citem == undefined || Citem == "null") {
            localStorage.removeItem('createdobjcreate');
        } else {
            localStorage.setItem("createdobjcreate", Citem);
        }

        var WOver = themeplist.WallOverlay;
        if (WOver == undefined || WOver == "null") {
            localStorage.removeItem('overlay');
        } else {
            localStorage.setItem("overlay", WOver);
        }

        var Elalign = themeplist.ElementAlign;
        if (Elalign == undefined || Elalign == "null") {
            localStorage.removeItem('alignOB');
        } else {
            localStorage.setItem("alignOB", Elalign);
        }
       // $('#body').addClass('scale');

        var ElBG = themeplist.Background; //only sets wall for menu blurs
        if (ElBG == undefined || ElBG == "null") {
            localStorage.removeItem('userbg');
        } else {

            localStorage.setItem('userbg', ElBG);
        }
      
      setLSWall(ElBG); //change lockscreen wallpaper
      themeplist=null;
      freememory();
    } catch (err) {
        alert("Themes Loading Error: " + err);
    }

swal({
    title: "Respring",
    text: "Changing multiple themes uses ram, it is good to respring. If you press no, the theme will still load.",
    type: "warning",
    showCancelButton: true,
    confirmButtonColor: "#DD6B55",
    confirmButtonText: "Yes, respring now!",
    cancelButtonText: "No, i'll respring later.",
    closeOnConfirm: false,
    closeOnCancel: false
}, function(isConfirm) {
    if (isConfirm) {
        respringdevice();
    } else {
        window.location = window.location.href;
    }
});

}
function openicon() {
    closehelper();
    $('#filemenus').touch();
    blurbackground();
    $('#moveicondir').css('display', 'block');
    var allfiles = readplist('/Library/Themes/');
    for (var i = 0; i < allfiles.length; i++) {
        ids = allfiles[i];
        classname = "menu1";
        d = document.createElement('div');
        $(d).addClass(classname).html("" + ids).appendTo($('#filemenus')) //append result to menu
            .click(function() {
                thisname = this.innerHTML;
                openmenu2(thisname)
            });
    }
}

function openmenu2(file) {
    $("#filemenus2").touch();
    $('.menu1').css('display', 'none');
    var allfiles = readplist('/Library/Themes/' + file);
    for (var i = 0; i < allfiles.length; i++) {
        ids = allfiles[i];
        classname = "menu2";
        d = document.createElement('div');
        $(d).addClass(classname).html("" + ids).appendTo($('#filemenus2'))
            .click(function() {
                thisname = this.innerHTML;
                openmenu3(file, thisname)
            });
    }
}

function openmenu3(file, nextfile) {
    $("#filemenus3").touch();
    $('.menu2').css('display', 'none');
    var allfiles = readplist('/Library/Themes/' + file + "/" + nextfile);
    for (var i = 0; i < allfiles.length; i++) {
        ids = allfiles[i];
        classname = "menu3";
        d = document.createElement('div');
        $(d).addClass(classname).html("" + ids).appendTo($('#filemenus3'))
            .click(function() {
                thisname = this.innerHTML;
                openmenu4(file, nextfile, thisname)
            });
    }
}

function openmenu4(file, nextfile, name) {
    $("#filemenus4").touch();
    $('.menu3').css('display', 'none');
    var allfiles = readplist('/Library/Themes/' + file + "/" + nextfile + "/" + name);
    for (var i = 0; i < allfiles.length; i++) {
        ids = allfiles[i];
        img = "/Library/Themes/" + file + "/" + nextfile + "/" + name + "/" + ids;
        classname = "menu4";
        d = document.createElement('div');
        $(d).addClass(classname).html('</br><img width="60" src="' + img + '" />' + ids).appendTo($('#filemenus4'))
            .click(function() {
                thisname = this.textContent;
                thisname = thisname.replace(/ /g, '');
                unblurbackground();
                openmenu5(file, nextfile, name, thisname);
            });
    }
}

function openmenu5(file, nextfile, name, thisname) {
    imgsrc = "/Library/Themes/" + file + "/" + nextfile + "/" + name + "/" + thisname;
    var curel = localStorage.getItem('curicon');
    $('#b' + curel + ' .iconimages').attr('src', imgsrc);
    $('.menu4').css('display', 'none');
    $('#moveicondir').css('display', 'none');
    newiconimgOBJ(curel, imgsrc);
}