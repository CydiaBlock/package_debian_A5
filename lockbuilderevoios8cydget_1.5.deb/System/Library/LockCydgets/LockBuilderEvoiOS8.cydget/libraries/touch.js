var newcount = "0";
(function ($, TweenLite) {
    "use strict";
    var defaults = {
        draggable: true,
        rotatable: true,
        scalable: true,
        tween: {
            use: false,
            speed: 1,
            ease: ''
        },
        touchClass: 'touching'
    };
    var props = $.event.props || [];
    props.push("touches");
    props.push("scale");
    props.push("rotation");
    $.event.props = props;

    $.fn.getMatrix = function (i) {
        if (this.css('transform') === 'none') return 0;
        var array = this.css('transform').split('(')[1].split(')')[0].split(',');

        //document.getElementById('output').innerHTML=array;
        return array[i] || array;
    };

    function Touch(elem, options) {
        this.elem = elem;
        this.$elem = $(elem);
        this.options = $.extend({}, defaults, options);
        //detect support for Webkit CSS 3d transforms
        this.supportsWebkit3dTransform = ('WebKitCSSMatrix' in window && 'm11' in new WebKitCSSMatrix());
        this.init();
    }

    //static property to store the zIndex for an element
    Touch.zIndexCount = 100;

    Touch.prototype.init = function () {
        //if rotated use that rotation
        this.rotation = 0;
        this.scale = 1.0; //default scale value
        this.gesture = true; //flags a 2 touch gesture
        this.$elem.on('touchstart', this.touchstart.bind(this));
    };

    Touch.prototype.touchstart = function (e) {

        e.preventDefault();
        //starttouch();
        starttimer(this.elem.id);
        if (this.elem.id == "moveicondir") {} else {
            localStorage.setItem('curel', this.elem.id);
        }
        //bring item to the front dont bring line to the front
        var createditem = $("#" + this.elem.id).hasClass("createditem");
            
        if (this.elem.id=="premenu"||this.elem.id=="weathermenu") {

        }
        
        else if(createditem===true){

        }
        else if(this.elem.id=='weathericonsmenu'){
        }
         else {
            this.elem.style.zIndex = Touch.zIndexCount++;
        }

        this.$elem.on('touchmove.touch', this.touchmove.bind(this));
        this.$elem.on('touchend.touch touchcancel.touch', this.touchend.bind(this));


/////////////////
        if (this.elem.id == "loadthemes"||this.elem.id=="animations"||this.elem.id=="movemenu"||this.elem.id=="iwidget"||this.elem.id=="iconlist"||this.elem.id=="overlays"||this.elem.id=="lockscreens"||this.elem.id=="filemenus"||this.elem.id == "filemenus2"||this.elem.id == "filemenus3"||this.elem.id == "filemenus4"||this.elem.id=="fontmenuone"){
            
        }
        else if(this.elem.id == "premenu"||this.elem.id=="weathermenu"||this.elem.id=="weathericonsmenu"){}
           //this else if(this.elem.id=='weathericonsmenu'){}
                else if(this.elem.id == 'dpad'){}
        

        else{
            
         if (this.options.touchClass) {
            this.$elem.addClass(this.options.touchClass);
        }
    }
        this.start0X = this.$elem.getMatrix(4) - e.touches[0].pageX;

        
        if (this.elem.id == "iwidgetscrollbar") {
            this.start0X = -260;
        }
        if (this.elem.id == "themes") {
            this.start0X = -260;
        }
        
        if (this.elem.id == "movelocksmenu") {
            curX = 0;
        }
        if (this.elem.id == "moveicondir") {
            curX = 0;
        }

        

        this.start0Y = this.$elem.getMatrix(5) - e.touches[0].pageY;
        
        if (e.touches.length < 2) return;
        this.start1X = this.$elem.getMatrix(4) - e.touches[1].pageX;
        this.start1Y = this.$elem.getMatrix(5) - e.touches[1].pageY;
    };

    Touch.prototype.touchmove = function (e) {
        var node, transformed;
        dragging = true;
        endtimer();
        var defaultrotation = localStorage.getItem(this.elem.id + 'defaultrotation');
        if (defaultrotation !== null) {
            this.rotation = defaultrotation;
        } else {
            this.rotation = 0;
        }
        var widgetornot = $("#" + this.elem.id).hasClass("widget");
        if (widgetornot === true) {
            node = $("#" + this.elem.id)[0];
            transformed = new WebKitCSSMatrix(window.getComputedStyle(node).webkitTransform);
            this.scale = transformed.d;
        }
        else if(this.elem.id==="forecast"){
            node = $("#" + this.elem.id)[0];
            transformed = new WebKitCSSMatrix(window.getComputedStyle(node).webkitTransform);
            this.scale = transformed.d;
        }

        e.preventDefault();
        var typeTransform;
        var elementName;
        var myTransform = "",
            x1 = 0,
            y1 = 0,
            x2 = 0,
            y2 = 0,
            curX = 0,
            curY = 0;
        //drag event
        if (e.touches.length === 1) {
            //get drag point
            curX = this.start0X + e.touches[0].pageX;
            //if (this.elem.id == "scrollbar") {
              //  curX = 0;
            //}
            if (this.elem.id == "loadthemes") {
                curX = 0;
            }
            if (this.elem.id == "animations") {
                curX = 0;
            }
            if (this.elem.id == "overlays") {
                curX = 0;
            }
            if (this.elem.id == "filemenus"||this.elem.id == "filemenus2"||this.elem.id == "filemenus3"||this.elem.id == "filemenus4") {
                curX = 0;
            }
            if (this.elem.id == "lockscreens") {
                curX = 0;
            }
            if (this.elem.id == "fontmenuone") {
                curX = 0;
            }
            if (this.elem.id == "iconlist") {
                curX = 0;
            }
            if (this.elem.id == "premenu") {
                curX = 0;
            }
            if (this.elem.id == "iwidget") {
                curX = 0;
            }

            if (this.elem.id == "weathermenu") {
                curX = 0;
            }
            if (this.elem.id == "iwidgetscrollbar") {
                curX = 0;
            }
            if (this.elem.id == "themes") {
                curX = 0;
            }
            if (this.elem.id == "movemenu") {
                curX = 0;
            }
            if (this.elem.id == "movelocksmenu") {
                curX = 0;
            }
            if (this.elem.id == "moveicondir") {
                curX = 0;
            }
            curY = this.start0Y + e.touches[0].pageY;

            if (this.elem.id == "moveicondir") {
                curX = 0;
            }

            if (this.elem.id == "weathericonsmenu") {
                curX = 0;
            }

            //translate drag
            if (this.options.draggable) {
                myTransform += 'translate3d(' + curX + 'px,' + curY + 'px, 0)';
                if (this.elem.id == "themes") {
                    $('#loadthemes').css('top', curY + "px");
                }
                

                
                if (this.elem.id == "movelocksmenu") {
                    $('.lockscreen').css('top', curY + "px");
                    $('.overlays').css('top', curY + "px");

                }
                if (this.elem.id == "moveicondir") {
                    $('.menu1').css('top', curY + "px");
                    $('.menu2').css('top', curY + "px");
                    $('.menu3').css('top', curY + "px");
                    $('.menu4').css('top', curY + "px");

                }

                if (this.elem.id == "weathericonsmenu") {
                    //$('#weathericonsmenu').css('top', curY + "px");
                }

                if (this.elem.id == "iwidgetscrollbar") {
                    $('.iwidget').css('top', curY + "px");
                }


                typeTransform = "drag";
                elementName = this.elem.id;
                if (this.elem.id == "moveicondir") {} else {
                    localStorage.setItem('curel', elementName);
                }
                record(typeTransform, elementName, myTransform);
            }

            //persist scale and rotate values from previous gesture
            if (this.options.scalable) {
                myTransform += "scale(" + (this.scale) + ")";
            }

            if (this.options.rotatable) {
                myTransform += "rotate(" + ((this.rotation) % 360) + "deg)";
            }
        } else if (e.touches.length === 2) {

            //gesture event
            this.gesture = true;

            //get middle point between two touches for drag
            x1 = this.start0X + e.touches[0].pageX;
            y1 = this.start0Y + e.touches[0].pageY;
            x2 = this.start1X + e.touches[1].pageX;
            y2 = this.start1Y + e.touches[1].pageY;
            curX = (x1 + x2) / 2, curY = (y1 + y2) / 2;

            //translate drag
            if (this.options.draggable) {
                if (this.supportsWebkit3dTransform) {
                    myTransform += 'translate3d(' + curX + 'px,' + curY + 'px, 0)';
                } else {
                    myTransform += 'translate(' + curX + 'px,' + curY + 'px)';
                }

                //if (this.elem.id == "scrollbar") {
                  //  myTransform += 'translate3d( 0px,' + curY + 'px, 0)';
                //}
            }

            //scale and rotate
            if (this.options.scalable) {
                myTransform += "scale(" + (this.scale) + ")";
            }

            if (this.options.rotatable) {
                myTransform += "rotate(" + ((this.rotation) % 360) + "deg)";

            }
        }

        if (this.options.tween.use) {
            TweenLite.to(this.elem, this.options.tween.speed, {
                css: {
                    transform: myTransform
                },
                ease: this.options.tween.ease
            });
        } else {
            this.elem.style.webkitTransform = this.elem.style.MozTransform = this.elem.style.msTransform = this.elem.style.OTransform = this.elem.style.transform = myTransform;
        }
    };

    Touch.prototype.touchend = function (e) {
        canceltimer();
        e.preventDefault();
        endtimer();
        //endtouch();
        this.$elem.off('.touch');
        //store scale and rotate values on gesture end
        if (this.gesture) {
            this.scale *= e.scale;
            this.rotation = (this.rotation) % 360;
            this.gesture = false;
        }

        if (this.options.touchClass) {
            this.$elem.removeClass(this.options.touchClass);
        }
        var curel = localStorage.getItem('curel');
        var curelpos = $('#' + curel).css('-webkit-transform');
        var type = "drag";
        record(type, curel, curelpos);
        if (dragging === false) { //if weather icon is pressed open weather
            if (curel == "icon") {
                openweather();
            }

            if (curel == "unlock") {
                unlockphone();
            }
            if (curel == "speak") {
                speaknow();
            }

            if (curel == "warning") {
                newcount+=1; //count is called before touch function at the top
                if (newcount == "1") { // if press once send parameter to the function
                    showdata('yes');
                } else {
                    showdata();
                    newcount = "0";
                } //otherwise don't
            }
        }
        dragging = false;
    };

    function record(type, name, myTransform) {
        if (name == "moveicondir"||name == "iwidget"||name == "dpad"||name == "premenu"||name == "overlays"||name == "weathermenu"||name == "filemenus"||name == "filemenus2"||name == "filemenus3"||name == "filemenus4"||name == "weathericonsmenu"||name=="fontmenuone"||name=="iconlist"||name=="premenu"||name=="weathermenu") {} else {
            dragobj(name, myTransform);
        }
    }
    // plugin wrapper
    $.fn.touch = function (options) {
        return this.each(function () {
            if (!$.data(this, "plugin_touch")) {
                $.data(this, 'plugin_touch', new Touch(this, options));
            }
        });
    };
}(jQuery, window.TweenLite));