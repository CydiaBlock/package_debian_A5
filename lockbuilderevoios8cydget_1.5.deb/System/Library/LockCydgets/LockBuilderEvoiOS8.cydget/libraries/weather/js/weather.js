// http://JunesiPhone.com

var imgcolor="white";

localStorage.setItem('apiCelsius',sUnit);
localStorage.setItem('api24hr',TwentyFourHourClock);
localStorage.setItem('apikph',kph);

var neighborhood=localStorage.getItem('neighborhood');
var street=localStorage.getItem('street');
var addr=localStorage.getItem('addr');
var county=localStorage.getItem('county');

document.getElementById('nhood').innerHTML = neighborhood;
document.getElementById('street').innerHTML = street;
document.getElementById('addr').innerHTML = addr;
document.getElementById('county').innerHTML = county;

if(gpstime==15){
  var refresh=900000;
}
if(gpstime==30){
  var refresh=1800000;
}
if(gpstime==45){
  var refresh=2700000;
}
if(gpstime==1){
  var refresh=3600000;
}
if(gpstime==2){
  var refresh=7200000;
}
if(gpstime=="manual"){
  var refresh=604800000;
}

//var language = window.navigator.language;

function Showdata(){
  showdata(); //showdata is not a constructor and shouldn't be capitolized. This is a fix while not breaking everthing.
}


function showdata(warning2) { //passing warning from touch.js
 // alert("loading");
var  tod, warning, icon, currentIcon, newimage;
var imageextention=".png";
var degrees="&deg;";

var dailyinfo=json.DailyForecasts; // daily forecast
var hourlyinfo=json.HourlyForecasts; // hourly forecast
var narrativeinfo=json.NarrativeForecasts; // Narrative forecast
var raininfo=json.WhenWillItRain;
var sunriseset=json.SunRiseSet;
var hirad=json.HiradObservation;

sunrise=JSON.stringify(sunriseset[0].rise);
sunset=JSON.stringify(sunriseset[0].set);
sunrise = sunrise.replace(/"/g, "");
sunset = sunset.replace(/"/g, "");

// convert sunrise from UNIX time
var timestamp1 = sunrise;
  UX2 = new Date(timestamp1 * 1000);
    hours = (UX2.getHours() < 10 ? '0' + UX2.getHours() : UX2.getHours());
    minutes = (UX2.getMinutes() < 10 ? '0' + UX2.getMinutes() : UX2.getMinutes());
    seconds = (UX2.getSeconds() < 10 ? '0' + UX2.getSeconds() : UX2.getSeconds());
    sunrise = hours + ':' + minutes;

if(TwentyFourHourClock=="true"){
  hours = hours % 12;
    if(hours === 0){hours += 12;}
    sunrise = hours + ':' + minutes;
}


// convert sunset from UNIX time
var timestamp = sunset;
  UX1 = new Date(timestamp * 1000);
    hours = (UX1.getHours() < 10 ? '0' + UX1.getHours() : UX1.getHours());
    minutes = (UX1.getMinutes() < 10 ? '0' + UX1.getMinutes() : UX1.getMinutes());
    seconds = (UX1.getSeconds() < 10 ? '0' + UX1.getSeconds() : UX1.getSeconds());
    sunset = hours + ':' + minutes;

if(TwentyFourHourClock=="true"){
  hours = hours % 12;
    if(hours === 0){hours += 12;}
    sunset = hours + ':' + minutes;
}

daily=JSON.stringify(dailyinfo[0]);
hourly=JSON.stringify(hourlyinfo[0]);
narrative=JSON.stringify(narrativeinfo[0].dayPart);


if(daily.day===undefined){
  tod=dailyinfo[0].night;
}
else{
  tod=dailyinfo[0].day;
}




var daysize="40"; //set forecast image size
 //what folder to pull from

////////////////////////////////////////////////////////////////////////////////////
var hiToday=JSON.stringify(+dailyinfo[0].maxTemp+degrees); //Today hi
hiToday = hiToday.replace(/"/g, "");
if(hiToday=="NaN"+degrees){hiToday=json.StandardObservation.temp+degrees;}      //If afternoon show NA
document.getElementById("hi").innerHTML = '<span>' + (hiToday) + '</span>';


//////////////////////////////////////////////////////////////////////////////////
var loToday=JSON.stringify(""+dailyinfo[0].minTemp+degrees); //Today lo
loToday = loToday.replace(/"/g, "");
document.getElementById("low").innerHTML = '<span>' + (loToday) + '</span>';

//////////////////////////////////////////////////////////////////////////////////
var descToday=JSON.stringify(tod.phrase); //Today weather description
descToday = descToday.replace(/"/g, "");
if(descToday==""){var descToday=JSON.stringify(dailyinfo[0].night.phrase)}
descToday = descToday.replace(/"/g, "");


document.getElementById("later").innerHTML = '<span>' + ( textstringlater + descToday) + '</span>';

//////////////////////////////////////////////////////////////////////////////////
var tempNow=JSON.stringify(hourlyinfo[0].temp+degrees); //Current Temp
tempNow = tempNow.replace(/"/g, "");
//document.getElementById("TempNow").innerHTML = '<span>' + ('' + tempNow) + '</span>'

// New
document.getElementById("temp").innerHTML = '<span>' + ('' + json.StandardObservation.temp+degrees) + '</span>';

if(sUnit=="s"){
  tUnits="F";
}
else{tUnits="C";}
document.getElementById("tempFC").innerHTML = '<span>' + ('' + json.StandardObservation.temp+degrees+tUnits) + '</span>';

//document.getElementById("TempNow").innerHTML = '<span>' + ('' + hirad.feelsLike) + '</span>'


function feeldiv(tmp){
realFeel = tmp.replace(/"/g, "");
document.getElementById("feeltemp").innerHTML = '<span>' + (feeltxt + realFeel) + '</span>';
}

try{
var realFeel=JSON.stringify(hourlyinfo[0].feelsLike+degrees); //Current Temp
feeldiv(realFeel);
}
catch(err){
  var realFeel=hirad.feelsLike;
  feeldiv(realFeel);
}


//////////////////////////////////////////////////////////////////////////////////
var Humidity=JSON.stringify("Humidity:"+hourlyinfo[0].humid); //Humidity
Humidity = Humidity.replace(/"/g, "");
document.getElementById("humidity").innerHTML = '<span>' + ('' + Humidity) + '</span>';


//////////////////////////////////////////////////////////////////////////////////
var WindSpeed=JSON.stringify(""+hourlyinfo[0].wSpeed); //Wind Speed
WindSpeed = WindSpeed.replace(/"/g, "");
document.getElementById("windsp").innerHTML = '<span>' + (''+WindSpeed+" Mph") + '</span>';



if(kph=="yes"){
conversion = 1.609344;
kph = WindSpeed * conversion;
kph = Math.round(kph * 100) / 100;
kph = Math.round(kph);
document.getElementById("windsp").innerHTML = '<span>' + ('' + kph+" Kph") + '</span>';

}




//////////////////////////////////////////////////////////////////////////////////
var WindDirection=JSON.stringify(hourlyinfo[0].wDirText); //Wind Direction
WindDirection = WindDirection.replace(/"/g, "");

//arrow=document.getElementById('windcompass');

 //setTimeout(function () {animatecompass();}, 1500);



function animatecompass(){
if(WindDirection=="ENE"){arrow.classList.remove('on');arrow.className = arrow.className + " ene";}
if(WindDirection=="ESE"){arrow.classList.remove('on');arrow.className = arrow.className + " ese";}
if(WindDirection=="NE"){arrow.classList.remove('on');arrow.className = arrow.className + " ne";}
if(WindDirection=="NNE"){arrow.classList.remove('on');arrow.className = arrow.className + " nne";}
if(WindDirection=="NNW"){arrow.classList.remove('on');arrow.className = arrow.className + " nnw";}
if(WindDirection=="NW"){arrow.classList.remove('on');arrow.className = arrow.className + " nw";}
if(WindDirection=="SE"){arrow.classList.remove('on');arrow.className = arrow.className + " se";}
if(WindDirection=="SSE"){arrow.classList.remove('on');arrow.className = arrow.className + " sse";}
if(WindDirection=="SSW"){arrow.classList.remove('on');arrow.className = arrow.className + " ssw";}
if(WindDirection=="SW"){arrow.classList.remove('on');arrow.className = arrow.className + " sw";}
if(WindDirection=="WNW"){arrow.classList.remove('on');arrow.className = arrow.className + " wnw";}
if(WindDirection=="WSW"){arrow.classList.remove('on');arrow.className = arrow.className + " wsw";}
}

document.getElementById("windir").innerHTML = '<span>' + ('' + WindDirection) + '</span>';

//////////////////////////////////////////////////////////////////////////////////
var UV=JSON.stringify("UV:"+hourlyinfo[0].uv); //UV
UV = UV.replace(/"/g, "");
document.getElementById("uv").innerHTML = '<span>' + ('' + UV) + '</span>';

//////////////////////////////////////////////////////////////////////////////////
var dew=JSON.stringify(""+hourlyinfo[0].dew+"&#176"); //dew

dew = dew.replace(/"/g, "");
document.getElementById("dew").innerHTML = '<span>' + ('Dew: ' + dew) + '</span>';

//////////////////////////////////////////////////////////////////////////////////
var City=JSON.stringify(json.Location.city); //City
City = City.replace(/"/g, "");
document.getElementById("city").innerHTML = '<span>' + ('' + City) + '</span>';





var State=JSON.stringify(json.Location.state);
State = State.replace(/"/g, "");
document.getElementById("state").innerHTML = '<span>' + ('' + State) + '</span>';

var Statename=JSON.stringify(json.Location.stateName);
Statename = Statename.replace(/"/g, "");
document.getElementById("statenm").innerHTML = '<span>' + ('' + Statename) + '</span>';

var Country=JSON.stringify(json.Location.country);
Country = Country.replace(/"/g, "");
document.getElementById("country").innerHTML = '<span>' + ('' + Country) + '</span>';

var Elevation=JSON.stringify(json.Location.elv);
Elevation = Elevation.replace(/"/g, "");
Elevation = elevationtxt+Elevation;
document.getElementById("elevation").innerHTML = '<span>' + ('' + Elevation) + '</span>';

var Lat=JSON.stringify(json.Location.lat);


Lat = Lat.replace(/"/g, "");


//Lat =Lat.slice(0, -4);
Lat = Number(Lat);
Lat = +Lat.toFixed(2);
document.getElementById("lat").innerHTML = '<span>' + ('Lat: ' + Lat) + '</span>';

var Long=JSON.stringify(json.Location.lng);
Long = Long.replace(/"/g, "");

//Long =Long.slice(0, -4);
Long = Number(Long);
Long = +Long.toFixed(2);
document.getElementById("long").innerHTML = '<span>' + ('Long: ' + Long) + '</span>';



try{
  document.getElementById("condition").innerHTML = '<span>' + (json.HiradObservation.text) + '</span>';
}
catch(err){
  document.getElementById("condition").innerHTML = '<span>' + (json.StandardObservation.text) + '</span>';
}

try{
  document.getElementById("rainfall").innerHTML = '<span>' + (preciptxt+json.HiradObservation.precipHourly+'\"') + '</span>';
  document.getElementById("tdesc").innerHTML = '<span>' + (json.HiradObservation.blunt_phrase) + '</span>';
  document.getElementById("visible").innerHTML = '<span>' + (visibilitytxt+json.HiradObservation.visibility) + '</span>';

}
catch(err){
  document.getElementById("rainfall").innerHTML = '<span>' + ('Not available') + '</span>';
  document.getElementById("tdesc").innerHTML = '<span>' + (json.StandardObservation.blunt_phrase) + '</span>';
  document.getElementById("visible").innerHTML = '<span>'+ ('Not available') +'</span>';
}




try {
warning=json.WeatherAlerts[0].headline;
} catch(err){
  warning=notxt+warningtxt;
}

  document.getElementById("warning").innerHTML = '<span>' + (warningtxt+warning) + '</span>';


if(warning2!==null){ //activate with touch. Need to send parameter to activate
  try { //use try because we don't know if it exists.
warning=json.WeatherAlerts[0].text;
document.getElementById("warning").innerHTML = '<span>' + (warningtxt+warning) + '</span>';

} catch(err){
  warning=notxt+warningtxt;
  document.getElementById("warning").innerHTML = '<span>' + (warningtxt+warning) + '</span>';

}

}

//////////////////////////////////////////////////////////////////////////////////
document.getElementById("raininfo").innerHTML = '<span>' + (raininfo.standardPhrase) + '</span>';


var exday=JSON.stringify(narrativeinfo[0].dayPart);
exday = exday.replace(/"/g, "");
var exstuff=JSON.stringify(narrativeinfo[0].phrase);
exstuff = exstuff.replace(/"/g, "");
document.getElementById("desc1").innerHTML = '<span>' + (exday+": "+exstuff) + '</span>';

var exday2=JSON.stringify(narrativeinfo[1].dayPart);
exday2 = exday2.replace(/"/g, "");
var exstuff2=JSON.stringify(narrativeinfo[1].phrase);
exstuff2 = exstuff2.replace(/"/g, "");
document.getElementById("desc2").innerHTML = '<span>' + (exday2+": "+exstuff2) + '</span>';

var exday3=JSON.stringify(narrativeinfo[2].dayPart);
exday3 = exday3.replace(/"/g, "");
var exstuff3=JSON.stringify(narrativeinfo[2].phrase);
exstuff3 = exstuff3.replace(/"/g, "");
document.getElementById("desc3").innerHTML = '<span>' + (exday3+": "+exstuff3) + '</span>';

var exday4=JSON.stringify(narrativeinfo[4].dayPart);
exday4 = exday4.replace(/"/g, "");
var exstuff4=JSON.stringify(narrativeinfo[4].phrase);
exstuff4 = exstuff4.replace(/"/g, "");
document.getElementById("desc4").innerHTML = '<span>' + (exday4+": "+exstuff4) + '</span>';

var exday5=JSON.stringify(narrativeinfo[5].dayPart);
exday5 = exday5.replace(/"/g, "");
var exstuff5=JSON.stringify(narrativeinfo[5].phrase);
exstuff5 = exstuff5.replace(/"/g, "");
document.getElementById("desc5").innerHTML = '<span>' + (exday5+": "+exstuff5) + '</span>';


//////////////////////////////////////////////////////////////////////////////////
var Sunrise=sunrise; //Sunrise

document.getElementById("sunrise").innerHTML = '<span>' + (sunrisetxt + Sunrise) + "am"+ '</span>';

//////////////////////////////////////////////////////////////////////////////////
var Sunset=sunset; //Sunset

document.getElementById("sunset").innerHTML = '<span>' + (sunsettxt + Sunset) + "pm"+'</span>';


///weather icon


var iconlocation="libraries/weather/white/icon/";
var imagelocation="libraries/weather/white/icon/";


var iconextention=".png"; //image extentions


var newicos=localStorage.getItem('iconset');

if(newicos){

imagelocation="http://JunesiPhone.com/weather/IconSets/"+newicos+"/";
iconlocation="http://JunesiPhone.com/weather/IconSets/"+newicos+"/";
iconextention=".png"; //image extentions

}


   var numofdays = 4;
    for (i=0; i<numofdays; i++){
         var count = i+1;
         var dn = dailyinfo[count].day ? dailyinfo[count].day : dailyinfo[count].night;
         var da = new Date(dailyinfo[count].validDate * 1000);
         var ht = dailyinfo[count].maxTemp;
         var lt = dailyinfo[count].minTemp;
        document.getElementById("Day"+count).innerHTML = '<img width=' + daysize + ' src=' +iconlocation+ dn.icon + iconextention + '>';
        document.getElementById("ForecastDay"+count).innerHTML = '<span>' + (sday[da.getDay()]) + '</span>';
        document.getElementById("day"+count+"day").innerHTML = '<span>' + (sday[da.getDay()]) + '</span>';
        document.getElementById("Day"+count+"High").innerHTML = '<span>' + (ht + degrees + "/" + '<span class="lowtemp">' + lt + degrees) + '</span>'+'</span>';
        document.getElementById("fcast"+count).innerHTML = '<span><img style="position:relative;top:10px;" width="40" src='+iconlocation+ dn.icon + iconextention +'>' + (sday[da.getDay()] + ", " + Fcondition[dn.icon]+ " - "+ht+degrees + "/"+lt+degrees) + '</span>';
        document.getElementById("day"+count+"iconi").src= iconlocation+ dn.icon + iconextention ;
        document.getElementById("day"+count+"hi").innerHTML = '<span>' + (ht+degrees) + '</span>';
        document.getElementById("day"+count+"lo").innerHTML = '<span>' + (lt+degrees) + '</span>';
        document.getElementById("day"+count+"des").innerHTML = '<span>' + (Fcondition[dn.icon]) + '</span>';

   }







try{
   icon=json.HiradObservation.wxIcon;
   currentIcon=json.HiradObservation.wxIcon;
}
catch(err){
  icon=json.StandardObservation.wxIcon;
  currentIcon=json.StandardObservation.wxIcon;
}



if(json.StandardObservation.wxIcon===""){json.StandardObservation.wxIcon="na";}
if(icon.length===0){
  icon="dunno";
}
var HourlyIcon=imagelocation+icon+imageextention;



iconimg=document.getElementById("iconimg");
iconimg.src=HourlyIcon;

window.NowIcon=icon;


   var rweatherdesc=Rcondition[icon];



    document.getElementById("rude").innerHTML = '<span>' + (rweatherdesc) + '</span>';




//end weathericon

var weatherwall=localStorage.getItem('weatherwalls');
if(weatherwall=="yes"){
  var backwall=document.getElementById('background');
  newimage="var/mobile/Library/LBEvoWeatherWalls/Icons/"+currentIcon+".jpg";
  if(loadLocal('CWeatherWall')!==null){
    wall=loadLocal('CWeatherWall');
    newimage = "/var/mobile/Library/LBEvoWeatherWalls/"+wall+"/"+currentIcon+".jpg";
     setWeatherWall(newimage);
  }
   backwall.style.backgroundImage = 'url('+newimage+')';
}



}


function ShowContent() {
  showdata();
}

function GetXmlFeed(code) {
    var lastset = new Date().getTime();
    jsons = localStorage.getItem('weatherjson');
    lset = localStorage.getItem('wlastset');

    if (lset !== null) {
        if (jsons !== null && Number(lset) + refresh >= lastset && jsons!=="undefined") {
            console.log('Using saved data');
            console.log(lastset);
            console.log(Number(lset)+refresh);
            json = {};
            json = JSON.parse(jsons);
            showdata();
        } else {
          if(jsons!=="undefined"){
            json = {};
            json = JSON.parse(jsons);
            showdata();
          }
            console.log('Using new data');
            try {
                notavalue = code.length;
            } catch (err) {
                code = sCityCodes;
            }
            localStorage.setItem('wlastset', lastset);
            localStorage.setItem('apiLocale', code);
            var sc = document.createElement("script");
            sc.src = 'http://wxdata.weather.com/wxdata/mobile/mobagg/' + code + '.js?key=2227ef4c-dfa4-11e0-80d5-0022198344f4&units=' + sUnit + '&locale=' + language + '&cb=XmlFeedCB';
            localStorage.setItem('weatherurl', sc.src);
            document.body.appendChild(sc);

        }
    } else {

        try {
            notavalue = code.length;
        } catch (err) {
            code = sCityCodes;
        }

        localStorage.setItem('wlastset', lastset);
        localStorage.setItem('apiLocale', code);
        var sc = document.createElement("script");
        sc.src = 'http://wxdata.weather.com/wxdata/mobile/mobagg/' + code + '.js?key=2227ef4c-dfa4-11e0-80d5-0022198344f4&units=' + sUnit + '&locale=' + language + '&cb=XmlFeedCB';
        localStorage.setItem('weatherurl', sc.src);
        document.body.appendChild(sc);

    }
}


function XmlFeedCB(going) {
    if (going[0] !== undefined) {
        json = going[0]; //json is XML
        var jsons = JSON.stringify(json);
        localStorage.setItem('weatherjson', jsons);
        ShowContent();
    } else {
        swal({
            title: "Weather",
            text: "Currently weather is not being retrieved. You may have entered the wrong weather code. Example weather.com code. USMS0365",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Watch a video on how to get this code!",
            cancelButtonText: "No, i'll use a weather.com code.",
            closeOnConfirm: false,
            closeOnCancel: false
        }, function(isConfirm) {
            if (isConfirm) {
                openurl("https://www.youtube.com/watch?v=lAxzBTyXZ1E");
                //respringdevice();
            } else {
                window.location = window.location.href;
            }
        });
    }
}





function startservices(){
    $.get( "file:///private/var/mobile/Documents/myLocation.txt", function( data ) {
    var Lines=data.split('\n'); //spli lines
    var Latitude = Lines[0].split('=')[1]; //get values after equals
    var Longitude = Lines[1].split('=')[1];
    document.getElementById("latext").innerHTML = '<span>' + ('Lat: ' + Latitude) + '</span>';
    document.getElementById("longext").innerHTML = '<span>' + ('Long: ' + Longitude) + '</span>';
    Latitude = parseFloat(Latitude.toString()).toFixed(4);
    Longitude = parseFloat(Longitude.toString()).toFixed(4);
    saveLocal('apiLat',Latitude);
    saveLocal('apiLong',Longitude);
    convertlatlong(Latitude,Longitude);
});
}

function refreshWeather(){
  closemenu();
  var randomsave=Math.floor(Math.random()*101);
  localStorage.setItem('randomsave',randomsave);
  localStorage.removeItem('wlastset');
  localStorage.removeItem('weatherjson');

  if(locationservices==true){
       swal({title: "Weather", text: "Updating from myLocation.txt if this file is not found it will default to the location code set in LBEvo Settings.", type: 'info',confirmButtonText: 'Close',confirmButtonColor: '#393939' });
      startservices();
     }
     else{
      swal({title: "Weather", text: "You are using a weather code set from LBEvo settings, if you want GPS you must enable the switch in settings, remove the weather code, and have a tweak that gets your location.", type: 'info',confirmButtonText: 'Close',confirmButtonColor: '#393939' });
     GetXmlFeed(sCityCodes);
     }
  }

//var locationservice=checklservices();

if(locationservices==true){
  var gpsset="true";
}
else{
  var sCityCodes = sCityCodes;
  //localStorage.setItem('apiLocale',sCityCodes);
    if(sCityCodes!==null){
      GetXmlFeed(sCityCodes);
    }
}





var lastAccess = new Date().getTime();

if (gpsset === "true") {
    var savedAccess=Number(localStorage.getItem('access'));
    if(lastAccess>=savedAccess+refresh){
      localStorage.setItem('access',lastAccess);
      localStorage.setItem('apiLocale',sCityCodes);
      startservices();
    }
    else{
     var zip=localStorage.getItem('apiLocale');
      GetXmlFeed(zip);
    }
}

function convertlatlong(Latitude,Longitude){
var url2 = 'http://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20geo.placefinder%20where%20text%3D"' + Latitude + "%2C" + Longitude + '"%20and%20gflags%3D"R"';
converttowoeid(url2);
}

function converttowoeid(url2){
$.ajax({
    url: url2,
    success: function (e) {
  woeid = $(e).find("woeid").text();
  locale = woeid;
  nhood=$(e).find("neighborhood").text();
  if(nhood.length!==0){localStorage.setItem('neighborhood',nhood);}
  else{nhood="NA";localStorage.setItem('neighborhood',nhood);}
  street=$(e).find("street").text();
  if(street.length!==0){localStorage.setItem('street',street);}
  else{street="NA";localStorage.setItem('street',street);}
  addr=$(e).find("line1").text();
  if(addr.length!==0){localStorage.setItem('addr',addr);}
  else{addr="NA";localStorage.setItem('addr',addr);}
  county=$(e).find("county").text();
  if(county!==0){localStorage.setItem('county',county);}
  else{county="NA";localStorage.setItem('county',county);}
  var url1="http://weather.yahooapis.com/forecastrss?w="+locale;

$.ajax({
    url: url1,
    success: function (e) {
  link= $(e).find("guid").text();
  link=link.split('_');
  locale = link[0];
  GetXmlFeed(locale);
  var sCityCodes = locale;
  //localStorage.setItem('apiLocale',sCityCodes);
  randomsave=Math.floor(Math.random()*101);
  localStorage.setItem('randomsave',randomsave);

    }
});
    }
});
}

function getdates(){
  var date = new Date();
  var day = date.getDay();
  var datetoday=date.getDate();
  var year=date.getFullYear();
  var syear = String(year).substr(2);
  var monthnum=date.getMonth();
  var textdate=["First","Second","Third","Fourth","Fifth","Sixth","Seventh","Eighth","Ninth","Tenth","Eleventh","Twelfth","Thirteenth","Fourteenth","Fifteenth","Sixteenth","Seventeenth","Eightheenth","Nineteenth","Twentyith","TwentyFirst","TwentySecond","TwentyThird",'TwentyFourth',"TwentyFifth","TwentySixth","TwentySeventh","TwentyEight","TwentyNinth","Thirtyith","ThirtyFirst"][datetoday-1];

  document.getElementById("DMD").innerHTML = '<span>' + weekday[day] + ", "+month[monthnum]+" "+datetoday+'</span>';
  document.getElementById("MD").innerHTML = '<span>'+month[monthnum]+" "+datetoday+'</span>';
  document.getElementById("DM").innerHTML = '<span>'+datetoday+" "+month[monthnum]+'</span>';
  document.getElementById("DSM").innerHTML = '<span>'+datetoday+" "+smonth[monthnum]+'</span>';
  document.getElementById("day").innerHTML = '<span>' + weekday[day] +'</span>';
  document.getElementById("sday").innerHTML = '<span>' + sday[day] +'</span>';
  document.getElementById("date").innerHTML = '<span>' + datetoday +'</span>';
  document.getElementById("tdate").innerHTML = '<span>' + textdate +'</span>';
  document.getElementById("month").innerHTML = '<span>' + month[monthnum] +'</span>';
  document.getElementById("smonth").innerHTML = '<span>' + smonth[monthnum] +'</span>';
  document.getElementById("year").innerHTML = '<span>' + year +'</span>';
  document.getElementById("mdy").innerHTML = '<span>' + (monthnum+1)+"/"+day+"/"+syear +'</span>';
  document.getElementById("dmy").innerHTML = '<span>' + day+"/"+(monthnum+1)+"/"+syear +'</span>';



}
setInterval(function(){updateClock();},20000);
setInterval(function(){getdates();},1800000);
getdates();
updateClock();



function updateClock(){
  var currentTime, currentHours, currentMinutes, currentSeconds, currentTimeString, timeOfDay, currentzHours, todayDate, hours, format, t, n, r, i, o, u, a, f, l, c, h;
    // var TwentyFourHourClock = localStorage.getItem('time');
if (TwentyFourHourClock == "false"){
  currentTime = new Date ( );
  currentHours = currentTime.getHours ( );
  currentMinutes = currentTime.getMinutes ( );
  currentSeconds = currentTime.getSeconds ( ); currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
  currentHours = ( currentHours === 0 ) ? 12 : currentHours;
  currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;
  currentTimeString = currentHours + ":" + currentMinutes;


  document.getElementById("zhour").innerHTML = '<span>' + currentHours + '</span>';
  document.getElementById("hour").innerHTML = '<span>' + currentHours + '</span>';
  document.getElementById("minute").innerHTML = '<span>' + currentMinutes + '</span>';
  document.getElementById("time").innerHTML = '<span>' + currentTimeString + '</span>';
  document.getElementById("ztime").innerHTML = '<span>' + currentHours +":"+ currentMinutes + '</span>';


  t = currentTime;
        n = t.getHours();
        r = t.getMinutes();
        i = t.getSeconds();
        n = (n < 10 ? "0" : "") + n;
        r = (r < 10 ? "0" : "") + r;
        o = n + ":" + r;
        u = new Array("Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen", "Twenty", "TwentyOne", "TwentyTwo", "TwentyThree", "TwetyFour");
        a = new Array("o' clock", "o' one", "o' two", "o' three", "o' four", "o' five", "o' six", "o' seven", "o' eight", "o' nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "Sixteen", "Seventeen", "eighteen", "Nineteen", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty");
        f = new Array("", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "");
        t = new Date();
        n = t.getHours();
        r = t.getMinutes();
        l = t.getMinutes();
        i = t.getSeconds();
        o = u[n];
        c = a[r];
        h = f[l];
        document.getElementById("ttext").innerHTML = o + "\n" + c + "\n" + h;
        document.getElementById("htext").innerHTML = o;
        document.getElementById("mtext").innerHTML = c + "\n" + h;

}

if (TwentyFourHourClock == "true"){

   currentTime = new Date ( );
   currentHours = currentTime.getHours ( );
   currentMinutes = currentTime.getMinutes ( );
   currentSeconds = currentTime.getSeconds ( );
   currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;
   currentSeconds = ( currentSeconds < 10 ? "0" : "" ) + currentSeconds;
   timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";
   currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
   currentHours = ( currentHours === 0 ) ? 12 : currentHours;
   currentzHours=( currentHours < 10 ? "0" : "" ) + currentHours;
   currentTimeString = currentHours + ":" + currentMinutes;
 document.getElementById("hour").innerHTML = '<span>' + currentHours + '</span>';
 document.getElementById("zhour").innerHTML = '<span>' + currentzHours + '</span>';
 document.getElementById("minute").innerHTML = '<span>' + currentMinutes + '</span>';
 document.getElementById("time").innerHTML = '<span>' + currentTimeString + '</span>';
 document.getElementById("ztime").innerHTML = '<span>' + currentzHours +":"+ currentMinutes + '</span>';

        t = currentTime;
        n = t.getHours();
        r = t.getMinutes();
        i = t.getSeconds();
        r = (r < 10 ? "0" : "") + r;
        i = (i < 10 ? "0" : "") + i;
        s = n < 12 ? "AM" : "PM";
        n = n > 12 ? n - 12 : n;
        n = n === 0 ? 12 : n;
        o = n + ":" + r;
        u = new Array("Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve");
        a = new Array("o' clock", "o' one", "o' two", "o' three", "o' four", "o' five", "o' six", "o' seven", "o' eight", "o' nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "Sixteen", "Seventeen", "eighteen", "Nineteen", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty");
        f = new Array("", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "");
        t = new Date();
        n = t.getHours();
        r = t.getMinutes();
        l = t.getMinutes();
        i = t.getSeconds();
        o = u[n];
        c = a[r];
        h = f[l];
        document.getElementById("ttext").innerHTML = o + "\n" + c + "\n" + h;
        document.getElementById("htext").innerHTML = o;
        document.getElementById("mtext").innerHTML = c + "\n" + h;
}

todayDate=new Date();
hours=todayDate.getHours();
format ="AM";
if(hours>11){format="PM";
}
document.getElementById("pm").innerHTML = '<span>' + format + '</span>';
}//end updateclock



//GetXmlFeed(true); Turned off controlled by GPS cydget
//Weather icons are hosted on JunesiPhone.com many of which were created by other artist.
//If any icons are listed that are yours you can send an email to LockBuilder@gmail.com
//3D flat bottom icons Credits: Stardate Tab 10.1, XDA
//Blacky Icons Rokey www.rokey.net
//RealIcons https://plus.google.com/110117535284009613290/posts/3gAcyw7yfh2
//girly https://plus.google.com/114658386874394074243/posts/EhQ3SjfjFqE
//jaws https://plus.google.com/+graemesykessphinx/posts/Ne17MC9fxUm
//wettericons http://www.android-hilfe.de/homescreen-modding/462648-apk-zooper-widget-widget-themes-iconsets-skins-keine-diskussion-2.html#post6361290





