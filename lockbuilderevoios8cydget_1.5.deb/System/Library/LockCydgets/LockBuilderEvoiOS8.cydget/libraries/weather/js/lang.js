
  if(language=="en"){
  var weekday = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
  var month=["January","February","March","April","May","June","July","August","September","October","November","December"];
  var smonth=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  var sday=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
  var windtxt = "Wind: ";
  var feeltxt = "Feels Like: ";
  var sunrisetxt = "Sunrise: ";
  var sunsettxt = "Sunset: ";
  var textstringlater="Later Today: ";
  var humidtxt="Humidity: ";
  var warningtxt = "Warning ";
  var elevationtxt = "Elevation: ";
  var preciptxt = "Precip ";
  var notxt = "No ";
  var visibilitytxt = "Visibility: ";
  var Fcondition = [ "Tornado", "Tropical Storm", "Hurricane", "Thunderstorm", "Thunderstorm", "Snow", "Sleet", "Sleet", "Freezing Drizzle", "Drizzle", "Freezing Rain", "Showers", "Showers", "Flurries", "Snow", "Snow", "Snow", "Hail", "Sleet", "Dust", "Fog", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Clear", "Sunny", "Fair", "Fair", "Sleet", "Hot", "Thunderstorms", "Thunderstorms", "Thunderstorms", "Showers", "Heavy Snow", "Light Snow", "Heavy Snow", "Partly Cloudy", "Thunderstorm", "Snow", "Thunderstorm", "blank" ];
  var Rcondition = [ "Oh shit a tornado", "Damn tropical storm", "Run its a hurricane", "Fucking thunderstorm", "Fuck its a thunderstorm", "Fuck its snowing", "Fucking sleet", "Fucking sleet", "Fuck it's drizzling", "Fuck it's drizzling", "Fucking freezing rain", "Fuck it's raining", "Fuck it's raining", "Fucking flurries", "Fucking light snow", "Fuck it's snowing", "Fuck it's snowing", "Fucking hailing", "Fuck it's sleeting", "Fucking dusty out here", "Fucking foggy", "Fucking hazy", "Fucking smoky", "WTF it's blustery", "Windy as fuck", "Cold as fuck", "It's fucking cloudy", "It's fucking mostly cloudy", "It's fucking mostly cloudy", "It's fucking partly cloudy", "It's fucking partly cloudy", "It's fucking clear", "It's fucking sunny outside", "Fucking fair", "Fucking fair", "Fucking sleeting", "Fuck it's hot", "Isolated fucking thunderstorms", "Scattered fucking thunderstorms", "Scattered fucking thunderstorms", "Scattered fucking showers", "Heavy fucking snow", "Light fucking snow", "Heavy fucking snow", "Partly fucking cloudy", "Fucking thunderstorm", "It's fucking snowing", "It's a fucking thunderstorm", "blank" ];
  var Rcondition = [ "Oh shit a tornado", "Damn tropical storm", "Run its a hurricane", "Fucking thunderstorm", "Fuck its a thunderstorm", "Fuck its snowing", "Fucking sleet", "Fucking sleet", "Fuck it's drizzling", "Fuck it's drizzling", "Fucking freezing rain", "Fuck it's raining", "Fuck it's raining", "Fucking flurries", "Fucking light snow", "Fuck it's snowing", "Fuck it's snowing", "Fucking hailing", "Fuck it's sleeting", "Fucking dusty out here", "Fucking foggy", "Fucking hazy", "Fucking smoky", "WTF it's blustery", "Windy as fuck", "Cold as fuck", "It's fucking cloudy", "It's fucking mostly cloudy", "It's fucking mostly cloudy", "It's fucking partly cloudy", "It's fucking partly cloudy", "It's fucking clear", "It's fucking sunny outside", "Fucking fair", "Fucking fair", "Fucking sleeting", "Fuck it's hot", "Isolated fucking thunderstorms", "Scattered fucking thunderstorms", "Scattered fucking thunderstorms", "Scattered fucking showers", "Heavy fucking snow", "Light fucking snow", "Heavy fucking snow", "Partly fucking cloudy", "Fucking thunderstorm", "It's fucking snowing", "It's a fucking thunderstorm", "blank" ];
  
  }
  else if(language=="it"){
  var weekday = ['Domenica','Luned&#236','Marted&#236','Mercoled&#236','Gioved&#236','Venerd&#236','Sabato'];
  var month=["Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre"];
  var smonth=["Gen","Feb","Mar","Apr","Mag","Giu","Lug","Ago","Set","Ott","Nov","Dic"];
  var sday=["Sun", "Mon", "Mar", "Mer", "Gio", "Ven", "Sat"];
  var windtxt = "Vento: ";
  var feeltxt = "Sembra: ";
  var sunrisetxt = "Alba: ";
  var sunsettxt = "Tramonto: ";
  var textstringlater="Più tardi oggi: ";
  var humidtxt="Umidità: ";
  var warningtxt = "Avvertimento ";
  var elevationtxt = "Elevazione: ";
  var preciptxt = "Pioggia ";
  var notxt = "No ";
  var visibilitytxt = "Visibilità: ";
  var Fcondition = [ "Tornado", "Tempesta Tropicale", "Uragano", "Temporali Forti", "Temporali", "Pioggia mista a Neve", "Nevischio", "Nevischio", "Pioggia Gelata", "Pioggerella", "Pioggia Ghiacciata", "Pioggia", "Pioggia", "Neve a Raffiche", "Neve Leggera", "Tempesta di Neve", "Neve", "Grandine", "Nevischio", "Irregolare", "Nebbia", "Foschia", "Fumoso", "Raffiche di Vento", "Ventoso", "Freddo", "Nuvoloso", "Molto Nuvoloso", "Molto Nuvoloso", "Nuvoloso", "Nuvoloso", "Sereno", "Sereno", "Bel Tempo", "Bel Tempo", "Pioggia e Grandine", "Caldo", "Temporali Isolati", "Temporali Sparsi", "Temporali Sparsi", "Rovesci Sparsi", "Neve Forte", "Nevicate Sparse", "Neve Forte", "Nuvoloso", "Rovesci Temporaleschi", "Rovesci di Neve", "Temporali isolati", "Non Disponibile" ];
   var Rcondition = [ "Oh shit a tornado", "Damn tropical storm", "Run its a hurricane", "Fucking thunderstorm", "Fuck its a thunderstorm", "Fuck its snowing", "Fucking sleet", "Fucking sleet", "Fuck it's drizzling", "Fuck it's drizzling", "Fucking freezing rain", "Fuck it's raining", "Fuck it's raining", "Fucking flurries", "Fucking light snow", "Fuck it's snowing", "Fuck it's snowing", "Fucking hailing", "Fuck it's sleeting", "Fucking dusty out here", "Fucking foggy", "Fucking hazy", "Fucking smoky", "WTF it's blustery", "Windy as fuck", "Cold as fuck", "It's fucking cloudy", "It's fucking mostly cloudy", "It's fucking mostly cloudy", "It's fucking partly cloudy", "It's fucking partly cloudy", "It's fucking clear", "It's fucking sunny outside", "Fucking fair", "Fucking fair", "Fucking sleeting", "Fuck it's hot", "Isolated fucking thunderstorms", "Scattered fucking thunderstorms", "Scattered fucking thunderstorms", "Scattered fucking showers", "Heavy fucking snow", "Light fucking snow", "Heavy fucking snow", "Partly fucking cloudy", "Fucking thunderstorm", "It's fucking snowing", "It's a fucking thunderstorm", "blank" ];
  
  }
  else if(language=="sp"){
  var weekday = ["Domingo","Lunes","Martes","Miércoles","Jueves","Viernes","Sábado"];
  var month=["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
  var smonth=["Ene","Feb","Mar","Abr","Mayo","Jun","Jul","Aug","Sep","Oct","Nov","Dic"];
  var sday=["Sol","Mon","Mar","Mie","Jue","Vie","Sat"];
  var windtxt = "Viento: ";
  var feeltxt = "Sensación térmica: ";
  var sunrisetxt = "Salida del sol: ";
  var sunsettxt = "Puesta del sol: ";
  var textstringlater="Para hoy más tarde: ";
  var humidtxt="Humedad: ";
  var warningtxt = "Advertencia ";
  var elevationtxt = "Elevación: ";
  var preciptxt = "Precip ";
  var notxt = "No ";
  var visibilitytxt = "Visibilidad: ";
  var Fcondition = [ "Tornado", "Tormenta Tropical", "Huracan", "Tormentas Electricas Severas", "Tormentas Electricas", "Mezcla de Lluvia y Nieve", "Mezcla de lluvia y aguanieve", "Mezcla de nieve y aguaniev", "Llovizna helada", "Llovizna", "Lluvia bajo cero", "Chubascos", "Chubascos", "Rafagas de nieve", "Ligeras precipitaciones de nieve", "Viento y nieve", "Nieve", "Granizo", "Aguanieve", "Polvareda", "Neblina", "Bruma", "Humeado", "Tempestuoso", "Vientoso", "Frio", "Nublado ", "Mayormente nublado", "Mayormente nublado", "despejado", "despejado", "Despejado", "Soleado", "Lindo", "Lindo", "Mezcla de lluvia y granizo", "Caluroso", "Tormentas electricas aisladas", "Tormentas electricas dispersas", "Tormentas electricas dispersas", "Chubascos dispersos", "Nieve fuerte", "Precipitaciones de nieve dispersas", "Nieve fuerte", "despejado", "Lluvia con truenos y relampagos", "Precipitaciones de nieve", "Tormentas aisladas", "No disponible" ];
  var Rcondition = [ "Oh shit a tornado", "Damn tropical storm", "Run its a hurricane", "Fucking thunderstorm", "Fuck its a thunderstorm", "Fuck its snowing", "Fucking sleet", "Fucking sleet", "Fuck it's drizzling", "Fuck it's drizzling", "Fucking freezing rain", "Fuck it's raining", "Fuck it's raining", "Fucking flurries", "Fucking light snow", "Fuck it's snowing", "Fuck it's snowing", "Fucking hailing", "Fuck it's sleeting", "Fucking dusty out here", "Fucking foggy", "Fucking hazy", "Fucking smoky", "WTF it's blustery", "Windy as fuck", "Cold as fuck", "It's fucking cloudy", "It's fucking mostly cloudy", "It's fucking mostly cloudy", "It's fucking partly cloudy", "It's fucking partly cloudy", "It's fucking clear", "It's fucking sunny outside", "Fucking fair", "Fucking fair", "Fucking sleeting", "Fuck it's hot", "Isolated fucking thunderstorms", "Scattered fucking thunderstorms", "Scattered fucking thunderstorms", "Scattered fucking showers", "Heavy fucking snow", "Light fucking snow", "Heavy fucking snow", "Partly fucking cloudy", "Fucking thunderstorm", "It's fucking snowing", "It's a fucking thunderstorm", "blank" ];
  
  }
  else if(language=="de"){
  var weekday = ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
  var month=["Januar","Februar","März","April","Mai","Juni","Ju li","August","September","Oktober","November","Dezember"];
  var smonth=["Jan", "Feb", "Maa", "Apr", "Kun", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez "];
  var sday=["Son","Mon","Die","Mit","Don","Fre","Sam"];
  var windtxt = "Wind: ";
  var feeltxt = "Gefühlt wie";
  var sunrisetxt = "Sonnenaufgang: ";
  var sunsettxt = "Sonnenuntergang: ";
  var textstringlater="Im Laufe des Tages: ";
  var humidtxt="Luftfeuchtigkeit: ";
  var warningtxt = "Warnung ";
  var elevationtxt = "Hoch: ";
  var preciptxt = "Niederschlag: ";
  var dewpointtxt = "Taupunkt: ";
  var notxt = "Nein";
  var visibilitytxt = "Sichtbarkeit: ";
  var Fcondition = [ "Tornado", "Tropischer Sturm", "Wirbelsturm", "Schwere Gewitter", "Gewitter", "Regen und Schnee", "Graupelschauer", "Schneeregen", "Gefrierender Nieselregen", "Nieselregen", "Gefrierender Regen", "Schauer", "Schauer", "Schneegestöber", "Leichte Schneeschauer", "Schneetreiben", "Schnee", "Hagel", "Schneeregen", "Staubig", "Nebelig", "Dunstschleier", "Dunstig", "Stürmisch", "Windig", "Kalt", "Bewölkt", "Meist Bewölkt", "Meist Bewölkt", "Bewölkt", "Bewölkt", "Klar", "Sonnig", "Heiter", "Heiter", "Regen und Hagel", "Heiss", "Örtliche Gewitter", "Vereinzelte Gewitter", "Vereinzelte Gewitter", "Vereinzelte Schauer", "Starker Schneefall", "Vereinzelte Schneeschauer", "Starker Schneefall", "Bewölkt", "Gewitter", "Scheeschauer", "Örtliche Gewitterschauer", "Nicht Verfügbar" ];
  var Rcondition = [ "Oh shit a tornado", "Damn tropical storm", "Run its a hurricane", "Fucking thunderstorm", "Fuck its a thunderstorm", "Fuck its snowing", "Fucking sleet", "Fucking sleet", "Fuck it's drizzling", "Fuck it's drizzling", "Fucking freezing rain", "Fuck it's raining", "Fuck it's raining", "Fucking flurries", "Fucking light snow", "Fuck it's snowing", "Fuck it's snowing", "Fucking hailing", "Fuck it's sleeting", "Fucking dusty out here", "Fucking foggy", "Fucking hazy", "Fucking smoky", "WTF it's blustery", "Windy as fuck", "Cold as fuck", "It's fucking cloudy", "It's fucking mostly cloudy", "It's fucking mostly cloudy", "It's fucking partly cloudy", "It's fucking partly cloudy", "It's fucking clear", "It's fucking sunny outside", "Fucking fair", "Fucking fair", "Fucking sleeting", "Fuck it's hot", "Isolated fucking thunderstorms", "Scattered fucking thunderstorms", "Scattered fucking thunderstorms", "Scattered fucking showers", "Heavy fucking snow", "Light fucking snow", "Heavy fucking snow", "Partly fucking cloudy", "Fucking thunderstorm", "It's fucking snowing", "It's a fucking thunderstorm", "blank" ];
  
  }
  else if(language=="fr"){
  var weekday = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
  var month=["Janvie","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"];
  var smonth=["Jan", "Fév", "Mar", "Avr", "Mai", "Jui", "Jui", "Aoû", "Sep", "Oct", "Nov", "Déc"];
  var sday=["Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"];
  var windtxt = "Vent: ";
  var feeltxt = "Ressenti: ";
  var sunrisetxt = "Lever du soleil: ";
  var sunsettxt = "Coucher du soleil: ";
  var textstringlater="Plus tard aujourd'hui: ";
  var humidtxt="Humidité: ";
  var warningtxt = "Avertissement ";
  var elevationtxt = "Elévation: ";
  var preciptxt = "Précipitations: ";
  var notxt = "No ";
  var visibilitytxt = "Visibilité: ";
  var Fcondition = [ "Tornade", "Tropical", "Ouragan", "Orages Violents", "Orages", "Pluie", "Pluie", "Neige", "Bruine", "Bruine", "Pluie", "Averses", "Averses", "Quelques Flocons", "Faibles Chutes de Neige", "Rafales de Neige", "Neige", "GrÃªle", "Neige Fondue", "PoussiÃ©reux", "Brouillard", "Brume", "Brumeux", "TempÃªte", "Vent", "Temps Froid", "Temps Nuageux ", "TrÃ¨s Nuageux", "TrÃ¨s Nuageux", "Nuageux", "Nuageux", "Temps Clair", "Ensoleille", "Beau Temps", "Beau Temps", "Pluie et GrÃªles", "Temps Chaud", "Orages IsolÃ©s", "Orages Eparses", "Orages Eparses", "Averses Eparses", "Fortes Chutes de Neige", "Chutes de Neige Eparses", "Fortes Chutes de Neige", "Nuageux", "Orages", "Chute de Neige", "Orages IsolÃ©s", "Non Disponible" ];
  var Rcondition = [ "Oh shit a tornado", "Damn tropical storm", "Run its a hurricane", "Fucking thunderstorm", "Fuck its a thunderstorm", "Fuck its snowing", "Fucking sleet", "Fucking sleet", "Fuck it's drizzling", "Fuck it's drizzling", "Fucking freezing rain", "Fuck it's raining", "Fuck it's raining", "Fucking flurries", "Fucking light snow", "Fuck it's snowing", "Fuck it's snowing", "Fucking hailing", "Fuck it's sleeting", "Fucking dusty out here", "Fucking foggy", "Fucking hazy", "Fucking smoky", "WTF it's blustery", "Windy as fuck", "Cold as fuck", "It's fucking cloudy", "It's fucking mostly cloudy", "It's fucking mostly cloudy", "It's fucking partly cloudy", "It's fucking partly cloudy", "It's fucking clear", "It's fucking sunny outside", "Fucking fair", "Fucking fair", "Fucking sleeting", "Fuck it's hot", "Isolated fucking thunderstorms", "Scattered fucking thunderstorms", "Scattered fucking thunderstorms", "Scattered fucking showers", "Heavy fucking snow", "Light fucking snow", "Heavy fucking snow", "Partly fucking cloudy", "Fucking thunderstorm", "It's fucking snowing", "It's a fucking thunderstorm", "blank" ];
  
  }
  else if(language=="zh"){
    var weekday = ['星期日','星期一','星期二','星期三','星期四','星期五','星期六'];
    var month=['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'];
    var smonth=['一','二','三','四','五','六','七','八','九','十','十一','十二'];
    var sday=['周日','周一','周二','周三','周四','周五','周六'];
    var windtxt = "风: ";
    var feeltxt = "感觉好像: ";
    var sunrisetxt = "日出: ";
    var sunsettxt = "日落: ";
    var textstringlater="今天晚些时候: ";
    var elevationtxt = "海拔: ";
    var humidtxt="湿度: ";
    var warningtxt = "警告 ";
    var preciptxt = "雨 ";
    var notxt = "沒有 ";
    var visibilitytxt = "能見度: ";
    var Fcondition = [ "Tornado", "Tropical Storm", "Hurricane", "Thunderstorm", "Thunderstorm", "Snow", "Sleet", "Sleet", "Freezing Drizzle", "Drizzle", "Freezing Rain", "Showers", "Showers", "Flurries", "Snow", "Snow", "Snow", "Hail", "Sleet", "Dust", "Fog", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Clear", "Sunny", "Fair", "Fair", "Sleet", "Hot", "Thunderstorms", "Thunderstorms", "Thunderstorms", "Showers", "Heavy Snow", "Light Snow", "Heavy Snow", "Partly Cloudy", "Thunderstorm", "Snow", "Thunderstorm", "blank" ];
    var Rcondition = [ "Oh shit a tornado", "Damn tropical storm", "Run its a hurricane", "Fucking thunderstorm", "Fuck its a thunderstorm", "Fuck its snowing", "Fucking sleet", "Fucking sleet", "Fuck it's drizzling", "Fuck it's drizzling", "Fucking freezing rain", "Fuck it's raining", "Fuck it's raining", "Fucking flurries", "Fucking light snow", "Fuck it's snowing", "Fuck it's snowing", "Fucking hailing", "Fuck it's sleeting", "Fucking dusty out here", "Fucking foggy", "Fucking hazy", "Fucking smoky", "WTF it's blustery", "Windy as fuck", "Cold as fuck", "It's fucking cloudy", "It's fucking mostly cloudy", "It's fucking mostly cloudy", "It's fucking partly cloudy", "It's fucking partly cloudy", "It's fucking clear", "It's fucking sunny outside", "Fucking fair", "Fucking fair", "Fucking sleeting", "Fuck it's hot", "Isolated fucking thunderstorms", "Scattered fucking thunderstorms", "Scattered fucking thunderstorms", "Scattered fucking showers", "Heavy fucking snow", "Light fucking snow", "Heavy fucking snow", "Partly fucking cloudy", "Fucking thunderstorm", "It's fucking snowing", "It's a fucking thunderstorm", "blank" ];
  

  }
  else{
  var weekday = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
  var month=["January","February","March","April","May","June","July","August","September","October","November","December"];
  var smonth=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  var sday=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
  var windtxt = "Wind: ";
  var feeltxt = "Feels Like: ";
  var sunrisetxt = "Sunrise: ";
  var sunsettxt = "Sunset: ";
  var textstringlater="Later Today:";
  var humidtxt="Humidity: ";
  var warningtxt = "Warning ";
  var elevationtxt = "Elevation: ";
  var preciptxt = "Precip ";
  var notxt = "No ";
  var visibilitytxt = "Visibility: ";
  var Fcondition = [ "Tornado", "Tropical Storm", "Hurricane", "Thunderstorm", "Thunderstorm", "Snow", "Sleet", "Sleet", "Freezing Drizzle", "Drizzle", "Freezing Rain", "Showers", "Showers", "Flurries", "Snow", "Snow", "Snow", "Hail", "Sleet", "Dust", "Fog", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Clear", "Sunny", "Fair", "Fair", "Sleet", "Hot", "Thunderstorms", "Thunderstorms", "Thunderstorms", "Showers", "Heavy Snow", "Light Snow", "Heavy Snow", "Partly Cloudy", "Thunderstorm", "Snow", "Thunderstorm", "blank" ];
  var Rcondition = [ "Oh shit a tornado", "Damn tropical storm", "Run its a hurricane", "Fucking thunderstorm", "Fuck its a thunderstorm", "Fuck its snowing", "Fucking sleet", "Fucking sleet", "Fuck it's drizzling", "Fuck it's drizzling", "Fucking freezing rain", "Fuck it's raining", "Fuck it's raining", "Fucking flurries", "Fucking light snow", "Fuck it's snowing", "Fuck it's snowing", "Fucking hailing", "Fuck it's sleeting", "Fucking dusty out here", "Fucking foggy", "Fucking hazy", "Fucking smoky", "WTF it's blustery", "Windy as fuck", "Cold as fuck", "It's fucking cloudy", "It's fucking mostly cloudy", "It's fucking mostly cloudy", "It's fucking partly cloudy", "It's fucking partly cloudy", "It's fucking clear", "It's fucking sunny outside", "Fucking fair", "Fucking fair", "Fucking sleeting", "Fuck it's hot", "Isolated fucking thunderstorms", "Scattered fucking thunderstorms", "Scattered fucking thunderstorms", "Scattered fucking showers", "Heavy fucking snow", "Light fucking snow", "Heavy fucking snow", "Partly fucking cloudy", "Fucking thunderstorm", "It's fucking snowing", "It's a fucking thunderstorm", "blank" ];
  
  }

  /*  $.datepicker.regional['fr'] = {
    monthNames: ['Janvier','Février','Mars','Avril','Mai','Juin',
    'Juillet','Août','Septembre','Octobre','Novembre','Décembre'],
    monthNamesShort: ['Jan','Fév','Mar','Avr','Mai','Jun',
    'Jul','Aoû','Sep','Oct','Nov','Déc'],
    dayNames: ['Dimanche','Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi'],
    dayNamesShort: ['Dim','Lun','Mar','Mer','Jeu','Ven','Sam'],
    dayNamesMin: ['Di','Lu','Ma','Me','Je','Ve','Sa']};

    $.datepicker.regional['de'] = {
    monthNames: ['Januari','Februari','Maart','April','Mei','Juni',
    'Juli','Augustus','September','Oktober','November','December'],
    monthNamesShort: ['Jan','Feb','Mrt','Apr','Mei','Jun',
    'Jul','Aug','Sep','Okt','Nov','Dec'],
    dayNames: ['Zondag','Maandag','Dinsdag','Woensdag','Donderdag','Vrijdag','Zaterdag'],
    dayNamesShort: ['Zo', 'Ma','Di','Wo','Do','Vr','Za'],
    dayNamesMin: ['Zo', 'Ma','Di','Wo','Do','Vr','Za']};

    $.datepicker.regional['sp'] = {
      monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
      monthNamesShort: ['Ene','Feb','Mar','Abr', 'May','Jun','Jul','Ago','Sep', 'Oct','Nov','Dic'],
      dayNames: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
      dayNamesShort: ['Dom','Lun','Mar','Mié','Juv','Vie','Sáb'],
      dayNamesMin: ['Do','Lu','Ma','Mi','Ju','Vi','Sá']};

    $.datepicker.regional['it'] = {
      monthNames:['Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno','Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre'],
      monthNamesShort: ['Gen','Feb','Mar','Apr','Mag','Giu','Lug','Ago','Set','Ott','Nov','Dic'],
      dayNames:['Domenica','Luned&#236','Marted&#236','Mercoled&#236','Gioved&#236','Venerd&#236','Sabato'],
      dayNamesShort: ['Dom','Lun','Mar','Mer','Gio','Ven','Sab'],
      dayNamesMin: ['Do','Lu','Ma','Me','Gio','Ve','Sa']};

       $.datepicker.regional['zh'] = {
        monthNames: ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'],
        monthNamesShort: ['一','二','三','四','五','六','七','八','九','十','十一','十二'],
        dayNames: ['星期日','星期一','星期二','星期三','星期四','星期五','星期六'],
        dayNamesShort: ['周日','周一','周二','周三','周四','周五','周六'],
        dayNamesMin: ['日','一','二','三','四','五','六']};
        */


