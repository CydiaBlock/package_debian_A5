var bgDIV, overlayDIV, selwallDIV, topmenuDIV, savedhideobj, menuloaded;
bgDIV = getEL('background');
overlayDIV = getEL('overlay');
selwallDIV = getEL('selectwalls');
topmenuDIV = getEL('topmenus');
savedhideobj = loadLocal('hideOBJ'); //objects that are shown/hidden
menuloaded = 0;

function showhelper(){
    var hElp = localStorage.getItem('helperel');
    document.getElementById('obj').innerHTML=hElp;
    getEL('helper').style.display="block";
    addHelperClicks();
}
function addappdoubleclick(key){ //add double tap to each element to open helper
    $('#'+key).on('doubletap', function() {
        var dblelement=$(this).attr("id");
        localStorage.setItem('helperel',dblelement);
        showhelper();
    });
}
function closehelper() {
    var helperdivs = ['helper','changeweatherico','changeico','colorpick'];
    for (var i=0; i<helperdivs.length; i++){
        getEL(helperdivs[i]).style.display="none";
    }
    helperdivs = null;
}

checkKey = function(key){
    if($('#' + key).length){return true;}
};

function blurbackground(){
    bgDIV.style.zIndex="30";
    bgDIV.style.display="block";
    //bgDIV.className = "blurred"; //removed blurring of bg
}
function unblurbackground(){
    bgDIV.style.zIndex="1";
    //bgDIV.className = ""; //removed blurring of bg
    bgDIV.style.display="none";
}
function openoverlay(overlay) {
    var docoverlay;
    saveLocal('overlay', overlay);
    overlayDIV.style.display = "block";
    overlayDIV.src = "/var/mobile/Library/LBEvoOverlays/" + overlay;
    $('.overlays').remove();
    $('#next').remove();// remove buttons
    $('#prev').remove();
}

function getiwidgetsize(widget) {
    try {
        var iwidgetsettings = readDict('/var/mobile/Library/iWidgets/' + widget + '/Widget.plist');
        if (iwidgetsettings !== null) {
            iwidgetwidth = iwidgetsettings.size.width;
            iwidgetheight = iwidgetsettings.size.height;
        }
    } catch (err) {
        alert("iWidget" + err);
    }
    try {
        var documentsPath = "/var/mobile/Library/iWidgets/" + widget + "/Options.plist";
        var wfileExists = fileExists(documentsPath);
        if (wfileExists === true) {
            swal({
                title: "Options.plist",
                text: "This iWidget has options.plist where settings are set through iWidget. It may not work in LBEvo.",
                type: 'info',
                confirmButtonText: 'Close',
                confirmButtonColor: '#393939'
            });
            loadiwidgetnow();
        } else if (wfileExists === false) {
            loadiwidgetnow();
        }

        function loadiwidgetnow() {
            loadiwidgets(widget, iwidgetwidth, iwidgetheight);
        }
    } catch (err) {
        alert("iWidget2" + err);
    }
}

function loadanimations() {
    closemenu();
    getEL('animations').style.display = "block";
    localStorage.removeItem('hiddenbg');
    bgDIV.style.visibility = "visible";
    var allfiles = readplist('/var/mobile/Library/LBEvoAnimations/');
    for (var i = 0; i < allfiles.length; i++) {
        ids = allfiles[i];
        classname = "animations";
        d1 = document.createElement('div');
        $(d1).addClass(classname).html("" + ids).appendTo($('#animations')).click(function() {
            thisname = this.innerHTML;
            openanimations(thisname);
        });
    }
    d2 = document.createElement('div');
    $(d2).addClass(classname).html("Remove current animation").appendTo($('#animations')).click(function() {
        thisname = this.innerHTML;
        stopanimations();
    });
    blurbackground();
    $('#animations').touch();
}

//groovylock
function loadGL() {
    blurbackground();
    closemenu();
    var Gallfiles=readplist('/var/mobile/Library/GroovyLock/');
    for (var w = 0; w < Gallfiles.length; w++) {
      Gids = Gallfiles[w];
      Gclassname = "lockscreen";
      Gd = document.createElement('div');
      $(Gd).addClass(Gclassname).html("" + Gids).appendTo($('#lockscreens')).click(function () {thisname = this.innerHTML;openlock(thisname);unblurbackground();});
    }
    $('#lockscreens').touch();
}
//springboard
  function saveSBtheme(){
    var sbstore = ['dragOBJ','capsOBJ','hideOBJ','iconimgOBJ','iconOBJ','colorOBJ','fontOBJ','opacityOB','scaleOBJ','userbg','shadowOBJ','lockscreenchosen','newiconimgOBJ','iconset','objiwidgets','animations','weatherwalls','createdobjcreate','alignOB','widget'];
    var randomsave=Math.floor(Math.random()*101);
        for(sa=0; sa < sbstore.length; sa++){
                saveLocal(sbstore[sa]+"SB",loadLocal(sbstore[sa]));
        }
    if(loadLocal('overlay')!== null||loadLocal('overlay')!="null"){saveLocal('overlaySB',loadLocal('overlay'));}
    saveLocal('randomsave',randomsave);
    var wallimg = document.getElementById('background').style.backgroundImage;
    if(wallimg.length > 5){setSBWall(wallimg);}
  swal({   title: "SBHTML",   text: "Enable LockBuilder Evo iOS8 SBHTML in GroovyBoard(SBHTML)",   type: "info",   showCancelButton: false,   confirmButtonColor: "#DD6B55",   confirmButtonText: "Close",   closeOnConfirm: false }, function(){    window.location = window.location.href; });
   sbstore = null;
}

var overlaymenu = 0;

function loadoverlay(prev, stop) {
    var Lids, iD, classname, divmkr, maindiv, nextdiv, prevdiv, endloop, count1, count2, alloverlays, overlaylength, fragment;
    $('.overlays').remove(); //clear overlays
    $('#next').remove();// remove buttons
    $('#prev').remove();
    endloop = "no"; // end of themes
    count1 = 0;
    count2 = 12; //number of themes/overlays per page
    alloverlays = readplist('/var/mobile/Library/LBEvoOverlays/'); //get overlays
    overlaylength = alloverlays.length;
    fragment = document.createDocumentFragment();
if (prev) {
        if (overlaymenu === 0) {
            overlaymenu+= 1;
        } else {
            overlaymenu-= 1;
        }
    } else {
        overlaymenu += 1;
    }
    if (overlaymenu == 1) {
        count1 = 0;
        count2 = 12;
        if (alloverlays[count2] === undefined) {
            endloop = "yes";
            overlaymenu = 0;
        } else {}
    } else if (overlaymenu === 2) {
        count1 = 12;
        count2 = 24;
        if (alloverlays[count2] === undefined) {
            endloop = "yes";
            overlaymenu = 0;
        } else {}
    } else {
        overlaymenus = overlaymenu - 1;
        count1 = count1 + 12 * overlaymenus;
        count2 = count2 + 12 * overlaymenus;
        if (alloverlays[count2] === undefined) {
            endloop = "yes";
            overlaymenu = 0;
        } else {}
} // end if (prev)

    localStorage.removeItem('hiddenbg');
for (var i = count1; i < count2; i++) {
    if (alloverlays[i] === undefined) {} else {
        Lids = alloverlays[i];
        iD = Lids.slice(0, -4);
        classname = "overlays";
        divmkr = document.createElement('div');
        divmkr.id = alloverlays[i];
        $(divmkr).addClass(classname).html('<img id="' + alloverlays[i] + '" class="loadimg" src="/var/mobile/Library/LBEvoOverlays/' + Lids + '"width="60px"><span  class="overlaytxt">' + iD + '</span>').click(function(e) {
            openoverlay(e.target.id);
            unblurbackground();
            overlaymenu = 0;
            getEL('background').style.display = "none";
        });
        fragment.appendChild(divmkr);
    }
} //end for loop
closemenu();
maindiv = getEL('overlays');
maindiv.appendChild(fragment);
hidetm();
blurbackground();
maindiv.style.display = "block";
getEL('background').style.display = "block";
if (count2 >= 12) {
    nextdiv = document.createElement("button");
    nextdiv.setAttribute('onclick', 'loadoverlay()');
    if (endloop == "yes") {
        nextdiv.innerHTML = "End";
    } else {
        nextdiv.innerHTML = "Next";
    }
    nextdiv.setAttribute(
        "style", "position:relative;z-index:20000000; border-radius:2px;width:150px; height:20px; margin-left:160px; margin-top:-20px; text-align:center; opacity:0.2;");
    nextdiv.id = "next";
    maindiv.appendChild(nextdiv);
    prevdiv = document.createElement("button");
    if (overlaymenu == 1) {} else {
        prevdiv.setAttribute('onclick', 'loadoverlay(prev)');
    }
    prevdiv.setAttribute(
        "style", "position:relative;z-index:20000000; border-radius:2px; width:150px; height:20px; margin-left:5px; margin-top:-20px; text-align:center; opacity:0.2;");
    prevdiv.id = "prev";
    if (endloop == "yes") {
        prevdiv.innerHTML = "Home";
    } else {
        if (overlaymenu == 1) { //if themes are on the first page hide the prev button.
            prevdiv.style.opacity = "0";
        } else {
            prevdiv.innerHTML = "Prev";
        }
    }
    maindiv.appendChild(prevdiv);
} else {}
}


function iWidget() {
    blurbackground();
    closemenu();
    var widcontain = getEL('iwidget');
    var Wallfiles = readplist('/var/mobile/Library/iWidgets/');
    var tmp = "";
    for (var u = 0; u < Wallfiles.length; u++) {
        Wids = Wallfiles[u];
        Wd = '<div class="iwidget">' + Wids + '</div>';
        tmp += Wd;
    }
    widcontain.innerHTML = widcontain.innerHTML + tmp;
    widcontain.addEventListener('click', function(e) {
        var target = event.target || event.srcElement;
        openiwidget(target.innerHTML);
        unblurbackground();
    });
    $('#iwidget').touch();
}

function CWeatherWall() {
    blurbackground();
    closemenu();
    var wallcontain = getEL('iwidget');
    var Wallfiles = readplist('/var/mobile/Library/LBEvoWeatherWalls/');
    var tmp = "";
    for (var u = 0; u < Wallfiles.length; u++) {
        WidName = Wallfiles[u];
        Walls = '<div class="weatherwalls">' + WidName + '</div>';
        tmp += Walls;
    }
    wallcontain.innerHTML = wallcontain.innerHTML + tmp;
    wallcontain.addEventListener('click', function(e) {
        var target = event.target || event.srcElement;
        target = target.innerHTML;
        localStorage.setItem('CWeatherWall', target);
        unblurbackground();
        location.reload();
    });
    $('#iwidget').touch();
}


function handleFileSelect(e) {
    var tw, ncount, rd, us;
    tw = e.target.files;
    for (ncount = 0, us; us = tw[ncount]; ncount++) {
        rd = new FileReader;
        rd.onload = function(e) {
            return function(e) {
                saveLocal("userbg", e.target.result);
                getEL('background').style.backgroundImage = "url(" + loadLocal('userbg') + ")";
                localStorage.removeItem('weatherwalls');
                setLSWall(e.target.result);
                closemenu();


            };
        }(us);
        rd.readAsDataURL(us);
    }
}
//show items

function createweathermenu() { //show weather menu
    createweatherEL();
    getEL('weathermenu').style.display="block";
    getEL('premenu').style.display="none";
    $('#weathermenu').touch();
}




function createweatherEL() { //create element menu
    menuloaded+=1;
    if (menuloaded == 1) {
        var weatherel, weatherel2;
        $("ul li").children("div").each(function() {
            weatherel = $(this).attr('id');
            createliMenu(weatherel);
        });
        $("ul li").children("p").each(function() {
            weatherel2 = $(this).attr('id');
            createliMenu(weatherel2);
        });
        if(savedhideobj!==null){
    hideOBJ=JSON.parse(savedhideobj);
    objH=hideOBJ;

    $.each(objH, function(key, value) {
        //$('#'+key).css('display', value);
        if (value != "none") {
            $('#menu'+key).addClass('selectedli');

        }
        else{
            $('#menu'+key).removeClass('selectedli');
            $('#menu'+key).addClass('noselectli');

        }
    });
  }
    } else {}
}

/*$('#Design').click(function(){
    if(getEL('create').style.display==="none"){
        getEL('create').style.display="block";
    }
    else{
        getEL('create').style.display="none";
    }
});*/

function loopsubmenu(array,display){
    for (var We = 0; We < array.length; We += 1) {
                 getEL("menu"+array[We]).style.display=display;
            }
}

function expandapps(app) {
   var elMenu;
    if (app === "Weather") {
        elMenu = ['icon', 'temp','tempFC','windsp','windir','elevation','feeltemp','condition','rude','later','hi','low','uv','raininfo','dew','humidity','rainfall','tdesc','visible','warning'];
            if (getEL('menuicon').style.display === "none") {
                loopsubmenu(elMenu,"block");
            }
            else{
                loopsubmenu(elMenu,"none");
            }
    }
    else if(app==="Forecast"){
        elMenu = ['day1day','day2day','day3day','day4day', 'desc1','desc2','desc3','desc4','desc5','fcast1','fcast2','fcast3','fcast4','day1icon','day1des','day1lo','day1hi','day2icon','day2des','day2lo','day2hi', 'day3icon' ,'day3des','day3lo','day3hi','day4icon','day4des','day4lo','day4hi','forecast'];
            if(getEL('menudesc1').style.display==="none"){
                loopsubmenu(elMenu,"block");
            }
            else{
                loopsubmenu(elMenu,"none");
            }
    }
    else if(app==="Clocks"){
        elMenu = ['ztime','time','zhour','hour','minute','pm','ttext','htext','mtext', 'sunrise','sunset','events'];
            if(getEL('menuztime').style.display==="none"){
                loopsubmenu(elMenu,"block");
            }
            else{
                loopsubmenu(elMenu,"none");
            }
    }
    else if(app==="Dates"){
        elMenu = ['DMD','MD','DM','DSM','day','date','tdate','month','sday','smonth','year','mdy','dmy'];
            if(getEL('menumonth').style.display==="none"){
                loopsubmenu(elMenu,"block");
            }
            else{
                loopsubmenu(elMenu,"none");
            }
    }
    else if(app==="Texts"){
        elMenu = ['slash','slash2','Dlocked','comma','colon','min','max','L2','H2','L','H'];
            if(getEL('menuslash').style.display==="none"){
                loopsubmenu(elMenu,"block");
            }
            else{
                loopsubmenu(elMenu,"none");
            }
    }
    else if(app==="Local"){
        elMenu = ['city','nhood','street','addr','county','lat','long','latext','longext','state','statenm','county'];
            if(getEL('menucity').style.display==="none"){
                loopsubmenu(elMenu,"block");
            }
            else{
                loopsubmenu(elMenu,"none");
            }
    }
    else if(app==="Notify"){
        elMenu = ['sms','mail','phone','twitter','tweetbot','whatapp'];
            if(getEL('menusms').style.display==="none"){
                loopsubmenu(elMenu,"block");
            }
            else{
                loopsubmenu(elMenu,"none");
            }
    }
    else if(app==="System"){
        elMenu = ['dsize','wifi','signal','alarm', 'dfree','msize','CPU','firm','uptime','battery','unlock','name','speak'];
            if(getEL('menudsize').style.display==="none"){
                loopsubmenu(elMenu,"block");
            }
            else{
                loopsubmenu(elMenu,"none");
            }
    }

}

var amenu, limenu, ulmenu, linkFunction;

function createliMenu(app) { //check if menu item is spacer/category/element
    amenu = document.createElement("a");
    if (app == "Weather" || app == "Forecast" || app == "Clocks" || app == "Dates" || app == "Texts" || app == "Local" || app == "System" || app == "Notify") {
        amenu.setAttribute('class', 'spacers');
        menuFunction = "expandapps('"+app+"')";
        amenu.setAttribute('onClick',menuFunction);
        amenu.appendChild(document.createTextNode(app));
    } else if (app == "lspace" || app == "lspace2" || app == "lspace3" || app == "lspace4" || app == "lspace5" || app == "lspace6") {
        amenu.setAttribute('class', 'space');
        amenu.appendChild(document.createTextNode(app));
    } else {
        amenu.id = "menu" + app;
        amenu.style.display = "none";
        amenu.appendChild(document.createTextNode(app));
    }
    limenu = document.createElement("li");
    limenu.appendChild(amenu);
    if (app == "Weather" || app == "Forecast" || app == "Clocks" || app == "Dates" || app == "Texts" || app == "Local" || app == "System" || app == "Notify") {} else if (app == "lspace" || app == "lspace2" || app == "lspace3" || app == "lspace4" || app == "lspace5" || app == "lspace6") {} else {
        linkFunction = "addapps('" + app + "')";
        limenu.setAttribute('onClick', linkFunction);
        limenu.setAttribute('class', 'needsclick');
    }
    ulmenu = getEL("weathermenu");
    ulmenu.insertBefore(limenu, getEL("close"));

}

function saveweatherdisplay(app) { //save element to localStorage
    var currentdisplay, savedhideobj, hidemainOBJ, myhideObject;
    currentdisplay = $('#'+app).css('display');
    $('#'+app).touch();
    hideOBJ = {};
    savedhideobj = loadLocal('hideOBJ');
    if (savedhideobj !== null) {
        hideOBJ = JSON.parse(savedhideobj);
    }
    hideOBJ[app] = [currentdisplay];
    myhideObject = JSON.stringify(hideOBJ);
    saveLocal('hideOBJ', myhideObject);
    addappdoubleclick(app);
}

function addapps(app) { //shade element in menu when placed
   if(getEL(app).style.display){
        if (getEL(app).style.display === "none") {
            getEL(app).style.display = "block";
            $('#menu'+app).addClass('selectedli');
        } else {
            getEL(app).style.display="none";
            $('#menu'+app).removeClass('selectedli');
            $('#menu'+app).addClass('noselectli');
        }
    }else{
        getEL(app).style.display = "block";
        $('#menu'+app).addClass('selectedli');
    }
    saveweatherdisplay(app);
}


$('#newitems').on('doubletap',function(){ //double tap screen to unlock
        unlockphone();
    });


  function showValueopacity(value){ //save opacity of item to localStorage
    var cdiv=loadLocal('helperel');
    getEL(cdiv).style.opacity=value;
    opacityobj(cdiv,value);
  }

  function iconmenu(){ //hide/show icon menu
    getEL('premenu').style.display = "none";
    getEL('iconmenu').style.display = "block";
  }


//$('#premenu').touch();


function firefiles() {
    document.getElementById('selectwalls').style.display="block"; //show wallpaper button.
if (isPasscodeon()) {
    if (wallPass === "no") {
        swal({
            title: "Wallpaper Password",
            text: "You need to set a password to access this. Would you like to open LBSettings?",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            cancelButtonText: "I'll go later.",
            confirmButtonText: "Yes, go there.",
            closeOnConfirm: false
        }, function() {
            openLBsettings();
        });

        closemenu();
    } else {
        var wPass = prompt("Enter your wallpaper password", "");
        if (wPass == wallPass) {
            selwallDIV.style.left = "180px";
            selwallDIV.style.top = "0px";
            getEL("files").addEventListener("change", handleFileSelect, false);
        } else {
            alert("You entered the wrong password");
            location.reload();
        }
    }

    //swal({   title: "Password Protected",   text: "Photos should be private, therefore you cannot use this option with passcode on.",   confirmButtonColor: "#393939" });
} else {
    selwallDIV.style.left = "180px";
    selwallDIV.style.top = "0px";
    getEL("files").addEventListener("change", handleFileSelect, false);
}

}
function hideme(){selwallDIV.style.left = "400px";}
function showtm(){topmenuDIV.style.display = "block";}
function hidetm(){topmenuDIV.style.display = "none";}
if (screen.height > 500) {var iPhoneType = "iPh5";}else {var iPhoneType = "iPh4";}
if(loadLocal('hiddenbg')){bgDIV.style.visibility="hidden";}else{}

//getEL('maskedbg').style.backgroundImage = "url(" + loadLocal('userbg') + ")";


//icons
function iconimgobj(iconimgname, iconimgs) { //when icon is selected
    var iconimgOBJ, savediconimg, myimgObject;
    iconimgOBJ = {};
    savediconimg = loadLocal('iconimgOBJ');
    if (savediconimg !== null) {
        iconimgOBJ = JSON.parse(savediconimg);
    }
    iconimgOBJ[iconimgname] = [iconimgs];
    myimgObject = JSON.stringify(iconimgOBJ);
    saveLocal('iconimgOBJ', myimgObject);
}

function newiconimgOBJ(newiconname, newiconimg) {
    var newiconimgOBJs, savediconimg, myimgObject;
    newiconimgOBJs = {};
    savediconimg = loadLocal('newiconimgOBJ');
    if (savediconimg !== null) {
        newiconimgOBJs = JSON.parse(savediconimg);
    }
    newiconimgOBJs[newiconname] = [newiconimg];
    myimgObject = JSON.stringify(newiconimgOBJs);
    saveLocal('newiconimgOBJ', myimgObject);
}


function iconobj(iconobjname, myTransform) {
    var matrix, values, aiconM, biconM, iconangle, iconOBJ, savediconobj, myObject;
    matrix = $('#' + iconobjname).css('-webkit-transform');
    if (matrix !== "none") {
        values = matrix.split('(')[1].split(')')[0].split(',');
        aiconM = values[0];
        biconM = values[1];
        iconangle = Math.round(Math.atan2(biconM, aiconM) * (180 / Math.PI));
        saveLocal(iconobjname + 'defaultrotation', iconangle);
    }
    iconOBJ = {};
    savediconobj = loadLocal('iconOBJ');
    if (savediconobj !== null) {
        iconOBJ = JSON.parse(savediconobj);
    }
    iconOBJ[iconobjname] = [myTransform];
    myObject = JSON.stringify(iconOBJ);
    saveLocal('iconOBJ', myObject);
}

function deleteFromObject(keyToDelete, mobj) {

    var myObject;
    $.each(mobj, function (delkey, delvalue) {
        if (delkey === keyToDelete) {
            delete mobj[delkey];
        }
    });
    myObject = JSON.stringify(mobj);
    saveLocal('iconOBJ', myObject);
}


function closethisapp(appdelkey) {
    iconOBJ = JSON.parse(loadLocal('iconOBJ'));
    $('#' + appdelkey).remove();
    //closehelper(); //keep open to delete more apps
    deleteFromObject(appdelkey, iconOBJ);
}



//////////////////////////////////////

function scaleobj(sce, sct) {
    var scn, scr, sci;
    scn = {};
    scr = loadLocal("scaleOBJ");
    if (scr !== null) {
        scn = JSON.parse(scr);
    }
    scn[sce] = [sct];
    sci = JSON.stringify(scn);
    saveLocal("scaleOBJ", sci);
}


////////////////////////
function colorobj(colorkey, colorvalue) {
    var mcolorobj, scolorobj, pcolorobj, strcolorobj;
    mcolorobj = {};
    scolorobj = loadLocal("colorOBJ");
    if (scolorobj !== null) {
        pcolorobj = JSON.parse(scolorobj);
        mcolorobj = pcolorobj;
    }
    mcolorobj[colorkey] = [colorvalue];
    strcolorobj = JSON.stringify(mcolorobj);
    saveLocal("colorOBJ", strcolorobj);
}

function shadowobj(shadowkey, shadowvalue) {
    var shobj, savesobj, pshadowobj, strshadowobj;
    shobj = {};
    savesobj = loadLocal("shadowOBJ");
    if (savesobj !== null) {
        pshadowobj = JSON.parse(savesobj);
        shobj = pshadowobj;
    }
    shobj[shadowkey] = [shadowvalue];
    strshadowobj = JSON.stringify(shobj);
    saveLocal("shadowOBJ", strshadowobj);
}



/////////////////////
function opacityobj(elopacityobj, elopacityname) {
    var sopacityobj, svdopacityobj, prsdopacityobj, opacityobjstring;
    sopacityobj = {};
    svdopacityobj = loadLocal("opacityOB");
    if (svdopacityobj !== null) {
        prsdopacityobj = JSON.parse(svdopacityobj);
        sopacityobj = prsdopacityobj;
    }
    sopacityobj[elopacityobj] = [elopacityname];
    opacityobjstring = JSON.stringify(sopacityobj);
    saveLocal("opacityOB", opacityobjstring);
}

/////////////////////
function alignobj(elalignname, elalignval) {
    var storedalignobj, prsedalignobj, mainalignobj, mainalignstring;
    mainalignobj = {};
    storedalignobj = loadLocal("alignOB");
    if (storedalignobj !== null) {
        prsedalignobj = JSON.parse(storedalignobj);
        mainalignobj = prsedalignobj;
    }
    mainalignobj[elalignname] = [elalignval];
    mainalignstring = JSON.stringify(mainalignobj);
    saveLocal("alignOB", mainalignstring);
}


////////////////////

//iWidget
function openiwidget(iwidgetscreen){
    getiwidgetsize(iwidgetscreen);
    $('.iwidget').remove();
}

function loadiwidgets(widget, width, height) {
    var widgetname, objiwidget, savedwidget, name, preparedwidget, container, swipecontain, link, widgetframe, widgetdiv, moverdiv, isLocked;
    widgetname = widget.replace(/\s+/g, '');
    widgetname = widgetname.replace(/[^\w\s]/g, '');

    objiwidget = {};
    savedwidget = loadLocal('objiwidgets');
    if (savedwidget !== null) {
        objiwidget = JSON.parse(savedwidget);
    }
    name = widgetname;
    objiwidget[name] = widget + ',' + width + ',' + height;
    preparedwidget = JSON.stringify(objiwidget);
    saveLocal('objiwidgets', preparedwidget);


    container = getEL('iwidgetcontainer');
    $('<div id="' + widgetname + '" style="position:absolute;" class="noswipe" class="iwidgetclass"></div>').appendTo(container);
    swipecontain = getEL(widgetname);
    $('<div id="iwidgetswipe' + widgetname + '" style="position:absolute; "></div>').appendTo(swipecontain);

    link = "file:///var/mobile/Library/iWidgets/" + widget + "/Widget.html";
    widgetframe = document.createElement('iframe');
    widgetframe.frameBorder = 0;
    widgetframe.style.left = "0px";
    widgetframe.style.position = "absolute";
    widgetframe.style.width = width + "px";
    widgetframe.style.height = height + "px";
    widgetframe.style.backgroundColor = "transparent";
    widgetframe.id = widgetname + "iframes";
    widgetframe.setAttribute("src", link);
    widgetframe.setAttribute("class", "iwidgetclass");
    getEL("iwidgetswipe" + widgetname).appendChild(widgetframe);

    $('#iwidgetswipe' + widgetname).css({
        'height': '' + height + 'px',
        'width': '' + width + 'px',
        'background-color': 'rgba(255,255,255,0.0)', //woo! set background color to size widgetframe
        'overflow': 'hidden'
    });

    widgetdiv = getEL(widgetname);
    moverdiv = document.createElement("div");
    moverdiv.style.zIndex = "10";
    moverdiv.style.width = width + "px";
    moverdiv.style.height = height + "px";
    moverdiv.style.backgroundColor = "transparent";
    moverdiv.id = widgetname + "mover";
    widgetdiv.appendChild(moverdiv);

    $("#" + widgetname + "mover").css({
        'z-index': '100',
        'height': '50px',
        'top': '10px',
        'position': 'absolute',
        'background-color': 'transparent'
    });

    $("#" + widgetname + "mover").css("width", width);

    $("#" + widgetname).css({
        'z-index': '4',
        'position': 'absolute',
        'top': '100px',
        'padding-bottom': '40px',
        'left': '0px',
        'background-color': 'red'
    });
    $("#" + widgetname).addClass(' widget');

    isLocked = loadLocal('locked');
    if (isLocked !== null) {} else {
        $("#" + widgetname).touch();
    }
}


function getwidgetvalues(wkey, valueiw) {
    var wname, wwidth, wheight;
    valueiw = valueiw.split(',');
    wname = valueiw[0];
    wwidth = valueiw[1];
    wheight = valueiw[2];
    loadiwidgets(wname, wwidth, wheight);
}

function deletewidget() {
    var wcurel, savedwwidget, newsaves, objiwidget;
    wcurel = loadLocal('curel');
    $('#' + wcurel).remove();
    savedwwidget = loadLocal('objiwidgets');
    if (savedwwidget !== null) {
        objiwidget = {};
        objiwidget = JSON.parse(savedwwidget);
    }
    delete objiwidget[wcurel];
    newsaves = JSON.stringify(objiwidget);
    saveLocal('objiwidgets', newsaves);
    closehelper();
}

//////////////////////////

//Drag Elements
function dragobj(name, myTransform) {
    var dragmatrix, dragvalues, draga, dragb, dragangle, dragOBJ, myDragObject, dragsavedobj;
    dragmatrix = $('#' + name).css('-webkit-transform');
    if (dragmatrix !== "none") {
        dragvalues = dragmatrix.split('(')[1].split(')')[0].split(',');
        draga = dragvalues[0];
        dragb = dragvalues[1];
        dragangle = Math.round(Math.atan2(dragb, draga) * (180 / Math.PI));
        saveLocal(name + 'defaultrotation', dragangle);
    }
    dragOBJ = {};
    dragsavedobj = loadLocal('dragOBJ');
    if (dragsavedobj !== null) {
        dragOBJ = JSON.parse(dragsavedobj);
    }
    dragOBJ[name] = [myTransform];
    myDragObject = JSON.stringify(dragOBJ);
    saveLocal('dragOBJ', myDragObject);
}



function taphold(elemt) {
    var dblelement, tapwidgetornot, curelt, tapiconsornot, tstyle, tmatrix, tp, helperDiv;
    dblelement = elemt;
    helperDiv = getEL('helper');

    if (hazClass(getEL(elemt),'createditem')) {
        getEL('delete').style.display = 'block';
    } else {
        getEL('delete').style.display = 'none';
    }
     if (hazClass(getEL(elemt),'widget')) {
        getEL('delete2').style.display = 'block';
    } else {
        getEL('delete2').style.display = 'none';
    }

    if (elemt === "icon") {
        getEL('changeweatherico').style.display = 'block';
    } else {
        getEL('changeweatherico').style.display = 'none';
    }
    if(elemt == "dpad"){

    }

    else if (elemt === "iconlist") { //close list for icon select
        getEL(elemt).style.display='none';
        window.location = window.location.href;
    }
     else if (elemt === "iwidget") {
        $('.iwidget').css('display', 'none');
        unblurbackground();
    }
    else if (elemt === "overlays") {
        $('.overlays').css('display', 'none');
        unblurbackground();
    }
    else if (elemt === "filemenus"||elemt === "filemenus2"||elemt === "filemenus3"||elemt === "filemenus4") {
        getEL(elemt).style.display = 'none';
        unblurbackground();
    }
    else if (elemt === "fontmenuone") {
        fontpage('close');
        $('#fontmenuone').empty();
    }
    else if (elemt === "lockscreens") { //GL
        [].forEach.call( document.querySelectorAll('.lockscreen'), function(elmt) {
            elmt.style.display = 'none';
        });
        unblurbackground();
    } else if (elemt === "weathericonsmenu") {
        getEL(elemt).style.display = 'none';
        unblurbackground();
        $('#weathericonsmenu').empty();
    } else if (elemt === "loadthemes") {
        window.location = window.location.href;

    }else if (elemt === "animations") {
        getEL(elemt).style.display = 'none';
        unblurbackground();
        $("#animations").empty();
        $(".animations").empty();

    } else {
        curelt = localStorage.getItem('curel');
        localStorage.setItem('curicon',curelt);
        if (hazClass(getEL(curelt),'iconcan')) {
            $('.closer').css('display', 'block');
            getEL('changeico').style.display = 'block';
        }
        else{}
        saveLocal('helperel', dblelement);
        //tstyle = window.getComputedStyle(getEL(dblelement));
        //tmatrix = new WebKitCSSMatrix(tstyle.webkitTransform);
        //helperDiv.style.top = tmatrix.f - 30 + "px"

        //if (hazClass(curelt,'widget')) {
          //  helperDiv.style.top = tmatrix.f - 80 + "px"
        //}
        //tp = helperDiv.style.top;
        //tp = tp.slice(0, -2);
        //if (tp <= 60) {
          //  helperDiv.style.top = '30px';
        //}
        //if (hazClass(getEL(curelt),'iconcan')) {
           //helperDiv.style.top = '150px';
        //}
       showhelper();
     dragging = true;
     }
}

//Start if Item is held for 1000 ms show helper
var myVar;
function starttimer(id) {
    myVar = setTimeout(function () {
        taphold(id);
    }, 1000);

}

function endtimer() {
    clearTimeout(myVar);
}

//load lockscreen on top of wallpaper

function openlock(lockscreen){
  //  localStorage.removeItem("userbg");
  $('#movelocksmenu').css('display','none');
    saveLocal('lockscreenchosen', lockscreen);
    setTimeout(function(){ window.location = window.location.href; }, 300);
}


function loadlock(ls) {
    var iframea, iframea2, gld;
    iframea = document.createElement("iframe");
    iframea.id = "lockscreen";
    iframea2 = document.createElement("lockscreen");
    iframea2.frameBorder = "0";
    iframea.src = "file:///var/mobile/Library/GroovyLock/" + ls + "/LockBackground.html";
    iframea.style.backgroundColor = "transparent";
    iframea.frameBorder = "0";
    iframea.allowTransparency = "true";
    gld = getEL("locksa");
    gld.frameBorder = "0";
    gld.appendChild(iframea);
    iframea = null;
    gld = null;
}

//lock elements and set elements to be touch/draggable
function lock() {
    var isLocked;
    isLocked = loadLocal('locked');
    if (isLocked !== null) {
        localStorage.removeItem('locked');
        setTimeout(function () {
            window.location = window.location.href;
        }, 100);
    } else {
        saveLocal('locked', 'yes');
        setTimeout(function () {
            window.location = window.location.href;
        }, 100);

    }
}

function openanimations(name){
    saveLocal('animations', name);
    setTimeout(function(){ window.location = window.location.href; }, 300);
}


function stopanimations(){
    localStorage.removeItem('animations');
    localStorage.removeItem('hiddenbg');
    getEL('background').style.visibility="visible";
    setTimeout(function(){ window.location = window.location.href; }, 500);

}

function loadanimation(ani) {
    var iframea, iframea2, gld;
    iframea = document.createElement("iframe");
    iframea.id = "lockscreen";
    iframea.src = "file:///var/mobile/Library/LBEvoAnimations/" + ani + "/index.html";
    iframea.style.backgroundColor = "transparent";
    iframea.frameBorder = "0";
    iframea.allowTransparency = "true";
    gld = getEL("anisc");
    gld.frameBorder = "0";
    gld.appendChild(iframea);
    iframea = null;
    gld = null;
}



//clear entire screen
function clearls() {

    swal({   title: "Reset",   text: "Clear current lockscreen?",   type: "warning",   showCancelButton: true,   confirmButtonColor: "#DD6B55",   confirmButtonText: "Yes, remove it!",   closeOnConfirm: false }, function(){

  var lsarray = ["access","locked","animations","hiddenbg","movemenudefaultrotation","loadthemesdefaultrotation","newsave","curel","opacityOB","daydefaultrotation","fontOBJ","randomsave","iconOBJ","hideOBJ","userbg","themesdefaultrotation","alignOB","dragOBJ","createdobjcreate","overlay","shadowOBJ","iwidgetscrollbardefaultrotation","datedefaultrotation","colorOBJ","scaleOBJ","iconimgOBJ","newsave","objiwidgets","newiconimgOBJ","iconset","lockscreenchosen","helperel","capsOBJ"];
        var lsarrayLength = lsarray.length;
        for (var ew = 0; ew < lsarrayLength; ew+=1) {
              localStorage.removeItem(lsarray[ew]);
        }
        for (var key in localStorage){
          var rotationkey=key.slice(-15);
          if(rotationkey=="defaultrotation"){
            localStorage.removeItem(key);
          }
        }
             //for (var key in localStorage){
                //alert(key);
            //}
        window.location = window.location.href;

       });

}

function clearsb(){
        swal({   title: "Reset",   text: "Clear current springboard?",   type: "warning",   showCancelButton: true,   confirmButtonColor: "#DD6B55",   confirmButtonText: "Yes, remove it!",   closeOnConfirm: false }, function(){
        var sbarray = ["newiconimgOBJSB","opacityOBSB","fontOBJSB","userbgSB","objiwidgetsSB","alignOBSB","dragOBJSB","widgetSB","overlaySB","lockscreenchosenSB","iconOBJSB","iconimgOBJSB","iconsetSB","scaleOBJSB","createdobjcreateSB","colorOBJSB","shadowOBJSB","hideOBJSB","iconsetSB"];
        var sbarrayLength = sbarray.length;
        for (var i = 0; i < sbarrayLength; i++) {
           localStorage.removeItem(sbarray[i]);
        }
        reloadSB();
    });
}

function masterreset(){
    swal({   title: "Reset",   text: "Warning this will reset everything!",   type: "warning",   showCancelButton: true,   confirmButtonColor: "#DD6B55",   confirmButtonText: "Yes, remove it!",   closeOnConfirm: false }, function(){
        localStorage.clear();
        reloadSB();
        window.location = window.location.href;
    });
}
   // var answer = confirm("Clear all Stored info? Press cancel to choose between clearing LockScreen or Springboard.")
    //if (answer){
      //  localStorage.clear();
        //window.location = window.location.href;
    //}
    //else{
      //  var secondanswer = confirm('Press ok to clear Lockscreen, press cancel to clear Springboard. If your theme isnt saved it will be lost');
    //}
   // if(secondanswer){
     //   var lsarray = ["access","locked","animations","hiddenbg","movemenudefaultrotation","loadthemesdefaultrotation","newsave","curel","opacityOB","daydefaultrotation","fontOBJ","randomsave","iconOBJ","hideOBJ","userbg","themesdefaultrotation","alignOB","dragOBJ","createdobjcreate","overlay","shadowOBJ","iwidgetscrollbardefaultrotation","datedefaultrotation","colorOBJ","scaleOBJ","iconimgOBJ","newsave","objiwidgets","newiconimgOBJ","iconset","lockscreenchosen","helperel","capsOBJ"];
       // var lsarrayLength = lsarray.length;
       // for (var ew = 0; ew < lsarrayLength; ew+=1) {
             // localStorage.removeItem(lsarray[ew]);
       // }
       // for (var key in localStorage){
         // var rotationkey=key.slice(-15);
         // if(rotationkey=="defaultrotation"){
           // localStorage.removeItem(key);
         // }
       // }
             //for (var key in localStorage){
                //alert(key);
            //}
        //window.location = window.location.href;
    //}
    //else{
      //  var sbarray = ["newiconimgOBJSB","opacityOBSB","fontOBJSB","userbgSB","objiwidgetsSB","alignOBSB","dragOBJSB","widgetSB","overlaySB","lockscreenchosenSB","iconOBJSB","iconimgOBJSB","iconsetSB","scaleOBJSB","createdobjcreateSB","colorOBJSB","shadowOBJSB","hideOBJSB","iconsetSB"];
        //var sbarrayLength = sbarray.length;
        //for (var i = 0; i < sbarrayLength; i++) {
     //       localStorage.removeItem(sbarray[i]);
       // }
        //reloadSB();
   // }
//}


function reloadSB(){
    randomsave=Math.floor(Math.random()*101);
    saveLocal('randomsave',randomsave);
    window.location = window.location.href;
}


function speakomightyone(foo) {
     swal({   title: "Speech",   text: "Speech is not available sorry.",   confirmButtonColor: "#393939" });
   // window.speechSynthesis.speak(foo);
}

var speaker = 0;
function speaknow() {
    var pitchRange, rateRange, volRange, langRadio, foo, sptxt, extended, valuesp;
    speaker += 1;
    if (speaker === 2) {
        window.speechSynthesis.cancel();
        speaker = 0;
    }
    if (speaker === 1) {
        pitchRange = getEL('pitch');
        rateRange = getEL('rate');
        volRange = getEL('volume');


        if (json.StandardObservation.text.value === undefined) {
            extended = json.HiradObservation.text;
        } else {
            extended = json.StandardObservation.text;
        }


        valuesp = "Hello, It is currently " + json.StandardObservation.temp + "degrees" + "in" + json.Location.city + "       " + "Conditions are  " + extended;
        $('input[name=textco]').val('' + valuesp);
        langRadio = document.querySelector('input[type=radio]:checked');
        sptxt = getEL('sayit').value;
        foo = new SpeechSynthesisUtterance(sptxt);
        foo.lang = langRadio.value;
        foo.pitch = pitchRange.value;
        foo.rate = rateRange.value;
        foo.volume = volRange.value;
        speakomightyone(foo);
    }
}


function openweathericon() {
    blurbackground();
    $('#weathericonsmenu').touch();
    $('#weathericonsmenu').css('display', 'block');
    var weathericonarray=["lines", "shadow", "deep", "nude","simply","playful","realicons","reddock", "clima","swhite", "GlowWhite","MNMLBW","MNMLB","Sk37ch","primusweather","plastic","mw","stardock","june","round","simple","black","weathercom","toon","toon2","yahoo","round2","topaz","blue","smash","blacky","mauri","mauri2","shiny","BlackOrange","six","sixtynine","Flex","wetter",'Klear','Purcy'];

    for (i = 0; i < weathericonarray.length; i++) {
      $("#weathericonsmenu").append('<div id='+weathericonarray[i]+' onclick="seticonss(\''+weathericonarray[i]+'\')"><img src="images/weather/'+weathericonarray[i]+'.png"width="40"></div>  ');
    }
    closehelper();

}

function seticonss(eicons) {
    $('#weathericonsmenu').css('display', 'none');
    unblurbackground();
    $('#weathericonsmenu').empty();
    saveLocal("iconset", eicons);
    showdata();
}

function killls() {
    localStorage.removeItem('lockscreenchosen');
    window.location.href = window.location.href;
}



function closeoverlay() {
    localStorage.removeItem('overlay');
    $('#overlay').css('display', 'none');
}

function showwidgetmenu() {
    $('#premenu').css('display', 'none');
    $('#widgetmenu').css('display', 'block');
}

function startani() {
    var widgetan;
    $('#widgetmenu').css('display', 'none');
    $('#background,#weather,.icons,#locksa').css('left', '0px');
    widgetan = loadLocal('widget');
    if (widgetan !== null) {
        localStorage.removeItem('widget');
        setTimeout(function () {
            window.location.reload();
        }, 10);
    } else {
        widgetan = "animated";
        saveLocal('widget', widgetan);
        setTimeout(function () {
            window.location.reload();
        }, 10);
    }
}
//////////////////

function openfonts() {
    var fmenu = $('#fontmenuone');
    var fm;
    fm = fmenu.css("display");
    if (fm === "none") {
        fmenu.css("display", "block");
    } else {
        fmenu.css("display", "none");
    }
    closehelper();
    var fontarray = ["Stock","HalloThick","HalloLight","Hallo","BebasBold","Bebas","BebasLight","BebasThin","OdinBold", "Odin","OdinLight","Wolf","WolfLight", "Penna","Sifon", "Talldark", "Signerica", "Deep", "Signa", "DigitalLCD", "Ozone", "WildPrint", "PeachCream", "Tragic", "Cubos", "Doodle", "Trench", "Seriously", "Comic", "Dripping", "Nero", "Geosans", "OStrich", "Roboto", "Steelfish", "BootsF", "BootsS", "Give You Glory", "Poiret One", "Tulpen One", "Metrophobic", "Bubbler One", "Orbitron", "Voltaire", "Dosis", "Righteous", "Londrina Shadow", "Nothing You Could Do", "Nosifer", "Shojumaru", "Swanky and Moo Moo", "Keania One", "Pompiere", "Josefin Slab", "Sniglet", "Pathway Gothic One", "Raleway", "Jockey One", "Amatic SC", "Marcellus SC", "Syncopate", "Questrial", "Atomic Age", "Montserrat Alternates", "Crushed", "Annie Use Your Telescope", "Bigelow Rules", "Monoton", "Fascinate", "Indie Flower", "Gloria Hallelujah", "Comfortaa", "anton", "hammersmith", "changa", "megrim", "meta", "game", "bowlby", "rdots", "joti", "rubik", "neuropol", "bgothic", "close"];
    var preList = "";
    for (i = 0; i < fontarray.length; i++) {
        preList += '<li onclick="appendfont(\'' + fontarray[i] + '\')" style="font-family:' + fontarray[i] + ';">' + fontarray[i] + '</li>';
    }
    fmenu.append(preList);
    fmenu.touch();
   // $('#fontmenuone li').click(function(event) {
     //   val = $(this).html();
       // appendfont(val);
    //});
    fontarray = null;
    preList = null;
}





function fontobj(fontname, fontvalue) {
    var fontmainobj, fontsavedobj, fontprsdobj, fontstringobj;
    fontmainobj = {};
    fontsavedobj = loadLocal("fontOBJ");
    if (fontsavedobj !== null) {
        fontprsdobj = JSON.parse(fontsavedobj);
        fontmainobj = fontprsdobj;
    }
    fontmainobj[fontname] = [fontvalue];
    fontstringobj = JSON.stringify(fontmainobj);
    saveLocal("fontOBJ", fontstringobj);
}

function loadfont(fvalue) {
    var curfontel;
    curfontel = loadLocal("helperel");
    $("#" + curfontel).css("font-family", fvalue);
    fontobj(curfontel, fvalue);
}

function applyfonts() {
    var namefont;
    namefont = $("#font").val();
    if (namefont !== "Font") {
        loadfont(namefont);
    }
}

function appendfont(appendft) {
    if(appendft == "close"){
        fontpage('close');
    }
        else{
    $("#font").val(appendft);
    loadfont(appendft);
    }
}

function fontpage(closeval) {
    if (closeval === "close") {
        $("#fontmenuone").empty();
        $("#fontmenuone").css("display", "none");
    }
}





function closeicons(){ //close icon list when press hold on scroller
  $('#iconlist').css('display','none');
  $('#scrollbar').css('display','none');
  unblurbackground();

}



function setapp(bundle,iconimg){
  $('#background').css('left','0px');
                $('#newitems').css('left','0px');
                $('#iwidgetcontainer').css('left','0px');
                $('#weatherelements').css('left','0px');
                $('#locksa').css('left','0px');
                $('.icons').css('left','0px');
                $('#premenu').css('display','none');

                $('#lsmenu').css('display','none');
                $('#iconmenu').css('display','none');
                $('#overlay').css('left','0px');

    //$('#iconlist').css('display','none');
    //unblurbackground();

    if (bundle == "libactivator") {
  bundle = "com.apple.activator"
    }
    if (bundle == "com.pandora") {
  bundle = "com.apple.pandora"
    }
    if (bundle == "com.in-notes") {
  bundle = "com.apple.innotes"
    }

    var idname=bundle.split('.');//split to get app name

    //imgsrc= $('#'+idname[2]+'img').children("img").attr("src");
    var imgsrc=iconimg;
//add custom icons images
    if(bundle=="com.apple.mobilephone"){
      imgsrc="/Applications/MobilePhone.app/icon@2x~iphone.png";
    }


    if(bundle=="com.saurik.WinterBoard"){
        imgsrc="/Applications/WinterBoard.app/icon7@2x~ipad.png";}
        if(bundle=="com.apple.Music"){
        imgsrc="/Applications/Music.app/Icon-120.png";}
        if(bundle=="com.apple.MobileStore"){
        imgsrc="/Applications/MobileStore.app/iTunesStore120.png";}
        if(bundle=="com.apple.AppStore"){
        imgsrc="/Applications/AppStore.app/Appstore120.png";}
        if(bundle=="com.saurik.Cydia"){
        imgsrc="/Applications/Cydia.app/Icon-76~ipad.png";}
        if(bundle=="com.apple.videos"){
        icon="/Applications/Videos.app/Videos60@2x~iphone.png";}
        if(bundle=="eu.heinelt.ifile"){
        icon="/Applications/iFile.app/AppIcon76x76@2x.png";}
        if(bundle=="org.herf.iflux"){
        icon="/Applications/iflux.app/Icon@2x.png";}
        if(bundle=="com.harrisonapps.Pandora-Downloader"){
        icon="/Applications/Pandora Downloader.app/Icon@2x.png";}
        if(bundle=="com.pragmatixconsulting.packagebackup"){
        icon="/Applications/PKGBackup.app/AppIcon60x60@2x.png";}

    if(idname[2]=="Telegraph"){
      idname[2]="Telegram";
    }
    if(idname[2]===undefined){
      idname[2]="whoknows";
    }

    if ($('#'+idname[2]).length > 0) {
      $('#'+idname[2]).remove(); //remove from html
      deleteFromObject(idname[2],iconOBJ); //remove from object
    }
      else{


imageExists(icon, function(exists) {
  if(exists===false){
    icon="/System/Library/LockCydgets/LockBuilderEvo.cydget/libraries/img/icon.png";
  }
  if(exists===true){
    icon=icon;
  }
});

    var openbundle="'"+bundle+"'";
    linkFuncts = "closethisapp('" + idname[2] + "')";
   $(".icons").append('<div class="iconcan" id='+idname[2]+'></div>');
   $('#'+idname[2]).append('<center><div class="iconcan" id="b'+idname[2]+'"><img width="60" id="icon'+idname[2]+'" ontouchend="openapp('+openbundle+')"  class="iconimages" src="' + imgsrc + '"></div></center><span id="closer' + idname[2] + '" class="closer">X</span>');
   closer=getEL("closer" + idname[2]);
    closer.setAttribute('onclick', linkFuncts);

isLocked=loadLocal('locked');
if(isLocked!==null){}
else{
 $('#'+idname[2]).touch();
}


iconname=idname[2];
iconobj(iconname,openbundle);
iconimgobj(iconname,imgsrc);
}
}



/////////////////////////
//controls

function opencolor() {
    var linktocolor, colorpickerframe;
    $('#colorpick').css('display', 'block');
     $('#colorpick').load('libraries/color/cp.html');
}

function changeval(which, color) {
    var curdiv, currentval, creatitems;
    if (which === "color") {
        curdiv = loadLocal('helperel');
        currentval = color;
        $('#colorpick').css('display', 'none');
        if (curdiv === "line" || curdiv === "thickline" || curdiv === "mediumline") {
            $('#' + curdiv).css('background-color', currentval);
            colorobj(curdiv, currentval);
        }
        creatitems = $("#" + curdiv).hasClass("createditem");
        if (creatitems === true) {
            $('#' + curdiv).css('background-color', currentval);
            colorobj(curdiv, currentval);
        } else {
            $('#' + curdiv).css('color', currentval);
            colorobj(curdiv, currentval);
        }
        $('#' + which).val(currentval);

    } else {
        currentval = prompt('Enter value', '');
        $('#' + which).val(currentval);
        if (which === "angle") {
            $('#rotate').click();
        } else {
            $('#scale').click();
        }
    }

}



$('#rotate').click(function () {
    var crtdiv, art, trt, crt, nrt, cssrt, divsrt, matrixrt, typert, nameofrt;
    crtdiv = loadLocal('helperel');
        art = +$('#angle')[0].value + ".001",
        trt = _T.rotate(art),
        crt = _T.fromString($('#' + crtdiv).css('transform')),
        nrt = crt.x(trt),
        cssrt = _T.toString(nrt);

    $('#' + crtdiv).css({
        transform: cssrt
    });
    divsrt = $('#' + crtdiv);
    matrixrt = $('#' + crtdiv).css('-webkit-transform');
    typert = "touch";
    nameofrt = crtdiv;
    dragobj(nameofrt, matrixrt);

});

$('#scale').click(function () {
    var csdiv, scle, iconsornot, widgetornot;
    csdiv = loadLocal('helperel');
    scle = $('#size')[0].value;

    if (csdiv === "line" || csdiv === "thickline" || csdiv === "mediumline") {
        $('#' + csdiv).css('height', scle + "px");
    }
    if (csdiv === "icon") {
        $('#' + csdiv + 'img').css('width', scle + "px");
    } else {
        $('#' + csdiv).css('font-size', scle + "px");
    }
    if(csdiv==="day1icon"||csdiv==="day2icon"||csdiv==="day3icon"||csdiv==="day4icon"){
        $('#' + csdiv + 'i').css('width', scle + "px");
    }

    iconsornot = $("#" + csdiv).hasClass("iconcan"); //if icon move to 150
    if (iconsornot === true) {
        $('#icon' + csdiv).css('width', scle + 'px');
    }

    widgetornot = $("#" + csdiv).hasClass("widget");
    if (widgetornot === true) {
        if (scle >= 2) {
           swal({   title: "Too big!",   text: "Widgets can only be scaled from 0.0 to 1.9.",   confirmButtonColor: "#393939" });
        } else {
            $('#' + csdiv).css({
                '-webkit-transform': 'scale(' + scle + ')'
            });
        }

    }
    if(csdiv === "forecast"){
        if (scle >= 2) {
           swal({   title: "Too big!",   text: "Forecast can only be scaled from 0.0 to 1.9.",   confirmButtonColor: "#393939" });
        } else {
            $('#' + csdiv).css({
                '-webkit-transform': 'scale(' + scle + ')'
            });
        }

    }
    scaleobj(csdiv, scle);
});


function opencontrols(){
    $('#dpad').load('libraries/control/control.html');
}


function closeshtml(){
    $('#shadowpicker').remove();
    $('#shadowpick').css('display','none');
    cdiv = loadLocal('helperel');
    shadow = loadLocal('fullblur');
    shadowobj(cdiv, shadow);
}

function changesdows(){
    colorvar = loadLocal('scolor');
    if(colorvar===null){
        colorvar="#1d1d1d";
        saveLocal('scolor','#1d1d1d');
    }
    cdiv = loadLocal('helperel');
    h=loadLocal("horizontal");
    v=loadLocal("vertical");
    b=loadLocal("blurs");
    if(h===null){h=0;}
    if(v===null){v=0;}
    if(b===null){b=0;}
    h=h+"px";
    v=v+"px";
    b=b+"px";
    shadow1=loadLocal('shadow1');
    shadow2=loadLocal('shadow2');
    shadow3=loadLocal('shadow3');
    shadow4=loadLocal('shadow4');
    if(shadow1!==null&&shadow2===null){
        shadow=shadow1+","+h + " " + v + " " + b + " " + colorvar;
    }
    else if(shadow2!==null&&shadow3===null){
        shadow=shadow1+","+shadow2+","+h + " " + v + " " + b + " " + colorvar;
    }
    else if(shadow3!==null&&shadow4===null){
        shadow=shadow1+","+shadow2+","+shadow3+","+h + " " + v + " " + b + " " + colorvar;
    }
    else if(shadow4!==null){
        shadow=shadow1+","+shadow2+","+shadow3+","+shadow4+","+h + " " + v + " " + b + " " + colorvar;
    }
    else{
    shadow=h + " " + v + " " + b + " " + colorvar;
}
    saveLocal('fullblur',shadow);
    saveLocal('redoshadow',shadow);
    $('#' + cdiv).css('text-shadow', shadow);

}



function redoshadow(){
    cdiv1 = loadLocal('helperel');
     shadow1=loadLocal('redoshadow');
     $('#' + cdiv1).css('text-shadow', shadow1);

}

function opendropmenu() {
   var linktoframe, miframes;
    $('#shadowpick').css('display', 'block');
    $('#shadowpick').load('libraries/shadows/shadows.html');
    closehelper();
}

function scolor() {
    var scolors = prompt('Type color', '');
    saveLocal('scolor', scolors);
    $('#shadowcolor').css('color', scolors);
}









function closedropshadow() {

    $('#shadowcolor').css('display', 'none');

}


function changecaps(){
  var change;
  var curdiv = loadLocal('helperel');
  var capvalue=$("#"+curdiv).css('text-transform');
  if(capvalue=="uppercase"){
    change ="capitalize";
    $("#"+curdiv).css('text-transform',change);
    capsobj(curdiv,change);
  }
  else if (capvalue == 'none'){
  change = "uppercase";
  $("#"+curdiv).css('text-transform',change);
  capsobj(curdiv,change);
  }
  else if(capvalue == 'capitalize'){
    change = "uppercase";
  $("#"+curdiv).css('text-transform',change);
  capsobj(curdiv,change);
  }
  else{
     change ="capitalize";
    $("#"+curdiv).css('text-transform',change);
    capsobj(curdiv,change);
  }
}



//caps Elements
function capsobj(name, myTransform) {
    capsOBJ = {};
    capssavedobj = loadLocal('capsOBJ');
    if (capssavedobj !== null) {
      if(capssavedobj=="undefined"){}
      else{capsOBJ = JSON.parse(capssavedobj);}
    }
    capsOBJ[name] = [myTransform];
    mycapsObject = JSON.stringify(capsOBJ);
    saveLocal('capsOBJ', mycapsObject);
}




//Opacity input
$(function () {
    var el, newPoint, newPlace, offset, width;
    $("input[type='range']").change(function () {
        el = $(this);
        width = el.width();
        newPoint = (el.val() - el.attr("min")) / (el.attr("max") - el.attr("min"));
        offset = 15;
        if (newPoint < 0) {
            newPlace = 0;
        } else if (newPoint > 1) {
            newPlace = width;
        } else {
            newPlace = width * newPoint + offset;
            offset -= newPoint;
        }
        el
            .next("output")
            .css({
                left: newPlace,
                marginLeft: offset + "%"
            })
            .text(el.val());
    });
});


var mainbg=loadLocal("userbg");
if(mainbg===null){
getBase64FromImageUrl("/var/mobile/Library/SpringBoard/LockBackgroundThumbnail.jpg");

}
function getBase64FromImageUrl(URL) {
    var img = new Image();
    img.src = URL;
    img.onload = function () {
    var canvas = document.createElement("canvas");
    canvas.width =this.width;
    canvas.height =this.height;
    var ctx = canvas.getContext("2d");
    ctx.drawImage(this, 0, 0);
    var dataURL = canvas.toDataURL("image/png");
    canvas=null;
    saveLocal('userbg',dataURL);
    if(URL=="/var/mobile/Library/SpringBoard/LockBackgroundThumbnail.jpg"){
      wall=loadLocal('userbg');
      cw=getEL("background");cw.style.backgroundImage="url("+wall+")";
  }

    };
}

function weatherwalls() {
    closemenu();
    var issaved = loadLocal('weatherwalls');
    if (issaved == 'yes') {
        localStorage.removeItem('weatherwalls');
        swal({
            title: "Weather",
            text: "Weather walls disabled, please set a wallpaper from camera roll.",
            type: "info",
            showCancelButton: false,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Ok",
            closeOnConfirm: true
        }, function() {
            location.reload();
        });
    } else {
        saveLocal('weatherwalls', 'yes');
        swal({
            title: "Weather",
            text: "Please select Wallpaper Folder. Add your own wallpapers to var/mobile/Library/LBEvoWeatherWalls.",
            type: "info",
            showCancelButton: false,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Ok",
            closeOnConfirm: true
        }, function() {

            CWeatherWall();

        });
    }
}



var weatherwallpapers=loadLocal('weatherwalls');
if(weatherwallpapers!==null){
  weatherwall="yes";
  //getBase64FromImageUrl("images/wallpaper.jpg");
}



function opensite(){
    var ntim = new Date().getTime();
  closemenu();
  blurbackground();
  //hidestatusbar();
  getEL('background').style.display="block";
  getEL('site').style.display = "block";
$('#site').load('http://junesiphone.com/LBEVO.html?cache='+ntim);
}

function hidebg(){getEL('background').style.visibility="hidden";}


////////////////// Start Apps ////////////////
localStorage.removeItem('system');
localStorage.removeItem('user');
function findicons(kind) {
    $('#iconlist').touch();
    getEL('background').style.display="block";
    var systemsaved = loadLocal('system');
    var usersaved = loadLocal('user');
    var applist = getinstall();
    if (systemsaved == kind) {
        closemenu();
        getEL('Iconlist').style.display = "block";

    } else if (usersaved == kind) {
        closemenu();
        getEL('Iconlist').style.display = "block";

    } else {
        closemenu();
        var system = applist.System;
        var user = applist.User;
        if (kind == "user") {
            systembundle = getuser(user);
        } else {
            systembundle = getuser(system);
            last = getvalue(system,systembundle,51); //mail app
        }
        var allapps = systembundle;
        for (var i = 0; i < allapps.length; i++) {
            try {
                checkapps(i);
            } catch (err) {}


        }

        function checkapps(i) {
            if (kind == "user") {
                var kindofapp = "user";
                var appbundle = getvalue(user,systembundle,i);
                var apppath = appbundle.Path; //icon path
            } else {
                var kindofapp = "system";
                var appbundle = getvalue(system,systembundle,i);
                var apppath = appbundle.Path; //icon path
            }

            var nam = allapps[i];

            // Some apps dont follow com.apple.bla fix them here.
            if (nam == "libactivator") {
                nam = "com.apple.activator"
            };
            if (nam == "com.pandora") {
                nam = "com.apple.pandora"
            };
            if (nam == "com.in-notes") {
                nam = "com.apple.innotes"
            };
            if (nam == "D4D2433BGC") {
                nam = "com.apple.weirdo"
            };
            if (nam == "com.chase") {
                nam = "com.apple.chase"
            };
            if (nam == "com.udemy") {
                nam = "com.apple.udemy"
            };
            if (nam == "com.directed.viper") {};

            nam = nam.split('.');
            fullicon = apppath + "/" + "AppIcon60x60@2x.png";

            //alert("name"+nam[2]+"bundle"+allapps[i]+"icon"+fullicon);
            createli(nam[2], allapps[i], fullicon, kindofapp); //create list of apps
            //alert(nam[2]+allapps[i]+fullicon+kindofapp);
        }
    }

    if (kind == "user") {} else {
        var systemsaves = loadLocal('system');
        if (systemsaves == null) {
            createphoneapp();

            function createphoneapp() {
                var nn1 = "Phone";
                var na1 = "com.apple.mobilephone";
                var ni1 = "/Applications/MobilePhone.app/icon@2x~iphone.png";
                var nk1 = "system";
                createli(nn1, na1, ni1, nk1);
            }

        }
    }
}

////////////////////////////////////////////////

/////////////////////////
function createli(app, bundle, icon, appkind) {
    //manual fixes
    if(bundle == "com.apple.MobileStore"){
        cutDirectory = icon.slice(0,-19);
        newIcon = cutDirectory+"iTunesStore120.png";
        icon = newIcon;
    }
    else if(bundle == "com.apple.camera"){
        cutDirectory = icon.slice(0,-19);
        newIcon = cutDirectory+"Camera@2x~iphone.png";
        icon = newIcon;
    }
    else if(bundle == "com.apple.mobileslideshow"){
        cutDirectory = icon.slice(0,-19);
        newIcon = cutDirectory+"Photos@2x~iphone.png";
        icon = newIcon;
    }
    else if(bundle == "com.apple.Maps"){
        cutDirectory = icon.slice(0,-19);
        newIcon = cutDirectory+"Icon-120.png";
        icon = newIcon;
    }
    else if(bundle == "com.apple.AppStore"){
        cutDirectory = icon.slice(0,-19);
        newIcon = cutDirectory+"Appstore120.png";
        icon = newIcon;
    }
    else if(bundle == "com.apple.mobiletimer"){
        cutDirectory = icon.slice(0,-19);
        newIcon = cutDirectory+"icon-about@2x.png";
        icon = newIcon;
    }
 if (app == "MailCompositionService" || app == "undefined" || app == "mobilesms" || app == "webapp" || app=="MobileReplayer" || app=="webapp1" || app=="family" || app == "Diagnostics" || app == "HealthPrivacyService" || app == "AskPermissionUI" || app == "PhotosViewService" || app == "TencentWeiboAccountMigrationDialog" || app == "InCallService" || app == "share"|| app=="CoreAuthUI" || app=="PreBoard" || app == "PrintKit" || app == "SharedWebCredentialViewService" || icon == "null" || app == "Social" || app == "mobilephone" || app == "CompassCalibrationViewService" || app == "ios" || app == "quicklook" || app == "QuickLook" || app == "iad" || app == "MusicUIService" || app == "WebContentFilter" || app == "Mobilesms" || app == "Mobileslideshow" || app == "purplebuddy" || app == "AccountAuthenticationDialog" || app == "AdSheetPhone" || app == "uikit" || app == "fieldtest" || app == "iosdiagnostics" || app == "FacebookAccountMigrationDialog" || app == "appleaccount" || app == "WebSheet" || app == "TrustMe" || app == "datadetectors" || app == "PassbookUIService" || app == "undefined" || app == "Undefined" || app == "gamecenter" || app == "Copilot" || app == "SiriViewService" || app == "DemoApp" || app == "WebViewService") {} else {

        if(fileExists(icon)){
            loadli(app, bundle, icon, appkind);
        }
        else{
                cutDirectory = icon.slice(0,-19);
                newIcon = cutDirectory+"iPhoneAppIcon@2x.png";

                    if(fileExists(newIcon)){
                        loadli(app, bundle, newIcon, appkind);
                    }
                    else{
                        checkiphoneapp(app,bundle,newIcon,appkind);
                    }
        }

    }

}



function checkiphoneapp(app, bundle, icon, kind) {
    if(fileExists(icon)){
        loadli(app, bundle, icon, kind);
    }
    else{
        newcutDirectory2 = icon.slice(0,-20);
        icon = newcutDirectory2+"icon@2x.png";
        if(fileExists(icon)){loadli(app,bundle,icon,kind);}
            else{
                newcutDirectory2 = icon.slice(0,-11);
                icon = newcutDirectory2+"Icon@2x.png";
                if(fileExists(icon)){loadli(app,bundle,icon,kind);}
                    else{
                        newcutDirectory2 = icon.slice(0,-11);
                        icon = newcutDirectory2+"icon.png";
                        if(fileExists(icon)){loadli(app,bundle,icon,kind);}
                            else{
                                newcutDirectory2 = icon.slice(0,-8);
                                icon = newcutDirectory2+"icon@2x~iphone.png";
                                if(fileExists(icon)){loadli(app,bundle,icon,kind);}
                                    else{

                                        loadli(app,bundle,icon,kind);
                                    }
                            }
                    }
            }
    }
}


function imageExists(url, callback) { //function to check if images exists works 90% which is amazing.
  var img = new Image();
  img.onload = function() { callback(true); };
  img.onerror = function() { callback(false); };
  img.src = url;
}

function loadli(app,bundle,icon,appkind){
if(appkind=="system"){
saveLocal('system',appkind);
localStorage.removeItem('user');
$('.user').remove();
}
if(appkind=="user"){
  localStorage.removeItem('system');
  saveLocal('user',appkind);
  $('.system').remove();
}

$('#iconlist').css('display','inline-block');
  blurbackground();


imageExists(icon, function(exists) { // if image doesn't exist apple no image icon.
    var classname;
    if (exists === false) {
        icon = "/System/Library/LockCydgets/LockBuilderEvo.cydget/libraries/img/icon.png";
        classname = "pickicons";
        d = document.createElement('div');
        $(d).addClass(classname).html('</br><img class="' + appkind + '" id="' + app + 'img" style="margin-left:15px;border-radius: 5px;" width="60" height="60" src="' + icon + '" /></br><span id="applabels">'+app+'</span>').appendTo($('#iconlist')) //main div
            .click(function() {
                setapp(bundle, icon);
                $('#' + app + 'img').css('opacity', '0.5');
                //unblurbackground();

            });
    } else {
        classname = "pickicons";
        d = document.createElement('div');
        $(d).addClass(classname).html('</br><img class="' + appkind + '" id="' + app + 'img" style="margin-left:15px;border-radius: 5px;" width="60" height="60" src="' + icon + '" /></br><span id="applabels">'+app+'</span>').appendTo($('#iconlist')) //main div
            .click(function() {
                setapp(bundle, icon);
                $('#' + app + 'img').css('opacity', '0.5');
                //unblurbackground();
            });

    }
});








   /* a = document.createElement("a");
    a.href = "#";
    var element = document.createElement("img");
    element.setAttribute("src", icon);
    a.appendChild(element);
    a.setAttribute("id", app+"img");
    a.setAttribute('onclick', 'setapp('+bundle+');');
    a.appendChild(document.createTextNode(app));
    li = document.createElement("li");
    li.appendChild(a);
    li.setAttribute('ontouchend', 'setapp("'+bundle+'");');
    ul = getEL("iconlist");
    ul.insertBefore(li, getEL("iconclose"));
    */


  }


function lastapp(){
  var lasticon=getlastapp();

  if(lasticon===null){
    swal({   title: "App",   text: "There is no last app, this means you may have respring before opening an app.",   confirmButtonColor: "#393939" });
  }
  lasticon=JSON.stringify(lasticon).split(">");
  lasticon=lasticon[1].replace(/"/g, "");
  lasticon=lasticon.replace(/ /g,'');
  openapp(lasticon);
}

function savetheme(){
    var themename=prompt('Name your theme','');
        themename=themename.replace(/\s+/g, '');
    var LBEvo = mutabledict();
      setobject(LBEvo,loadLocal('locked'),"ElementsLocked");
      setobject(LBEvo,loadLocal('weatherwalls'),"WeatherWallsave");
      setobject(LBEvo,loadLocal('animations'),"Animation");
      setobject(LBEvo,SMStxt,"Smssv");
      setobject(LBEvo,MAILtxt,"Mailsv");
      setobject(LBEvo,PHONEtxt,"Phonesv");
      setobject(LBEvo,TWITTERtxt,"Twittersv");
      setobject(LBEvo,TWEETBOTtxt,"Tweetbotsv");
      setobject(LBEvo,WHATSAPPtxt,"Whatsappsv");
      setobject(LBEvo,loadLocal('capsOBJ'),"ElementCaps");
      setobject(LBEvo,loadLocal('dragOBJ'),"MainElements");
      setobject(LBEvo,loadLocal('hideOBJ'),"HideElements");
      setobject(LBEvo,loadLocal('iconimgOBJ'),"IconImages");
      setobject(LBEvo,loadLocal('iconOBJ'),"IconList");
      setobject(LBEvo,loadLocal('colorOBJ'),"ElementColors");
      setobject(LBEvo,loadLocal('fontOBJ'),"ElementFonts");
      setobject(LBEvo,loadLocal('opacityOB'),"ElementOpacity");
      setobject(LBEvo,loadLocal('scaleOBJ'),"ElementScale");
      setobject(LBEvo,loadLocal('userbg'),"Background");
      setobject(LBEvo,loadLocal('shadowOBJ'),"ElementShadow");
      setobject(LBEvo,loadLocal('lockscreenchosen'),"Lockscreen");
      setobject(LBEvo,loadLocal('newiconimgOBJ'),"CustomIcon");
      setobject(LBEvo,loadLocal('iconset'),"CustomWeatherIcon");
      setobject(LBEvo,loadLocal('objiwidgets'),"SelectediWidget");
      setobject(LBEvo,loadLocal('createdobjcreate'),"CreatedItem");
      setobject(LBEvo,loadLocal('overlay'),"WallOverlay");
      setobject(LBEvo,loadLocal('alignOB'),"ElementAlign");
   var saveDir = "/var/mobile/Library/LBEvoThemes/";
   var plistName = themename + ".plist";
   var filePath = saveDir+plistName;
   savedplist(LBEvo,filePath);
   window.location = window.location.href;
}

function openweather(){
  openapp("com.apple.weather");
}



var dragging = false; //make sure drag is false unless moved
function openapp(bundle){
    if(dragging===true){} //do nothing varible set in touch.js
      else{ //open app that is clicked
        var passcode=isPasscodeon();
        if(passcode===true){
          //unlockphone();
            openappBundle(bundle);
        }
        else{
         openappBundle(bundle);
        }
    }
}

loadObject = function(savobj,type){
    var parsed;
  if(savobj!==null){
    if(savobj.length>=2){
        if(savobj!='undefined'){
    parsed = JSON.parse(savobj);
    Object.keys(parsed).forEach(function (key) {
        var value = parsed[key];
        try{
            if(type == 'hide'){
                $('#'+key).css('display',value);
                 addappdoubleclick(key);
                 if(loadLocal('locked')!==null){}else{
                    $('#'+key).touch();
                 }
        }
                else if(type == 'opacity'){ getEL(key).style.opacity = value; }
                    else if(type == 'icon'){
                            $(".icons").append('<div class="iconcan" name="'+value+'" id=' + key + '></div>');
                                if (loadLocal('locked') !== null) {} else {$('#' + key).touch();}
                    }
                    else if(type == 'iconimg'){
                        if(checkKey(key)){
                            var bundle = getEL(key).getAttribute('name');
                            linkFuncts = "closethisapp('" + key + "')";

                            getEL(key).innerHTML = getEL(key).innerHTML+'<center><div class="iconcan" id="b' + key + '"><img ontouchend="openapp(' + bundle + ') " id="icon' + key + '" class="iconimages" src="' + value + '"></div></center><span id="closer' + key + '" class="closer" >X</span>';
                            closer = getEL("closer" + key);
                            closer.setAttribute('onTouchEnd', linkFuncts);
                         }
                    }
                    else if(type == 'newiconimg'){
                        if (checkKey(key)) {
                            $('#b' + key + ' .iconimages').attr('src', value);
                        } else {}
                    }
                    else if(type == 'scale'){
                        if(checkKey(key)){
                            if (key === "line" || key === "thickline" || key === "mediumline") {
                                getEL(key).style.height = value+"px";
                            }

                             if (key === "icon") {
                                getEL(key+'img').style.width = value+'px';
                            }
                            if (key === "day1icon" || key === "day2icon" || key === "day3icon" || key === "day4icon") {
                                getEL(key+'i').style.width = value+'px';
                            }

                             if (hazClass(getEL(key),'iconcan')) {
                                getEL('icon'+key).style.width = value+'px';
                            }
                             if (hazClass(getEL(key),'widget')) {
                                if (value >= 2) {
                                    alert("widgets can only be scaled from 0.0 to 1.9")
                                } else {
                                    getEL(key).style.webkitTransform = "scale(" + value + ")";
                                }
                            }
                            getEL(key).style.fontSize = value + 'px';
                            if(key === "forecast"){
                                getEL(key).style.webkitTransform = "scale(" + value + ")";
                            }
                        }
                    }
                    else if(type == 'color'){
                        if(checkKey(key)){
                            if (key === "line" || key === "thickline" || key === "mediumline") {
                                getEL(key).style.backgroundColor = value;
                            }
                             var creatitem = $("#" + key).hasClass("createditem");
                            if (creatitem === true) {
                                getEL(key).style.backgroundColor = value;
                            } else {
                                getEL(key).style.color = value;
                            }
                        }
                    }
                    else if(type == 'shadow'){
                        if(checkKey(key)){
                            if (key === "line" || key === "thickline" || key === "mediumline") {
                                getEL(key).style.webkitBoxShadow = value;
                            } else {
                                getEL(key).style.textShadow = value;
                            }
                        }
                    }
                    else if(type == 'align'){
                        getEL(key).style.textAlign = value;
                    }
                    else if(type =='iwidgets'){
                        getwidgetvalues(key, value);
                    }
                    else if(type == 'dragposition'){
                         if(checkKey(key)){
                            if(key == 'weathericonsmenu'||key=="premenu"||key=="weathermenu"){}
                                else{
                                getEL(key).style.webkitTransform = value;
                                }
                        }
                    }
                    else if(type == 'fonts'){
                        //alert('font'+key+value);
                        $('#'+key).css('font-family',value);
                        //getEL(key).style.fontFamily = value;
                    }
                    else if(type == 'caps'){
                        if(checkKey(key)){
                            $('#'+key).css('text-transform',value);
                            //getEL(key).style.textTransform = value;
                        }
                    }

                    }catch(err){}


                });
            }
        }
    }


    parsed=null;
    value=null;
};

//setTimeout(function(){
loadObject(loadLocal('iconOBJ'),'icon');
loadObject(loadLocal('hideOBJ'),'hide');
loadObject(loadLocal('objiwidgets'),'iwidgets');
loadObject(loadLocal('fontOBJ'),'fonts');
loadObject(loadLocal('iconimgOBJ'),'iconimg');
loadObject(loadLocal('newiconimgOBJ'),'newiconimg');
loadObject(loadLocal('colorOBJ'),'color');
loadObject(loadLocal('shadowOBJ'),'shadow');
loadObject(loadLocal('alignOB'),'align');
loadObject(loadLocal('capsOBJ'),'caps');
loadObject(loadLocal('opacityOB'),'opacity');
loadObject(loadLocal('scaleOBJ'),'scale');
loadObject(loadLocal('dragOBJ'),'dragposition');
//},0);

 var getitems, currentwall;
    if (loadLocal('overlay') !== null) {
        getEL('overlay').src = "/var/mobile/Library/LBEvoOverlays/" + loadLocal('overlay');
        getEL('overlay').style.display = "block";
    } else {
        getEL('overlay').style.display = "none";
    }


var calev=getcalendarEvents(0);
if(calev == 'No Events'){}
else{
    eventsplit=calev[0].split(':'); //split array
    date=eventsplit[0];
    date=JSON.stringify(date);
    date = date.replace(/"/g, "").split('-');
getEL('events').innerHTML=date[1]+"/"+date[2]+": "+eventsplit[1];
}


function formatSizeUnits(bytes){
    if  (bytes>=1000000000) {bytes=(bytes/1000000000).toFixed(2)+' GB';}
    else if (bytes>=1000000)    {bytes=(bytes/1000000).toFixed(2)+' MB';}
    else if (bytes>=1000)       {bytes=(bytes/1000).toFixed(2)+' KB';}
    else if (bytes>1)       {bytes=bytes+' bytes';}
    else if (bytes==1)      {bytes=bytes+' byte';}
    else                {bytes='0 byte';}
    return bytes;
}

var ddata = devicedata();
var signalArray = ["0%","20%","40%","60%","80%","100%"];

 getEL('name').innerHTML=devicename();
 getEL("dsize").innerHTML = "Total: " + formatSizeUnits(ddata.NSFileSystemSize);
 getEL("dfree").innerHTML = "Free: " + formatSizeUnits(ddata.NSFileSystemFreeSize);
 getEL("msize").innerHTML = "Memory: " + formatSizeUnits(devicemem());
 getEL("CPU").innerHTML = "CPU Cores: " + cpu();
 getEL("firm").innerHTML =  firmware();
 getEL("uptime").innerHTML = "Device on for "+uptimeinfo()+" mins";
 getEL("battery").innerHTML = getbattery()+"%";

 getEL('signal').innerHTML = signalArray[getSignal()];
 getEL('wifi').innerHTML = getWifi() + "%";
 getEL('alarm').innerHTML = getAlarm();


function alertmemory(){
    closemenu();
  var memoryuse=getjavascriptmemory();
  //var free=confirm(memoryuse+"\n *Click ok to free ram","");

swal({   title: "Memory",   text: memoryuse,   type: "warning",   showCancelButton: true,   confirmButtonColor: "#DD6B55",   confirmButtonText: "Yes, free memory",   closeOnConfirm: false }, function(){    swal({title: "Memory Cleared", text: "We cleaned as much as we could", type: 'success',confirmButtonText: 'Close',
        confirmButtonColor: '#393939' }); setTimeout(function(){  freememory(); }, 0); });

  //if(free){
    //freememory();
  //}
}




if(plisttxt==1){
    var stxt=loadLocal("smstext");
    var mtxt=loadLocal("mailtext");
    var ptxt=loadLocal("phonetext");
    var twtext=loadLocal("twittertext");
    var twbtext=loadLocal("tweetbottext");
    var watext=loadLocal("whatsapptext");


    if(stxt!="undefined"){
      SMStxt=stxt;
    }
    if(mtxt!="undefined"){
      MAILtxt=mtxt;
    }
    if(ptxt!="undefined"){
      PHONEtxt=ptxt;
    }
    if(twtext!="undefined"){
      TWITTERtxt=twtext;
    }
    if(twbtext!="undefined"){
      TWEETBOTtxt=twbtext;
    }
    if(watext!="undefined"){
      WHATSAPPtxt=watext;
    }
}


  getEL("sms").innerHTML = SMStxt+getbadgeSMS();
  getEL("mail").innerHTML = MAILtxt+getbadgeEmail();
  getEL("phone").innerHTML = PHONEtxt+getbadgePhone();
  getEL("twitter").innerHTML = TWITTERtxt+getbadgeTwitter();
  getEL("tweetbot").innerHTML = TWEETBOTtxt+getbadgeTweetbot();
  getEL("whatapp").innerHTML = WHATSAPPtxt+getbadgeWhatsapp();

  saveLocal('apiDeviceName',devicename());
  saveLocal('apiDeviceSize',"Total: " + formatSizeUnits(systemsize()));
  saveLocal('apiDeviceFree',"Free: " + formatSizeUnits(systemfree()));
  saveLocal('apiMsize',"Memory: " + formatSizeUnits(devicemem()));
  saveLocal('apiCPU',"CPU Cores: " + cpu());
  saveLocal('apiUptime','Device on for '+uptimeinfo()+' mins');
  saveLocal('apiFirm',firmware());
  saveLocal('apiSMS',SMStxt+getbadgeSMS());
  saveLocal('apiEmail',MAILtxt+getbadgeEmail());
  saveLocal('apiPhone',PHONEtxt+getbadgePhone());
  saveLocal('apiTwitter',TWITTERtxt+getbadgeTwitter());
  saveLocal('apiTweetbot',TWEETBOTtxt+getbadgeTweetbot());
  saveLocal('apiWhatsapp',WHATSAPPtxt+getbadgeWhatsapp());
