var saveLocal = function (name, value) {
    localStorage.setItem(name, value);
};
var loadLocal = function (name) {
    return localStorage.getItem(name);
};
var getEL = function (element) {
    return document.getElementById(element);
};
var hazClass = function (element, cls) {
    return (' ' + element.className + ' ').indexOf(' ' + cls + ' ') > -1;
};
function setalignments(alignm) {
    var caldiv;
    caldiv = loadLocal('helperel');
    if (getEL(caldiv)) {
        getEL(caldiv).style.textAlign = alignm;
    } else {
        alert("Error, jsfunctions.js line 13");
    }
    alignobj(caldiv, alignm);
}
var preLoad = function() {
   // getitems = loadLocal('userbg');
    //if (getitems !== null) {
      //  if (getitems.length >= 100) {
        //    getEL('background').style.backgroundImage = "url(" + getitems + ")";
        //}
    //}
    //getitems=null;

    var ls = loadLocal("lockscreenchosen");
if (ls != "null") {
    if (ls !== null) {
        var container = getEL('iwidgetcontainer');
        $("<div></div>").attr("id", "lockscreen").appendTo(container);
        $("<div></div>").attr("id", "locksa").appendTo(container);
        $("#lockscreen").css("position", "absolute");
        $("#lockscreen").css("width", "320px");
        $("#lockscreen").css("height", "160px");
        $("#lockscreen").css("left", "0px");
        $("#lockscreen").css("top", "410px");
        $("#lockscreen").css("background-color", "transparent");
        $("#lockscreen").css("z-index", "4");
        $("#locksa").css("z-index", "3");
        $("#locksa").css("position", "absolute");
        $("#locksa").css("background-color", "transparent");
        $("#locksa").css("width", "320px");
        $("#locksa").css("top", "0px");
        $("#locksa").css("left", "0px");
        loadlock(ls);
    }
}
var animat = loadLocal("animations");
if (animat != "null") {
    if (animat !== null) {
        var widcontainer = getEL('animationcontainer');
        $("<div></div>").attr("id", "anisc").appendTo(widcontainer);
        $("#anisc").css("z-index", "1");
        $("#anisc").css("position", "absolute");
        $("#anisc").css("background-color", "transparent");
        $("#anisc").css("width", "320px");
        $("#anisc").css("top", "0px");
        $("#anisc").css("left", "0px");
        $("#anisc").css("pointer-events", "none");
        loadanimation(animat);
    }
}

var isLocked, weathers;
isLocked = loadLocal('locked');
if (isLocked !== null) {
    getEL('lscreen').innerHTML = "Unlock";
    var unlockdiv=getEL('unlock');
    unlockdiv.setAttribute('onclick','unlockphone()');
    $('#weatherelements div').css('pointer-events','none');
   // getEL('weatherelements').style.pointerEvents = "none";
} else {
    getEL('lscreen').innerHTML = "Lock";

    //weathers = $('#weatherelements div').touch();
   // weathers = $('#city,#state,#statenm,#country,#desc1,#desc2,#desc3,#desc4,#desc5,#elevation,#lat,#long,#rainfall,#tdesc,#visible,#warning,#temp,#feeltemp,#condition,#later,#time,#day,#comma,#date,#year,#uv,#raininfo,#dew,#sunrise,#sunset,#icon,#battery,#forecast,#sms,#mail,#phone,#pm,#ttext,#htext,#mtext,#humidity,#month,#hi,#low,#slash,#slash2,#windsp,#windir,#speak,#unlock,#name,#dsize,#dfree,#tempFC,#min,#max,#hour,#minute,#colon,#nhood,#street,#addr,#county,#DMD,#MD,#DM,#twitter,#tweetbot,#whatapp,#events,#smonth,#latext,#longext,#sday,#L,#H,#L2,#H2,#msize,#CPU,#firm,#uptime,#zhour,#Dlocked,#rude,#fcast1,#fcast2,#fcast3,#fcast4,#day1icon,#day2icon,#day3icon,#day4icon,#day1hi,#day1lo,#day2hi,#day2lo,#day3hi,#day3lo,#day4hi,#day4lo,#day1des,#day2des,#day3des,#day4des,#tdate,#DSM,#ztime').touch();
}

//$('#movelocksmenu,#moveicondir,#iwidgetscrollbar,#themes').touch();

var smcolor = loadLocal('scolor');
if (smcolor !== null) {
  getEL('shadowcolor').style.color=smcolor;
}


};
var bclicker=0;
var addHelperClicks = function() {
bclicker+=1;
if(bclicker==1){
 getEL('helper').addEventListener('click', function(e) {
        if (e.target.id === "LBmove") {
            opencontrols();
            closehelper();
            $('#dpad').css('display', 'block');
            $('#dpad').touch();
        } else if (e.target.id === "LBalign") {
            toggleiconEl($('.alignoptions'));
        } else if (e.target.id === "LBfont") {
            toggleiconEl($('.fontelements'));
        } else if (e.target.id === "LBshadow") {
            opendropmenu();
        } else if (e.target.id === "LBrotate") {
            toggleiconEl($('.rotateelements'));
        } else if (e.target.id === "LBscale") {
            toggleiconEl($('.scaleelements'));
        } else if (e.target.id === "LBopacity") {
            toggleiconEl($('#opacity'));
        } else if (e.target.id === "LBcolor") {
            opencolor();
        } else if (e.target.id === "Aleft") {
            setalignments('left');
        } else if (e.target.id === "Acenter") {
            setalignments('center');
        } else if (e.target.id === "Aright") {
            setalignments('right');
        } else {}
    });
}
else{}
   
};


function togglemenuEl(div){
 if(getEL(div).style.display == "block"){
        getEL(div).style.display = "none";
      }
}

function toggleiconEl(ele){
    if(ele.css('display')==="none"){
        ele.css('display','block');
    }
    else{
        ele.css('display','none');
    }
}

  function togglepreLi(ele){ //toggle premenu elements to expand
    var dsp = document.getElementById(ele).style.display;
    if(dsp==="none"){
      document.getElementById(ele).style.display="block";
    }
    else{
     document.getElementById(ele).style.display="none";
    }
    
}

function submenuloop(el, men) { //toggle menu icons to expand
  var x;
    for (i = 0; i < el.length; i++) {
        togglepreLi(el[i]);
    }
    if (document.getElementById(el[0]).style.display == "block") {
        x = document.getElementsByClassName("mbutton");
        for (e = 0; e < x.length; e++) {
            if (x[e].id !== men) {
                x[e].style.display = "none";
            }
        }
    } else {
        x = document.getElementsByClassName("mbutton");
        for (e = 0; e < x.length; e++) {
            if (x[e].id !== men) {
                x[e].style.display = "block";
            }
        }
    }

}

function showsubmenu(which){
  var prePlace;
if(which === "Place"){
  prePlace = ['preEl','preWid','preApp','preLock'];
}
else if(which === "Wall"){
  prePlace = ['wallpaperbutton','preWw','preWall'];
}
else if(which === "Theme"){
  prePlace = ['loadsavedthemes','preSave','preSavesb','preDl'];
}
else if(which === "Overlay"){
  prePlace = ['preOver','preXover','preLgl','preCgl'];
}
else if(which === "Reset"){
  prePlace = ['preClear','preResetsb','preMreset'];
}
else if(which === "System"){
  prePlace = ['preRef','preMemory','preGlmkr'];
}
  submenuloop(prePlace,which+"pre");
}







closemenu = function(){
	var menuDdivs = ['premenu','weathermenu','widgetmenu','iconmenu'];
	for(md=0; md < menuDdivs.length; md++){
    togglemenuEl(menuDdivs[md]);
			}

	//getEL('menubackg').style.display = "none";
  getEL('menutopg').style.display = "none";
  getEL('selectwalls').style.left="300px";
  getEL('selectwalls').style.display="none";
};
openmenu = function(){
  getEL('premenu').style.display="block";
  //Removed below items to save resources.
  //getEL('menubackg').style.backgroundImage = "url(" + loadLocal('userbg') + ")";
	//getEL('menubackg').style.display="block";
  getEL('menutopg').style.display = "block";
};


var wallPass,statbar, sCityCodes,sUnit,gpstime,TwentyFourHourClock,statusbar,dimmer,curlanguage,cameragrab,ccgrab,ncgrab,overrideunlock,kph,plisttxt,SMStxt,MAILtxt,PHONEtxt,TWITTERtxt,TWEETBOTtxt,WHATSAPPtxt,slider;
    var settings = readDict('/var/mobile/Library/Preferences/com.JunesiPhone.LockBuilderEvo.plist');
  if (settings !== null) {
    if(settings.sCityCodes!==null){sCityCodes = settings.sCityCodes;}else{sCityCodes="72301";}
    if(settings.sUnit!==null){isCelsius = settings.sUnit;}else{isCelsius=0;}
    if(settings.gpsint!==null){gpstime = settings.gpsint;}else{gpstime=15;}
    if(settings.TwentyFour!==null){TwentyFourHourClock = settings.TwentyFour;}else{TwentyFourHourClock=false;}
    //if(settings.statusbarswitch!=null){statusbar = settings.statusbarswitch;}else{statusbar=0;}
    if(settings.dimmer!==null){dimmer = settings.dimmer;}else{dimmer="6000";}
    if(settings.languages!==null){var curlanguage = settings.languages;}else{var curlanguage="p";}
    //if(settings.cameragrab!=null){cameragrab = settings.cameragrab;}else{cameragrab=0;} 
    //if(settings.ccgrab!=null){ccgrab = settings.ccgrab;}else{ccgrab=0;} 
    //if(settings.ncgrab!=null){ncgrab = settings.ncgrab;}else{ncgrab=0;} 
    if(settings.overrideunlock!==null){overrideunlock=settings.overrideunlock;}else{overrideunlock="false";}
    if(settings.kph!==null){kph=settings.kph;}else{kph=0;}
    if(settings.plisttxt!==null){plisttxt=settings.plisttxt;}else{plisttxt=0;}
    if(settings.SMS!==null){SMStxt=settings.SMS;}else{SMStxt="SMS: ";}
    if(settings.MAIL!==null){MAILtxt=settings.MAIL;}else{MAILtxt="Mail: ";}
    if(settings.PHONE!==null){PHONEtxt=settings.PHONE;}else{PHONEtxt="Phone: ";}
    if(settings.TWITTER!==null){TWITTERtxt=settings.TWITTER;}else{TWITTERtxt="Twitter: ";}
    if(settings.TWEETBOT!==null){TWEETBOTtxt=settings.TWEETBOT;}else{TWEETBOTtxt="Tweetbot: ";}
    if(settings.WHATSAPP!==null){WHATSAPPtxt=settings.WHATSAPP;}else{WHATSAPPtxt="Whatsapp: ";}
    if(settings.slider!==null){slider = settings.slider;}else{slider="Unlock";}
    if(settings.locationservices!==null){locationservices = settings.locationservices;}else{locationservices=false;}
    if(settings.Wpassword!==null){wallPass = settings.Wpassword;}else{wallPass="no";}
    //if (settings.slideto != null){var slideto = settings.slideto;} else {var slideto = 0;}
    settings=null;
 }
  else{
    setTimeout(function(){  beginalert(); }, 0);
    var sCityCodes="38671";
    var TwentyFourHourClock="false";
    var sUnit="s";
    var curlanguage = "en";
  }
localStorage.setItem('currentlang',curlanguage);

if (overrideunlock == 1) { var sliderdiv = document.getElementById('unlock'); sliderdiv.innerHTML = slider;
}else{}

if (isCelsius == 1) { var sUnit = "m";
} else { var sUnit = "s";}

if (kph == 1) { var kph = "yes";
} else { var kph = "no"; }

if (TwentyFourHourClock == 1) { TwentyFourHourClock = "false";
} else { TwentyFourHourClock = "true"; }




window.setTimeout("dimlockscreen();", dimmer);

function getthemebg(theme){
  var themeplist = readDict('/var/mobile/Library/LBEvoThemes/'+theme);
  if(themeplist!==null){
  var img=themeplist.Background;
  return img;
  }
  themeplist=null;
}

function loading(name){
  var themeplist;
  try {
    themeplist = readDict("/var/mobile/Library/LBEvoThemes/"+name);
    loadpickedtheme(themeplist,name);
  }
  catch(err){
    alert("Themes2"+err);
  }
  themeplist=null;
}
function iconalert(){return window.NowIcon;}

function beginalert(){
    swal({   title: "Settings",   text: "LBEvo is using default settings. Would you like to go to the settings now?",   type: "warning",   showCancelButton: true,   confirmButtonColor: "#DD6B55", cancelButtonText: "I'll go later.",  confirmButtonText: "Yes, go there.",   closeOnConfirm: false }, function(){
      openLBsettings();
       });
 
  }







