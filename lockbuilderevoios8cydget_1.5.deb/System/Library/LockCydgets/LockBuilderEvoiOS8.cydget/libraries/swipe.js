$(window).load(function () {
    $(function () {
        var addSwipeTo = function (selector) {
            $(selector).swipe("destroy");
            $(selector).swipe({
                swipe: function (event, direction, distance, duration, fingerCount) {

                    freememory();

                    if (direction == "right"&&distance>="180") {
                        unlockphone();
                    }
                    if (direction == "left") {
                        openmenu();
                        hidetm();
                        useWinterboard();
                    }
                    if (direction == "right") {
                        closemenu();
                    }
                    if(direction=="up"){
                        hidetm();
                    }
                    if(direction=="down"){
                         showtm();
                         useWinterboard();
                         closemenu();
                    }
                },
                threshold: 0,
                excludedElements:$.fn.swipe.defaults.excludedElements+", .noswipe"
            });
        };
        //addSwipeTo("#menubg");
        addSwipeTo("#background");
        addSwipeTo("#locksa");
        addSwipeTo("#lockscreen");
        //addSwipeTo("#cloudcontainer");
        //addSwipeTo("#thunder");
        //addSwipeTo("#thunder2");
        addSwipeTo('#newitems');
        addSwipeTo('#falsebg');
        addSwipeTo('#overlay');
        //addSwipeTo('.iwidgetclass');

    });
});

/*function closemenupressed() {
    $('#menubackg').css('left','350px');
    $('#overlay,#background,#newitems,#weatherelements,.icons,#animationcontainer,#iwidgetcontainer').css('left', '0px');
    $('#premenu,#movemenu,#lsmenu,#iconmenu,#moveiwidgetsmenu,.iwidget,#widgetmenu,#iwidgetscrollbar').css('display', 'none');
}*/