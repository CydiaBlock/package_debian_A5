WEB_SOCKET_SWF_LOCATION = "/js/socket_ie.swf";
WEB_SOCKET_DEBUG = false;

var $wsWebSocketConnectionUrl = "%%WEBSOCKET_URL%%";
var $wsReconnectionAttemptsCounter = 1;
var $wsReconnectionTimer;
var $wsRetrying = 0;
var ws = 0;

function wsOnClose() {
	$wsRetrying = 1;
	setTimeout(function() {
		if ($("#status").hasClass('error') == false) {
			$("#status").addClass('error').animate({'opacity': 0.1}, 250);
		}
		clearErrors('errRetry');
		pushError("Connection to device lost. Retrying connection (attempt " + $wsReconnectionAttemptsCounter + ")", 'errRetry');
		$wsReconnectionTimer = setTimeout(function() {
			attemptReconnect();
		}, 1000);
	}, 1000);
}

function initWebSocket() {
	if (ws != 0) {
		ws.onclose = function() {};
		ws.close();
	}

	ws = new WebSocket($wsWebSocketConnectionUrl);

	ws.onopen = function() {
		$wsReconnectionAttemptsCounter = 1;
		$wsRetrying = 0;
		clearErrors();
		clearTimeout($wsReconnectionTimer);
		loadConversations();
		requestCurrentPhoneStatus();
	}

	ws.onmessage = function(evt) {
		onMessage(evt);
	}

	ws.onclose = wsOnClose;

	ws.onerror = function(evt) {
		if ($("#status").hasClass('error') == false) {
			$("#status").addClass('error').animate({'opacity': 0.1}, 250);
		}
		if ($wsRetrying == 0) {
			wsOnClose();
		}
	}
}

function attemptReconnect() {
	$wsReconnectionAttemptsCounter++;
	initWebSocket();
}