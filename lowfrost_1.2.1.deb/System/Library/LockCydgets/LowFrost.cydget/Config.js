/*

Configuration here

by ImLemonPartying

*/

	// AFTER MAKING ANY CHANGES HERE, RESPRING YOUR DEVICE!
	

	// Enter your zip code.  
	//
	// ONLY IF THAT DOES NOT WORK, try the following:
	// Go to http://www.weather.com/ and put your city into the search bar, then hit enter.
	// For example, Toronto, Canada: http://www.weather.com/weather/today/Toronto+CAXX0504:1:CA
	// In this example, you'd copy "CAXX0504" and paste that code below, between the quotation marks
	var locale = "VMXX0006";
	//
	//
	// If you want celsius, change this to = true;
	var isCelsius = true;
	//
	//
	// If you want to see wind chill/heat index instead,
	// change this to = true;	
	var useRealFeel = false;
	

	// AFTER MAKING ANY CHANGES HERE, RESPRING YOUR DEVICE!

/*

Hugs 'n kisses,
ImLemonPartying

*/
