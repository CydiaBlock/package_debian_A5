window.onload=function(){
    for (var i=7;i<9;i++){
        if (!avatar[i]){
            avatar[i]={};
            avatar[i].current = defaultAvas[i];
            avatar[i].original = defaultAvas[i];
            $('img'+i).src = $('ori'+i).src; //"getavatarpart?c="+skin+"&amp;aid="+avatar[i].original;
        }
    }
    if(!avatar[9]) avatar[9]={};
    avatar[9].original = -1;
    if(sub==0) for(var j=7;j<10;j++){avatar[j].selected = 0;avatar[j].original=defaultAvas[j];}
}
function changeavatar(flag,item,src,icon,price,xx,yy,zz){
    if (flag==7||flag==8||flag==9) changeclothes(flag,item,src,icon,price,xx,yy,zz);
    else changeface(flag,item,src,icon,price,xx,yy,zz);
}
function drawBody(){
    for (var i=7;i<10;i++){
        var a = $('img'+i);
        if(avatar[i].inuse) show(a);
        else hide(a);
    }
}
function changeclothes(flag,item,src,icon,price,xx,yy,zz){
    var t = $('img'+flag);
    var x = $('img7'),y=$('img8'),z=$('img9');
    if (avatar[flag].current==item ){
        if(avatar[flag].selected){
            avatar[flag].selected = 0;
            if (sub!=0){
                removeitem($('shopitem'+flag));
            }
            avatar[flag].current = avatar[flag].original;
            avatar[7].inuse = 1;
            avatar[8].inuse = 1;
            avatar[9].inuse = 0;
            if(flag!=9){
                avatar[9].current = avatar[9].original;
                if(avatar[flag].current==defaultAvas[flag])
                    t.src = $('def'+flag).src;
                else
                    //t.src = "getavatarpart?c="+skin+"&amp;aid="+avatar[flag].original;
                    t.src = $('ori'+flag).src;
                drawBody();
            }
            else{
                avatar[7].current = avatar[7].original;
                if(avatar[7].current==defaultAvas[7])
                    x.src = $('def7').src;
                else
                    //x.src = "getavatarpart?c="+skin+"&amp;aid="+avatar[7].original;
                    x.src = $('ori7').src;
                avatar[8].current = avatar[8].original;
                if(avatar[8].current==defaultAvas[8])
                    y.src = $('def8').src;
                else
                    //y.src = "getavatarpart?c="+skin+"&amp;aid="+avatar[8].original;
                    y.src = $('ori8').src;
                drawBody();
            }
            if(sub==0) rememberclothes();
        }
        else{
            avatar[flag].selected = 1;
        }
    }
    else{
        avatar[flag].current = item;
        avatar[flag].selected = 1;
        t.src = src;
        if(flag==9){
            if ($('shopitem7')) removeitem($('shopitem7'));
            if ($('shopitem8')) removeitem($('shopitem8'));
            avatar[7].current = avatar[7].original;
            if(avatar[7].current==defaultAvas[7])
                x.src = $('def7').src;
            else
                //x.src = "getavatarpart?c="+skin+"&amp;aid="+avatar[7].original;
                x.src = $('ori7').src;
            avatar[8].current = avatar[8].original;
            if(avatar[8].current==defaultAvas[8])
                y.src = $('def8').src;
            else
                //y.src = "getavatarpart?c="+skin+"&amp;aid="+avatar[8].original;
                y.src = $('ori8').src;
            avatar[7].inuse = 0;
            avatar[8].inuse = 0;
            avatar[9].inuse = 1;
            drawBody();
        }
        else{
            if ($('shopitem9')) removeitem($('shopitem9'));
            avatar[9].current = avatar[9].original;
            if (avatar[9].original!=-1) 
                //z.src = "getavatarpart?c="+skin+"&amp;aid="+avatar[9].original;
                z.src = $('ori9').src;
            avatar[7].inuse = 1;
            avatar[8].inuse = 1;
            avatar[9].inuse = 0;
            drawBody();
        }
        if(sub!=0){
            if ($('shopitem'+flag)) removeitem($('shopitem'+flag));
            var shopitm = document.createElement('li');
            shopitm.id = "shopitem"+flag;
            shopitm.className = "list";
            shopitm.setAttribute('itemid',item);
            shopitm.setAttribute('price',price);
            shopitm.setAttribute('flag',flag);
            shopitm.setAttribute('onclick','removeitem(this,1)');
            shopitm.innerHTML = '<p><img src="'+icon+'"/><b>Price: '+price+' papayas</b></p>';
            if ($('mycart').hasClass(shopitm.getAttribute('itemid'))) shopitm.addClass("checked");
            shopitm.injectInto($('cart'));
            show($('cart'));
            show($('addbtn'));
            //updatetotalprice();
        }
        else{
            rememberclothes();
        }
    }
}
function rememberclothes(){
    s = '';
    for (var i=7;i<10;i++){
        if(avatar[i].inuse) s += ','+avatar[i].current;
    }
    s = s.substr(1);
    loadJSON('rememberclothes',{'aids':s},function(r){});
}
function notenoughpapaya(){
    $('md').style.height=document.scrollHeight;show($('md'));$('confirm').style.marginTop=(window.pageYOffset+150)+'px';
}
function showmine(flag){
    var lis = $('sidemenu').getElementsByTagName('li');
    for(i=0;i<lis.length;i++)lis[i].removeClass('on');
    lis[flag-7].addClass('on');
    for(var j=7;j<10;j++) avatar[j].selected = 0;
    document.location='papaya://refreshavatarbar?myavataritems?flag='+flag;
}
function showcart(flag){
    hide($('sidemenu'));
    var c = $('cartpanel');
    //show($('cart'));
    show($('pcs'));
    hide($('check'));
    document.location='papaya://refreshavatarbar?avataritems?flag='+flag;
}
function hidecart(){
    hide($('cart'));
    hide($('pcs'));
    show($('sidemenu'));
    var itms = $('cart').GC('li','list');
    if (itms.length!=0){
        for(var i=0;i<itms.length;i++){
            removeitem(itms[i]);
        }
    }
    show($('check'));
    document.location='papaya://hideavatarbar';
}
function removeitem(el,a){
    if (a){
        var flag = el.getAttribute('flag').toInt();
        t = $('img'+flag);
        avatar[flag].current = avatar[flag].original;
        if(avatar[flag].original!=-1){
            if(avatar[flag].current==defaultAvas[flag])
                t.src = $('def'+flag).src;
            else
                //t.src = "getavatarpart?c="+skin+"&amp;aid="+avatar[flag].original;
                t.src = $('ori'+flag).src;
        }
        avatar[7].inuse = 1;
        avatar[8].inuse = 1;
        avatar[9].inuse = 0;
        drawBody();
        var ct = $('mycart');
        if(ct.hasClass(el.getAttribute('itemid'))) ct.removeClass(el.getAttribute('itemid'));
    }
    del(el);
    hide($('cart'));
    hide($('addbtn'));
}
function checkout(){
    var itms = $('mycart').className.replaceAll(' ',',');
    if(itms==''){
        palert("Your cart is empty.",1);
        return;
    }
    else
        document.location = 'papaya://slidenewpage?checkout?items='+itms;
}
function addtocart(){
    var items = $('cart').GC('li','list');
    if(items.length==0) return;
    else{
        var ct = $('mycart');
        for(var i=0;i<items.length;i++){ct.addClass(items[i].getAttribute('itemid'));}
        for (var i=7;i<10;i++){
            avatar[i].original = avatar[i].current;
        }
        for (var i=0;i<items.length;i++){
            //del(items[i]);
            items[i].addClass('checked');
        }
    }
}
function showfacial(flag){
    document.location='papaya://refreshavatarbar?avataritems?flag='+flag;
    var lis = $('sidemenu').getElementsByTagName('li');
    for(i=0;i<lis.length;i++)lis[i].removeClass('on');
    lis[flag].addClass('on');
}
function changeface(flag,item,src,icon,price,xx,yy,zz){
    var imgs = $('userface').getElementsByTagName('img');
    if (flag!=6){
        imgs[flag].src = src;
        avatar[flag].current = item;
    }
    else{
        var bh = $('backhair');
        if(src.indexOf('~')!=-1){
            var ss = src.split('~');
            imgs[flag].src = ss[0];
            bh.src = ss[1];
            bh.setAttribute('current',item);
            show(bh);
        }
        else{
            imgs[flag].src = src;
            hide(bh);
        }
        avatar[flag].current = item;
    }
    saveface();
}
function saveface(){
    s = '';
    for (var i=0;i<7;i++){
        s += ','+avatar[i].current;
    }
    s = s.substr(1);
    loadJSON('saveface',{'items':s},function(r){});
}
function savefacetoalbum(){
    s = '';
    for (var i=0;i<7;i++){
        s += ','+avatar[i].current;
    }
    s = s.substr(1);
    loadJSON('savefacetoalbum',{'items':s},function(r){
        if(r.saved){
            palert("Saved successfully.");
        }
        else palert('Failed to save the picture to your album. Please try again later.',1);
    });
}
function saveavatartoalbum(){
    loadJSON('saveavatartoalbum',{},function(r){
        if(r.saved){
            palert("Saved successfully.");
        }
        else palert('Failed to save the picture to your album. Please try again later.',1);
    });
}