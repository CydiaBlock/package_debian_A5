var mancatenames = ["Face",'Eyebrow','Eye','Nose','Mouth','Ear','Hair','Top','Pants','Suit','Neck','Background','Beard','Necklace','Bag','Hat','Head background','Glasses'];
var womancatenames = ["Face",'Eyebrow','Eye','Nose','Mouth','Ear','Hair','Top','Bottom','Dress','Neck','Background','Beard','Necklace','Bag','Hat','Head background','Glasses'];
var faceflags = [0,1,2,3,4,5,6,10,12,16];
var bodyflags = [7,8,9,11,13,14,15];
window.onload=function(){
    if (sub==2) faceflags.push(17);
    else bodyflags.push(17);
    var nk = sex==0?194:193;
    avatar[10]={};
    avatar[10].current = nk;
    avatar[10].original = nk;
    avatar[10].inuse = 1;
    avatar[10].selected = 1;
    for (var i=7;i<9;i++){
        if (!avatar[i]){
            avatar[i]={};
            avatar[i].current = defaultAvas[i];
            avatar[i].original = defaultAvas[i];
            if($('img'+i)) $('img'+i).src = "getavatarpart?c="+skin+"&amp;aid="+avatar[i].original;
        }
    }
    var initavas = [9,11,12,13,14,15,16,17];
    for (var n=0;n<initavas.length;n++){
        k = initavas[n];
        if (!avatar[k]) avatar[k]={};
        avatar[k].original = -1;
    }
    if(sub==0) for(var j=7;j<10;j++){avatar[j].selected = 0;avatar[j].original=defaultAvas[j];}
}
function changeavatar(flag,item,src,icon,price,xx,yy,zz){
    if (faceflags.indexOf(flag)==-1) changeclothes(flag,item,src,icon,price,xx,yy,zz);
    else changeface(flag,item,src,icon,price,xx,yy,zz);
}
function drawBody(){
    for (var j=0;j<bodyflags.length;j++){
        var i = bodyflags[j];
        var a = $('img'+i);
        if(avatar[i].inuse) show(a);
        else hide(a);
    }
}
function changeclothes(flag,item,src,icon,price,xx,yy,zz){
    var t = $('img'+flag);
    var x = $('img7'),y=$('img8'),z=$('img9');
    if (avatar[flag].current==item ){
        if(avatar[flag].selected){
            avatar[flag].selected = 0;
            if (sub!=0){
                if($('shopitem'+flag))
                    removeitem($('shopitem'+flag));
            }
            avatar[flag].current = avatar[flag].original;
            if (flag==7||flag==8||flag==9){
                avatar[7].inuse = 1;
                avatar[8].inuse = 1;
                avatar[9].inuse = 0;
            }
            else
                avatar[flag].inuse = 0;
            if(flag==7||flag==8){
                avatar[9].current = avatar[9].original;
                if(avatar[flag].current==defaultAvas[flag])
                    t.src = $('def'+flag).src;
                else
                    t.src = "getavatarpart?c="+skin+"&amp;aid="+avatar[flag].original;
            }
            else if (flag==9){
                avatar[7].current = avatar[7].original;
                if(avatar[7].current==defaultAvas[7])
                    x.src = $('def7').src;
                else
                    x.src = "getavatarpart?c="+skin+"&amp;aid="+avatar[7].original;
                avatar[8].current = avatar[8].original;
                if(avatar[8].current==defaultAvas[8])
                    y.src = $('def8').src;
                else
                    y.src = "getavatarpart?c="+skin+"&amp;aid="+avatar[8].original;
            }
            drawBody();
            if(sub==0) rememberclothes();
        }
        else{
            avatar[flag].selected = 1;
        }
    }
    else{
        avatar[flag].current = item;
        avatar[flag].selected = 1;
        t.src = src;
        if(flag==9){
            if ($('shopitem7')) removeitem($('shopitem7'));
            if ($('shopitem8')) removeitem($('shopitem8'));
            avatar[7].current = avatar[7].original;
            if(avatar[7].current==defaultAvas[7])
                x.src = $('def7').src;
            else
                x.src = "getavatarpart?c="+skin+"&amp;aid="+avatar[7].original;
            avatar[8].current = avatar[8].original;
            if(avatar[8].current==defaultAvas[8])
                y.src = $('def8').src;
            else
                y.src = "getavatarpart?c="+skin+"&amp;aid="+avatar[8].original;
            avatar[7].inuse = 0;
            avatar[8].inuse = 0;
            avatar[9].inuse = 1;
        }
        else if (flag==7||flag==8){
            if ($('shopitem9')) removeitem($('shopitem9'));
            avatar[9].current = avatar[9].original;
            if (avatar[9].original!=-1) z.src = "getavatarpart?c="+skin+"&amp;aid="+avatar[9].original;
            avatar[7].inuse = 1;
            avatar[8].inuse = 1;
            avatar[9].inuse = 0;
        }
        else{
            avatar[flag].inuse = 1;
        }
        drawBody();
        if(sub!=0){
            var crt = $('cart');
            if ($('shopitem'+flag)) removeitem($('shopitem'+flag));
            if(xx && (!$('acclk') || !$('acclk').hasClass('on'))){
                var acclink;
                if(!$('acclk')){
                    acclink = document.createElement('li');
                    acclink.id = 'acclk';
                    acclink.innerHTML = '<b>Show related items</b>'
                    acclink.injectInto(crt);
                }
                else{
                    acclink = $('acclk');
                }
                acclink.setAttribute('onclick','togglerelated(this,'+flag+','+item+')');
                acclink.className = 'centertext';
            }
            else if(!xx && $('acclk')){
                del($('acclk'));
            }
            var shopitm = document.createElement('li');
            shopitm.id = "shopitem"+flag;
            shopitm.className = "list";
            shopitm.setAttribute('itemid',item);
            shopitm.setAttribute('price',price);
            shopitm.setAttribute('flag',flag);
            shopitm.setAttribute('onclick','removeitem(this,1)');
            shopitm.innerHTML = '<p><img src="'+icon+'"/><b>Price: '+price+' papayas</b></p>';
            if ($('mycart').hasClass(shopitm.getAttribute('itemid'))) shopitm.addClass("checked");
            shopitm.injectInto(crt);
            show(crt);
            show($('addbtn'));
        }
        else{
            rememberclothes();
        }
    }
}
function rememberclothes(){
    s = '';
    for (var i=7;i<10;i++){
        if(avatar[i].inuse) s += ','+avatar[i].current;
    }
    s = s.substr(1);
    loadJSON('rememberclothes',{'aids':s},function(r){});
}
function notenoughpapaya(){
    $('md').style.height=document.scrollHeight;show($('md'));$('confirm').style.marginTop=(window.pageYOffset+150)+'px';
}
function showmine(flag){
    var lis = $('sidemenu').getElementsByTagName('li');
    for(i=0;i<lis.length;i++)lis[i].removeClass('on');
    $('fli'+flag).addClass('on');
    //lis[flag-7].addClass('on');
    for(var j=7;j<10;j++) avatar[j].selected = 0;
    document.location='papaya://refreshavatarbar?myavataritems?flag='+flag;
}
function togglerelated(el,flag,aid){
    //$('cart').innerHTML = '';
    if (el.hasClass('on')){
        el.removeClass('on');
        el.innerHTML = "<b>Show related items</b>"
        document.location='papaya://refreshavatarbar?avataritems?flag='+flag;
    }
    else{
        el.addClass('on');
        var cate = '';
        if(sex==0){
            cate = mancatenames[flag];
        }
        else{
            cate = womancatenames[flag];
        }
        el.innerHTML = "<b>Back to "+cate+"</b>";
        document.location="papaya://refreshavatarbar?relatedavatar?aid="+aid;
    }
}
function showcart(flag){
    hide($('sidemenu'));
    if(!$('access').hasClass('hidden')) hide($('access'));
    //var c = $('cartpanel');
    //show($('cart'));
    show($('pcs'));
    hide($('check'));
    document.location='papaya://refreshavatarbar?avataritems?free=2&amp;flag='+flag+'&amp;sub='+sub;
}
function hidecart(){
    var ct = $('cart');
    var acs = $('access');
    hide(ct);
    hide($('pcs'));
    if(acs.hasClass('hidden'))
        show($('sidemenu'));
    else show(acs);
    var itms = ct.GC('li','list');
    if (itms.length!=0){
        for(var i=0;i<itms.length;i++){
            removeitem(itms[i]);
        }
    }
    ct.innerHTML = '';
    show($('check'));
    document.location='papaya://hideavatarbar';
}
function removeitem(el,a){
    if (a){
        var flag = el.getAttribute('flag').toInt();
        t = $('img'+flag);
        avatar[flag].current = avatar[flag].original;
        if(avatar[flag].original!=-1){
            if(avatar[flag].current==defaultAvas[flag])
                t.src = $('def'+flag).src;
            else
                t.src = "getavatarpart?c="+skin+"&amp;aid="+avatar[flag].original;
        }
        if(flag==7||flag==8||flag==9){
            avatar[7].inuse = 1;
            avatar[8].inuse = 1;
            avatar[9].inuse = 0;
        }
        else avatar[flag].inuse = 0;
        drawBody();
        var ct = $('mycart');
        if(ct.hasClass(el.getAttribute('itemid'))) ct.removeClass(el.getAttribute('itemid'));
    }
    del(el);
    if($('cart').GC('li','list').length==0){
        hide($('cart'));
        hide($('addbtn'));
    }
}
function checkout(){
    var itms = $('mycart').className.replaceAll(' ',',');
    if(itms==''){
        palert("Your cart is empty.",1);
        return;
    }
    else
        document.location = 'papaya://slidenewpage?checkout?items='+itms;
}
function addtocart(){
    var items = $('cart').GC('li','list');
    if(items.length==0) return;
    else{
        var ct = $('mycart');
        for(var i=0;i<items.length;i++){ct.addClass(items[i].getAttribute('itemid'));}
        for (var i=7;i<10;i++){
            avatar[i].original = avatar[i].current;
        }
        for (var i=0;i<items.length;i++){
            //del(items[i]);
            items[i].addClass('checked');
        }
    }
}
function showfacial(flag){
    document.location='papaya://refreshavatarbar?avataritems?free=1&amp;flag='+flag+'&amp;sub='+sub;
    var lis = $('sidemenu').getElementsByTagName('li');
    for(i=0;i<lis.length;i++)lis[i].removeClass('on');
    $('fli'+flag).addClass('on');
}
function changeface(flag,item,src,icon,price,xx,yy,zz){
    var im = $('img'+flag);
    if (flag!=6){
        im.src = src;
        avatar[flag].current = item;
    }
    else{
        var bh = $('backhair');
        if(src.indexOf('~')!=-1){
            var ss = src.split('~');
            im.src = ss[0];
            bh.src = ss[1];
            bh.setAttribute('current',item);
            show(bh);
        }
        else{
            im.src = src;
            hide(bh);
        }
        avatar[flag].current = item;
    }
    saveface();
}
function saveface(){
    s = '';
    for (var i=0;i<faceflags.length;i++){
        j = faceflags[i];
        if (avatar[j].current && avatar[j].current!=-1)
            s += ','+avatar[j].current;
    }
    s = s.substr(1);
    loadJSON('saveface',{'items':s},function(r){});
}
function savefacetoalbum(){
    s = '';
    for (var i=0;i<faceflags.length;i++){
        j = faceflags[i];
        if (avatar[j].current && avatar[j].current!=-1)
            s += ','+avatar[j].current;
    }
    s = s.substr(1);
    loadJSON('savefacetoalbum',{'items':s},function(r){
        if(r.saved){
            palert("Copied successfully.");
        }
        else palert('Failed to save the picture to your album. Please try again later.',1);
    });
}
function saveavatartoalbum(){
    loadJSON('saveavatartoalbum',{},function(r){
        if(r.saved){
            palert("Copied successfully.");
        }
        else palert('Failed to save the picture to your album. Please try again later.',1);
    });
}