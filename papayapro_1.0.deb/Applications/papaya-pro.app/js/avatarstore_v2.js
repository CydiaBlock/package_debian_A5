var faceflags = [];
var bodyflags = [];
window.onload=function(){
    faceflags = facialflags;
    bodyflags = bodiesflags;
    if (sub==2) bodyflags.remove(17);
    else faceflags.remove(17);
}
function changeavatar(flag,item,src,icon,price,xx,yy,zz){
    if (faceflags.indexOf(flag)==-1) changeclothes(flag,item,src,icon,price,xx,yy,zz);
    else changeface(flag,item,src,icon,price,xx,yy,zz);
}
function drawBody(){
    for (var j=0;j<bodyflags.length;j++){
        var i = bodyflags[j];
        var a = $('img'+i);
        if(avatar[i].inuse) show(a);
        else hide(a);
    }
}
function showwaiting() {
	var papaya = window.Papaya;
	papaya.indicatorShow_("wait");
	papaya.indicatorSet_animating_("wait", 1);
}
function hidewaiting() {
	var papaya = window.Papaya;
	papaya.indicatorHide_("wait");
	papaya.indicatorSet_animating_("wait", 0);
}
function avatarbartapped(selected, flag, item, src, icon, price, xx, yy, zz) {
	if (src.length == 0) {
		showwaiting();
	} else {
		hidewaiting();
		changeavatar(flag, item, src, icon, price, xx, yy, zz);
	}		
}
function avatarimageloaded(selected, flag, item, src, icon, price, xx, yy, zz) {
	hidewaiting();
	changeavatar(flag, item, src, icon, price, xx, yy, zz);
}
function changeclothes(flag,item,src,icon,price,xx,yy,zz){
    var t = $('img'+flag);
    var x = $('img7'),y=$('img8'),z=$('img9');
    if (avatar[flag].current==item ){
        if(avatar[flag].selected){
            avatar[flag].selected = 0;
            if (sub!=0){
                if($('shopitem'+flag))
                    removeitem($('shopitem'+flag));
            }
            if (avatar[flag].current != avatar[flag].original) avatar[flag].current = avatar[flag].original;
            else{
                var mct = $('mycart');
                if (mct.hasClass(item))
                    mct.removeClass(item);
                avatar[flag].current = avatar[flag].dft;
            }
            if (flag==7||flag==8||flag==9){
                avatar[7].inuse = 1;
                avatar[8].inuse = 1;
                avatar[9].inuse = 0;
            }
            else
                avatar[flag].inuse = 0;
            if(flag==7||flag==8){
                avatar[9].current = avatar[9].original;
                if(avatar[flag].current==avatar[flag].dft)
                    t.src = $('def'+flag).src;
                else
                    t.src = $('ori'+flag).src;
            }
            else if (flag==9){
                avatar[7].current = avatar[7].original;
                if(avatar[7].current==avatar[7].dft)
                    x.src = $('def7').src;
                else
                    x.src = $('ori7').src;
                avatar[8].current = avatar[8].original;
                if(avatar[8].current==avatar[8].dft)
                    y.src = $('def8').src;
                else
                    y.src = $('ori8').src;
            }
            drawBody();
            if(sub==0) rememberclothes();
        }
        else{
            avatar[flag].selected = 1;
        }
    }
    else{
        avatar[flag].current = item;
        avatar[flag].selected = 1;
        t.src = src;
        if(flag==9){
            if ($('shopitem7')) removeitem($('shopitem7'));
            if ($('shopitem8')) removeitem($('shopitem8'));
            avatar[7].current = avatar[7].original;
            if(avatar[7].current==avatar[7].dft)
                x.src = $('def7').src;
            else
                x.src = $('ori7').src;
            avatar[8].current = avatar[8].original;
            if(avatar[8].current==avatar[8].dft)
                y.src = $('def8').src;
            else
                y.src = $('ori8').src;
            avatar[7].inuse = 0;
            avatar[8].inuse = 0;
            avatar[9].inuse = 1;
        }
        else if (flag==7||flag==8){
            if ($('shopitem9')) removeitem($('shopitem9'));
            avatar[9].current = avatar[9].original;
            if (avatar[9].original)
                z.src = $('ori9').src;
            avatar[7].inuse = 1;
            avatar[8].inuse = 1;
            avatar[9].inuse = 0;
            if(avatar[15-flag].current==0) avatar[15-flag].current = avatar[15-flag].dft;
        }
        else{
            avatar[flag].inuse = 1;
        }
        drawBody();
        if(sub!=0){
            var crt = $('cart');
            if ($('shopitem'+flag)) removeitem($('shopitem'+flag));
            if(xx && (!$('acclk') || !$('acclk').hasClass('on'))){
                var acclink;
                if(!$('acclk')){
                    acclink = document.createElement('li');
                    acclink.id = 'acclk';
                    //acclink.innerHTML = '<b>Show related items</b>'
                    acclink.innerHTML = '<b>'+$('showrelstr').innerHTML+'</b>';
                    acclink.injectInto(crt);
                }
                else{
                    acclink = $('acclk');
                }
                acclink.setAttribute('onclick','togglerelated(this,'+flag+','+item+')');
                acclink.className = 'centertext';
            }
            else if(!xx && $('acclk')){
                del($('acclk'));
            }
            var shopitm = document.createElement('li');
            shopitm.id = "shopitem"+flag;
            shopitm.className = "list";
            shopitm.setAttribute('itemid',item);
            shopitm.setAttribute('price',price);
            shopitm.setAttribute('flag',flag);
            shopitm.setAttribute('onclick','removeitem(this,1)');
            shopitm.innerHTML = '<p><img src="'+icon+'"/><b>'+$('pricestr').innerHTML+' '+price+' papayas</b></p>';
            if ($('mycart').hasClass(shopitm.getAttribute('itemid'))) shopitm.addClass("checked");
            shopitm.injectInto(crt);
            show(crt);
            show($('addbtn'));
        }
        else{
            rememberclothes();
        }
    }
}
function rememberclothes(){
    s = '';
    for (var i=0;i<bodyflags.length;i++){
        j = bodiesflags[i]
        if(avatar[j].inuse) s += ','+avatar[j].current;
    }
    s = s.substr(1);
    loadJSON('rememberclothes',{'aids':s},function(r){});
}
function notenoughpapaya(){
    $('md').style.height=document.scrollHeight;show($('md'));$('confirm').style.marginTop=(window.pageYOffset+150)+'px';
}
function showmine(flag){
    //document.location='papaya://refreshavatarbar?newmyavataritems?flag='+flag;
    showAvatarBar("newmyavataritems?flag="+flag);
}
function togglerelated(el,flag,aid){
    if (el.hasClass('on')){
        el.removeClass('on');
        //el.innerHTML = "<b>Show related items</b>"
        el.innerHTML = '<b>'+$('showrelstr').innerHTML+'</b>';
        //document.location='papaya://refreshavatarbar?newavataritems?flag='+flag;
        showAvatarBar("newavataritems?flag="+flag);
    }
    else{
        el.addClass('on');
        var cate = '';
        if(sex==0){
            cate = mancatenames[flag];
        }
        else{
            cate = womancatenames[flag];
        }
        //el.innerHTML = "<b>Back to "+cate+"</b>";
        el.innerHTML = "<b>" + $('bktostr').innerHTML +' '+ cate + "</b>";
        //document.location="papaya://refreshavatarbar?newrelatedavatar?aid="+aid;
        showAvatarBar("newrelatedavatar?aid="+aid);
    }
}

var menumap = {};

var storemenu =
    {
        "backgroundColor":"#ffffff",
        "selectedColor":"#E8EEF7",
        "rowHeight":38,
        "fontSize":13,
        "fontName":"Helvetica-Bold",
        "selectionStyle":"Gray",
        "separatorSize":0.5,
        "separatorColor":"#cccccc",
        "borderSize":1.0,
        "borderColor":"#cccccc",
        "radius":6.0,
        "textMinX":10.0,
        "iconMaxX" : 24.0
    };
function composeitem(text,action,accessory){
    if (!accessory) accessory='None';
    var item = {};
    item["text"] = text;
    item["accessory"] = accessory;
    item["action"] = action;
    return item;
}

function composemenumap() {
    if (sub == 0) {
        menumap['top'] = genMenu(bodiesflags,'showmine',my);
    } else if (sub == 1) {
        menumap['top'] = genMenu(bodiesflags,'showcart');
    } else if (sub == 2) {
        menumap['top'] = genMenu(facialflags,'showfacial');
    }
}

function genMenu(list,cb,pref){
    if (!pref) pref='';
    itemarray = [];
    catenames = sex==0?mancatenames:womancatenames;
    for(var i=0;i<list.length;i++){
        j = list[i];
        itemarray.push(composeitem(pref+catenames[j],cb+'('+j+')'));
    }
    return itemarray;
}

function showmenu() {
    var papaya = window.Papaya;
    papaya.menuClearSelection_('menu');
    papaya.menuShow_('menu');
    papaya.menuPack_('menu');
    var frame = papaya.menuFrame_('menu');
    var sidemenu = document.getElementById('sidemenu');
    show(sidemenu);
    sidemenu.style.height = (frame[3]-1)+"px";
}

function hidemenu() {
    var papaya = window.Papaya;
    papaya.menuHide_('menu');
    hide($('sidemenu'));
}
function showAvatarBar(url) {
    var papaya = window.Papaya;
	var json = {
		"items_url" : url
	};
	papaya.avatarBarShow_("bar");
	papaya.avatarBarReload_json_("bar", toJSONString(json));
}
function showcart(flag){
    hidemenu();
    show($('pcs'));
    //hide($('check'));
    //document.location='papaya://refreshavatarbar?avataritems?free=2&amp;flag='+flag+'&amp;sub='+sub;
    showAvatarBar('newavataritems?free=2&amp;flag='+flag+'&amp;sub='+sub);
}
function hidecart(){
    var papaya = window.Papaya;
    papaya.log_('hidecart begins');
    var ct = $('cart');
    var acs = $('access');
    hide(ct);
    hide($('pcs'));
    showmenu();

    var itms = ct.GC('li','list');
    if (itms.length!=0){
        for(var i=0;i<itms.length;i++){
            removeitem(itms[i]);
        }
    }
    ct.innerHTML = '';
    //show($('check'));
    papaya.log_('hidecart ends');
    //document.location='papaya://hideavatarbar';
    window.Papaya.avatarBarHide_('bar');
}
function removeitem(el,a){
    if (a){
        var flag = el.getAttribute('flag').toInt();
        t = $('img'+flag);
        avatar[flag].current = avatar[flag].original;
        if(avatar[flag].original){
            if(avatar[flag].current==avatar[flag].dft){
                if ($('def'+flag))
                    t.src = $('def'+flag).src;
            }
            else{
                if ($('ori'+flag))
                    t.src = $('ori'+flag).src; // t.src = "getavatarpart?c="+skin+"&amp;aid="+avatar[flag].original;
            }
        }
        if(flag==7||flag==8||flag==9){
            avatar[7].inuse = 1;
            avatar[8].inuse = 1;
            avatar[9].inuse = 0;
        }
        else avatar[flag].inuse = 0;
        drawBody();
        var ct = $('mycart');
        if(ct.hasClass(el.getAttribute('itemid'))) ct.removeClass(el.getAttribute('itemid'));
    }
    del(el);
    if($('cart').GC('li','list').length==0){
        hide($('cart'));
        hide($('addbtn'));
    }
}
function checkout(){
    var itms = $('mycart').className.replaceAll(' ',',');
    if(itms==''){
        palert($('emptycartstr').innerHTML,1);
        return;
    }
    else papayajs.slideto('newcheckout?items='+itms);
}
function addtocart(){
    var items = $('cart').GC('li','list');
    if(items.length==0) return;
    else{
        var ct = $('mycart');
        for(var i=0;i<items.length;i++){ct.addClass(items[i].getAttribute('itemid'));}
        for (var i=7;i<10;i++){
            avatar[i].original = avatar[i].current;
        }
        for (var i=0;i<items.length;i++){
            items[i].addClass('checked');
        }
    }
}
function showfacial(flag){
    //document.location='papaya://refreshavatarbar?newavataritems?free=1&amp;flag='+flag+'&amp;sub='+sub;
    showAvatarBar('newavataritems?free=1&amp;flag='+flag+'&amp;sub='+sub);
}
function changeface(flag,item,src,icon,price,xx,yy,zz){
    var im = $('img'+flag);
    if (avatar[flag].current!=item){
        if (flag!=6){
            im.src = src;
            avatar[flag].current = item;
        }
        else{
            var bh = $('backhair');
            if(src.indexOf('~')!=-1){
                var ss = src.split('~');
                im.src = ss[0];
                bh.src = ss[1];
                bh.setAttribute('current',item);
                show(bh);
            }
            else{
                im.src = src;
                hide(bh);
            }
            avatar[flag].current = item;
        }
        show(im);
    }
    else{
        if (avatar[flag].removable){
            avatar[flag].current = 0;
            im.src = '';
            hide(im);
        }
    }
    saveface();
}
function saveface(){
    s = '';
    for (var i=0;i<faceflags.length;i++){
        j = faceflags[i];
        if (avatar[j].current)
            s += ','+avatar[j].current;
    }
    s = s.substr(1);
    loadJSON('saveface',{'items':s},function(r){});
}
function savefacetoalbum(){
    s = '';
    for (var i=0;i<faceflags.length;i++){
        j = faceflags[i];
        if (avatar[j].current)
            s += ','+avatar[j].current;
    }
    s = s.substr(1);
    loadJSON('savefacetoalbum',{'items':s},function(r){
        if(r.saved){
            palert($('savedstr').innerHTML);
        }
        else palert($('savefailedstr').innerHTML,1);
    });
}
function saveavatartoalbum(){
    loadJSON('saveavatartoalbum',{},function(r){
        if(r.saved){
            palert($('savedstr').innerHTML);
        }
        else palert($('savefailedstr').innerHTML,1);
    });
}
