var ppy_home_tabs = {'home':0,'avatar':1,'comment':2,'profile':3,'bank':4,'blog':5,'score':6};
var ppy_home_horibar_ctx = {
    'tabs':[
        {'text':'My home','action':"papayajs.go('static_home')"},
        {'text':'Avatar','action':"papayajs.slidenewpage('avatar')"},
        {'text':'Comment','action':"papayajs.go('comments')"},
        {'text':'Profile','action':"papayajs.go('profile')"},
        {'text':'Bank','action':"papayajs.go('credit')"},
        {'text':'Blog','action':"papayajs.go('miniblog')"},
        {'text':'Game scores','action':"papayajs.go('gamescore')"}
    ]
};
var ppy_friend_tabs = {'home':0,'avatar':1,'comment':2,'photo':3,'profile':4,'blog':5,'friend':6,'score':7};
function ppy_get_friend_Horibar_ctx(fid,acttab){
    var ctx = {
        'tabs':[
            {'text':'News','action':"papayajs.go('home?uid="+fid+"')"},
            {'text':'Avatar','action':"papayajs.go('avatar?uid="+fid+"')"},
            {'text':'Comments','action':"papayajs.go('comments?uid="+fid+"')"},
            {'text':'Photo','action':"papayajs.go('photos?uid="+fid+"')"},
            {'text':'Profile','action':"papayajs.go('profile?uid="+fid+"')"},
            {'text':'Blog','action':"papayajs.go('miniblog?uid="+fid+"')"},
            {'text':'Friends','action':"papayajs.go('friends?uid="+fid+"')"},
            {'text':'Game scores','action':"papayajs.go('gamescore?uid="+fid+"')"}
        ]
    };
    ctx.tabs[frdhoritabs[acttab]].action = 'void(0)';
    ctx.tabs[frdhoritabs[acttab]].active = 1;
    return ctx;
}