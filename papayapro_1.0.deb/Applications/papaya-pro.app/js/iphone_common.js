function $(id){return document.getElementById(id);}
function del(el){el.parentNode.removeChild(el);}
function getElementByTagNameAndAttr(tagName,attrName,v){
    es = this.getElementsByTagName(tagName);
    if (attrName!=''){
        var els = [];
        var l = es.length;
        for (i=0;i<l;i++){
            if (es[i].getAttribute(attrName)==v) els.push(es[i]);
        }
        return els;
    }
    else return es;
}
function getElementByTagNameAndNotAttr(tagName,attrName,v){
    es = this.getElementsByTagName(tagName);
    if (attrName!=''){
        var els = [];
        var l = es.length;
        for (i=0;i<l;i++){
            if (es[i].getAttribute(attrName)!=v) els.push(es[i]);
        }
        return els;
    }
    else return es;
}
function gc(tagName,className){
	es = this.getElementsByTagName(tagName);
    if (className!=''){
        var els = [];
        var l = es.length;
        for (i=0;i<l;i++){
            if (es[i].hasClass(className)) els.push(es[i]);
        }
        return els;
    }
    else return es;
}
function injectBefore(el){el.parentNode.insertBefore(this,el);}
function injectInto(el){if (el.childNodes.length!=0)el.insertBefore(this,el.childNodes[0]);else el.appendChild(this);}
function hasClass(c){return this.className.contains(c, ' ');}
function addClass(c){if(!this.hasClass(c))this.className=(this.className+' '+ c).clean();}
function removeClass(c){this.className = this.className.replace(new RegExp('(^|\\s)'+c+'(?:\\s|$)'),'$1').clean();}
Element.prototype.G = getElementByTagNameAndAttr;
Element.prototype.GN = getElementByTagNameAndNotAttr;
Element.prototype.GC = gc;
Element.prototype.injectBefore = injectBefore;
Element.prototype.injectInto = injectInto;
Element.prototype.hasClass = hasClass;
Element.prototype.addClass = addClass;
Element.prototype.removeClass = removeClass;
Element.prototype.getNextSibling = function(){
	var el = this.nextSibling;
	while(el && !el.tagName) el = el.nextSibling;
	return el;
}
function toQS(o){
	var qs = [];
	for (var property in o)
	    qs.push(encodeURIComponent(property) + '=' + encodeURIComponent(o[property]));
	return qs.join('&');
};
String.prototype.test=function(regex, params){ return ((typeof(regex) == 'string') ? new RegExp(regex, params) : regex).test(this);};
String.prototype.replaceAll=function(AFindText,ARepText){raRegExp=new RegExp(AFindText,"g");return this.replace(raRegExp,ARepText)};
String.prototype.sliceBetween=function(start,end){return this.slice(this.indexOf(start)+start.length,this.indexOf(end));}
String.prototype.contains=function(string,s){return(s)?(s+this+s).indexOf(s+string+s)>-1:this.indexOf(string)>-1;}
String.prototype.clean=function(){return this.replace(/\s{2,}/g,' ').trim();}
String.prototype.trim=function(){return this.replace(/^\s+|\s+$/g, '');}
String.prototype.toInt=function(){return parseInt(this);}
String.prototype.startsWith=function(s){return this.substr(0,s.length)==s;}
function evalJSON(str){	return ((typeof(str) != 'string') || !str.test(/^("(\\.|[^"\\\n\r])*?"|[,:{}\[\]0-9.\-+Eaeflnr-u \n\r\t])+?$/)) ? str : eval('(' + str + ')'); }
function show(el){el.style.display='block';}
function hide(el){el.style.display='none';}
function disable(el){
    el.setAttribute('_onclick',el.getAttribute('onclick'));
    el.setAttribute('onclick','return false');
}
function enable(el){
    el.setAttribute('onclick',el.getAttribute('_onclick'));
    el.removeAttribute('_onclick');
}
function htmlpalert(msg,warn){
var c = $('content');
var m = document.createElement('DIV');
m.className = 'modal_background';
m.style.height = document.body.scrollHeight+'px';
m.id='m';
var w = document.createElement('DIV');
if (warn) w.className = 'warning';
else w.className = "success";
w.id='w';
w.style.marginTop = (window.pageYOffset+150)+'px';
w.innerHTML='<p>'+msg+'</p><div class="centertext"><a class="btn" href="javascript:del($(\'m\'));">&nbsp;&nbsp;OK&nbsp;&nbsp;</a></div>';
m.appendChild(w);
c.appendChild(m);
show(m);
show(w);
}
function palert(msg,warn){
window.alertvar = '{"text":"'+msg+'","icon":'+(warn?'1':'0')+'}';
document.location = "papaya://showalert~alertvar";
}

function toJSONString(obj){
    var t = typeof obj;
    if (t=='object' && obj.constructor== Array) t = 'array';
	switch(t){
		case 'string':
			return '"' + obj.replace(/(["\\])/g, '\\$1') + '"';
		case 'array':
		    var a = [];
		    for (var i=0;i<obj.length;i++) a.push(toJSONString(obj[i]));
			return '[' + a.join(',') + ']';
		case 'object':
			var s = [];
			for (var property in obj) s.push(toJSONString(property) + ':' + toJSONString(obj[property]));
			return '{' + s.join(',') + '}';
		case 'number':
			if (isFinite(obj)) break;
		case false:
			return 'null';
	}
	return String(obj);
}
function doAJAX(href,rid,args,cb){
    var s = toQS(args);
    var url = s==''?href:(href+(href.indexOf('?')==-1?'?':'&')+s);
    document.location = 'papaya://ajax~'+cb+'~'+rid+'?'+url;
}
function getBaseURL(){
    try{
        var u = window.Papaya.baseURL();
        return u;
    }
    catch(E){return '';}
}
function loadJSON(href, args, cb,pgsTitle,pgsContent){
    var req = new XMLHttpRequest();
    req.onerror = function(){
        try{window.Papaya.progressDlgHide();}catch(E){}
        cb(false);
    };
    req.onreadystatechange = function(){
        if (req.readyState == 4){
            try{window.Papaya.progressDlgHide();}catch(E){}
            cb(evalJSON(req.responseText));
        }
    };
    var sid = getsid();
    if (href.indexOf('sid=')!=-1){
        href = href.replace(/sid=[\d]+/,'sid='+sid);
    }
    else args.sid = sid;
    var s = toQS(args);
    var url = s==''?href:(href+(href.indexOf('?')==-1?'?':'&')+s);
    url = getBaseURL()+url;
    if(pgsTitle && pgsContent){
        try{
            window.Papaya.progressDlgShow_msg_(pgsTitle, pgsContent);
        }catch(E){}
    }
    req.open("GET", url, true);
    req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    req.send(null);
}
function getValue(el){
    switch(el.tagName.toLowerCase()){
        case 'select': return el.value;
        case 'input': if (!(el.checked && (el.type == 'checkbox' || el.type == 'radio')) && (!(el.type=='hidden'||el.type=='text'||el.type=='password'))) break;
        case 'textarea': if (el.value != '') return el.value;
    }
    return false;
}
function submitformJSON(el,cb,pgsTitle,pgsContent){
    if (!el.getAttribute('action')) return;
    var inputs = el.getElementsByTagName('input');
    var sels = el.getElementsByTagName('select');
    var textareas = el.getElementsByTagName('textarea');
    var allels = [];
    for (var i=0;i<inputs.length;i++) allels.push(inputs[i]);
    for (var i=0;i<sels.length;i++) allels.push(sels[i]);
    for (var i=0;i<textareas.length;i++) allels.push(textareas[i]);
    var qs = '';
    for (var i=0;i<allels.length;i++){
        var name = allels[i].name;
        var value = getValue(allels[i]);
        if (value === false || !name || allels[i].disabled){
            continue;
        }
        else qs += '&'+name+'='+encodeURIComponent(value);
    }
    qs += '&sid='+getsid();
    qs = qs.substr(1);
    var req = new XMLHttpRequest();
    req.onerror = function(){
        window.Papaya.progressDlgHide();
        cb(false);
    };
    req.onreadystatechange = function(){
        if (req.readyState == 4){
            window.Papaya.progressDlgHide();
            cb(evalJSON(req.responseText));
        }
    };
    var url = (window.Papaya.baseURL?window.Papaya.baseURL():'')+el.getAttribute('action') + (qs?'?':'') + qs;
    if(window.Papaya.progressDlgShow_msg_ && pgsTitle && pgsContent)
        window.Papaya.progressDlgShow_msg_(pgsTitle, pgsContent);
    req.open("GET", url, true);
    req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    req.send(null);
}
function cropImage(el,width,height){
	if (!width) width=60;
	if (!height) height=60;
    if (el.width==0){
        setTimeout(cropImage,500,el,width,height);
        return;
    }
    if (el.width<width && el.height<height) return;
    if (el.width<=el.height){
        el.style.marginTop = (el.width-el.height)*(height/2)/el.height+'px';
        el.width = width;
    }
    else{
        el.style.marginLeft = (el.height-el.width)*(width/2)/el.width+'px';
        el.height = height;
    }
}
function visituser(d){
	var uid = 0;
	if (typeof d!='number'){
    	d.preventDefault();
    	uid = d.target.getAttribute('uid');
    }
    else uid = parseInt(d);
    document.location = 'papaya://slidenewpage?home?uid='+uid;
    return false;
}
function checkmail(){
    var cnt = 0;
    var u = $('unreadmailcnt');
    if(!$('donotcheckmail')){
        if (window.Papaya.mailUnreadCount){
            cnt = window.Papaya.mailUnreadCount();
            if (cnt!=0){
                u.innerHTML=cnt;
                u.style.display="inline-block";
            }
            else hide(u);
        }
        else{
            loadJSON('checkformail',{},function(r){if(r.count && r.count!=0){u.innerHTML=r.count;u.style.display="inline-block";}});
        }
    }
    else return;
}
function updatemailstatus(){
    if (!$('unreadmailcnt')) return;
    var u = $('unreadmailcnt');
    var cnt = window.Papaya.mailUnreadCount();
    if (cnt!=0){
        u.innerHTML=cnt;
        u.style.display="inline-block";
    }
    else hide(u);
}
function showuserframe(id,name,country,gs,avtver,hpver){
	var m = document.createElement('DIV');
	m.className = 'modal_background';
	m.style.height = document.body.scrollHeight+'px';
	m.id = 'uf_'+id;
    var d = document.createElement('DIV');
    d.className = "userframe";
    d.style.top = (window.pageYOffset+5)+'px';
    var s = '<div class="useravatar"><img src="getavatar?uid='+id+'&amp;v='+avtver+'"/></div><div class="userinfo"><span class="close" onclick="del('+m.id+')"><img src="../images/deltrans.png"/></span>'+
        '<h1>'+name+'</h1>';
    if (country && country!='')
        s+='<p>Country: '+country+'</p>';
    if (gs && gs!='')
        s+='<p>Game score: '+gs+'</p>';
    s+='<div class="homepic right"><img id="strangerhp" src="gethomepic?uid='+id+'&amp;res=0&amp;v='+hpver+'"/></div></div><div class="utils centertext"><div><a href="compose?recipients='+id+'" class="btn sendmailbtn" style="width:120px">Send a message</a></div><div><a href="javascript:del('+m.id+');addasfriend('+id+')" class="btn addbtn" style="width:120px">Add as friend</a></div></div>';
    d.innerHTML = s;
    m.appendChild(d);
    $('content').appendChild(m);
    cropImage($('strangerhp'));
}
function addasfriend(id){
	loadJSON('sendfriendrequest',{'uid':id},function(r){
		if (r.added)
			palert("Your friend request has been sent.");
		else
			palert("Failed to send your friend request. Please try again later.",1);
		return;
	});
}
Element.prototype.getTop = function(){
	var el = this, left = 0, top = 0;
	do {
		left += el.offsetLeft || 0;
		top += el.offsetTop || 0;
		el = el.offsetParent;
	} while (el);
	return top;
}
Array.prototype.remove = function(el) {
    var i = this.indexOf(el);
    if (i<0) return;
    var rest = this.slice(i + 1 || this.length);
    this.length = i < 0 ? this.length + i : i;
    return this.push.apply(this, rest);
};
function updatesid(sid){if($('sessionid'))$('sessionid').value=sid;}
function getsid(){if($('sessionid'))return $('sessionid').value;else return 0;}
function genHoriBar(){
    if(!$('genhoribar')) return;
    else{
        gh = $('genhoribar').value;
        if (gh==0) return;
        else if(gh==1){
            myhoribarvar.tabs[myhoritabs[$('activetab').value]].action = 'void(0)';
            myhoribarvar.tabs[myhoritabs[$('activetab').value]].active = 1;
            window.horibar = toJSONString(myhoribarvar);
        }
        else if(gh==2){
            window.horibar = toJSONString(genfrdhoribarvar($('friendID').value,$('activetab').value));
        }
        else if(gh==3){
            window.horibar = toJSONString(genCircleHoribarVar($('circleID').value,$('activetab').value));
        }
    }
}

var lazy_image_queue = [];
var lazy_image_timer = null;
var lazy_image_ticket = 0;

function getAbsPath(s){
var l = location,h,p,f,i;
if (/^\w+:/.test(s))
return s;
h = l.protocol+'//'+l.host;
if (s.indexOf('/')==0)
return h + s;
p = l.pathname.replace(/\/[^\/]*$/, '');
f = s.match(/\.\.\//g);
if (f){
s = s.substring(f.length*3);
for (i = f.length;i>0;i--)
p = p.substring(0,p.lastIndexOf('/'));
}
return h+p+'/'+s;
}

function parseimgsrc(imgsrc) {
    var result = imgsrc;    
    var type = 0;
    if(imgsrc.startsWith('papaya_cache_')){
        if (imgsrc.startsWith('papaya_cache_file://')){
            result = imgsrc.substr(20);
            type = 1;
        }
        else if (imgsrc.startsWith('papaya_cache_bundle://')){
            result = imgsrc.substr(21);
            type = 2;
        }
    }

    result = getAbsPath(result).replaceAll('&', '&amp;');
    if (type < 2)
        return 'papaya_cache_file://'+result;
    else
        return 'papaya_cache_bundle://'+result;
}

function lazyImageTimerHandler(interval) {
    lazy_image_ticket += interval;
    var papaya = window.Papaya;
    papaya.log_('cacheTimerHandler');
    var tmp = [];

    while (lazy_image_queue.length > 0) {
        var img = lazy_image_queue.pop();
        var imgsrc = img.getAttribute('imgsrc');
        if (imgsrc != null && imgsrc.length > 0) {
            imgsrc = parseimgsrc(imgsrc);
            var cachePath = papaya.cachePath_(imgsrc);
            if (cachePath != imgsrc)
                img.src = 'file://' + cachePath;
            else
                tmp.push(img);
        }        
    }
    lazy_image_queue = tmp;
    if (lazy_image_queue.length > 0 && lazy_image_ticket < 180 * 1000)
        lazy_image_timer = setTimeout(lazyImageTimerHandler,interval,interval);
    else {
        lazy_image_timer = null;
        lazy_image_ticket = 0;
    }
    papaya.log_("cacheTimerHandler ends");
}
function processLazyImage(interval) {
    var lazyimgs = document.body.G('img','lazy','1');
    lazy_image_ticket = 0;
    var papaya = window.Papaya;
    papaya.log_("processLazyImage " + lazyimgs.length);
    if (lazyimgs.length > 0) {
        var prefix = 'file://';
        for (var i = 0; i < lazyimgs.length; i++) {
            var img = lazyimgs[i];
            var cache = img.getAttribute('cache');
            var imgsrc = img.getAttribute('imgsrc');

            if (imgsrc != null && imgsrc.length > 0) {
                if (imgsrc.substr(0, prefix.length) == prefix) {
                    img.src = imgsrc;
                } else {
                    if (cache == '0')
                        img.src = imgsrc;
                    else {
                        var tmp = parseimgsrc(imgsrc);
                        var cachePath = papaya.cachePath_(tmp);
                        if (cachePath == tmp)
                            lazy_image_queue.push(img);
                        else 
                            img.src = 'file://' + cachePath;
                    }
                }
            }            
        }
    }

    if (lazy_image_timer == null && lazy_image_queue.length > 0) { 
        papaya.log_('start timer');
        lazy_image_timer = setTimeout(lazyImageTimerHandler,interval,interval);//setTimeout('lazyImageTimerHandler('+interval+')', interval);
    } else if (lazy_image_timer) papaya.log_('dont start timer, exists');
    else papaya.log_('dont start timer, empty lazy images');
}
function createInputs(){
    var lis = document.body.GC('li','input');
    for(var i=0;i<lis.length;i++){
        var s = '';
        var lb = lis[i].getAttribute('label');
        if (lb)
            s += '<label>'+lb+'</label>';
        else s += '<label></label>';
        var ph = lis[i].getAttribute('placeholder');
        if (ph)
            s += '<placeholder>'+ph+'</placeholder>';
        else s += '<placeholder></placeholder>';
        var txt = lis[i].getAttribute('text');
        var tid = '';
        if (lis[i].getAttribute('textid'))
            tid = ' id="'+lis[i].getAttribute('textid')+'"';
        if (txt)
            s+= '<text'+tid+'>'+txt+'</text>';
        else
            s += '<text'+tid+'></text>';
        lis[i].innerHTML = s;
    }
    
    var lblength = 0;
    var lbs = document.body.getElementsByTagName('label');
    for (var i=0;i<lbs.length;i++){
        var lblen = lbs[i].clientWidth;
        if (lbs[i].parentNode.tagName.toLowerCase()=='li' && lblen>lblength)
            lblength = lblen;
    }
    for (var i=0;i<lis.length;i++){
        lis[i].getElementsByTagName('label')[0].style.width = lblength+'px';
        var clk = lis[i].getAttribute('onclick');
        if (clk) lis[i].setAttribute('onclick','hide(this.getElementsByTagName("placeholder")[0]);'+clk);
        else lis[i].setAttribute('onclick','hide(this.getElementsByTagName("placeholder")[0]);');
        if (!lis[i].getElementsByTagName('text')[0].innerHTML)
            lis[i].getElementsByTagName('placeholder')[0].style.display = 'inline';
    }
}
function refreshInputs(){
    var lis = document.body.GC('li','input');
    for (var i=0;i<lis.length;i++){
        if (!lis[i].getElementsByTagName('text')[0].innerHTML)
            lis[i].getElementsByTagName('placeholder')[0].style.display = 'inline';
    }
}

var papayajs = {
go : function(uri){
    document.location = 'papaya://slideno?'+uri;
},
slidenewpage : function(uri){
    document.location = 'papaya://slidenewpage?'+uri;
},
slideto : function(uri,direction){
    if(!direction)direction='right';
    document.location = 'papaya://slideto'+direction+'?'+uri;
},
slideback : function(){
    document.location = "papaya://slideback";
},
createselector : function(jsonvar){
    window.customselectorstr = toJSONString(jsonvar);
    document.location = 'papaya://createselector~customselectorstr';
},
switchtab : function(tabname,uri){
    document.location = "papaya://switchtab~"+tabname+"?"+uri;
},
showkeyboard : function(jsonvar){
    window.kbjsonstr = toJSONString(jsonvar);
    document.location = 'papaya://showkeyboard~kbjsonstr';
},
createkeyboard : function(cb,titl,id,init,returntyp,typ){
    var jsonvar = {'title':titl?titl:'','type':typ?typ:"Default",'callback':cb,'initValue':init?init:'','returnKeyType':returntyp?returntyp:"Default",'id':id?id:'nosuchelement'};
    window.kbjsonstr = toJSONString(jsonvar);
    document.location = 'papaya://showkeyboard~kbjsonstr';
},
showtextarea : function(jsonvar){
    window.tajsonstr = toJSONString(jsonvar);
    document.location = 'papaya://showmultiplelineinput~tajsonstr';
},
createtextarea : function(cb,id,typ,init,returntyp){
    var jsonvar = {'type':typ?typ:'Default','callback':cb,'initValue':init?init:'','actionbtn':returntyp?returntyp:'','id':id?id:'nosuchelement'};
    window.tajsonstr = toJSONString(jsonvar);
    document.location = 'papaya://showmultiplelineinput~tajsonstr';
},
showphotoselector : function(jsonvar){
    window.psjsonstr = toJSONString(jsonvar);
    document.location = 'papaya://showpictures~psjsonstr';
}
};
window.addEventListener('load',genHoriBar,false);