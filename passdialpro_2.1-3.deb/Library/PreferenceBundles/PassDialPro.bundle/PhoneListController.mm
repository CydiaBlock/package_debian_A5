#import <Preferences/Preferences.h>

@interface PhoneListController : PSListController
@end

@implementation PhoneListController

- (id)specifiers {
	if(_specifiers == nil) {
		_specifiers = [[self loadSpecifiersFromPlistName:@"PhoneList" target:self] retain];
	}
	return _specifiers;
}

@end