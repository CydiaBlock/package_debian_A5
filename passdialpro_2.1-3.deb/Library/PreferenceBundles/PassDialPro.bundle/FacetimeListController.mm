#import <Preferences/Preferences.h>

@interface FacetimeListController : PSListController
@end

@implementation FacetimeListController

- (id)specifiers {
	if(_specifiers == nil) {
		_specifiers = [[self loadSpecifiersFromPlistName:@"FacetimeList" target:self] retain];
	}
	return _specifiers;
}



@end