//
//  ShoutDown.m
//  ShoutDown
//
//  Created by AQUA on 2014/06/20.
//  Copyright (c) 2014年 __MyCompanyName__. All rights reserved.
//

// LibActivator by Ryan Petrich
// See https://github.com/rpetrich/libactivator

#import <Preferences/Preferences.h>
#import <UIKit/UIKit.h>
#import <Social/Social.h>
#import <Foundation/Foundation.h>


@interface MagicBlink: PSListController

{
    
}
@end

@implementation MagicBlink
- (id)specifiers {
    if(_specifiers == nil) {
        _specifiers = [[self loadSpecifiersFromPlistName:@"MagicBlink" target:self] retain];
        
        PSSpecifier* spec = [PSSpecifier preferenceSpecifierNamed:@"tweetMagicBlink" target:self set:nil get:nil detail:nil cell:PSGroupCell edit:nil];
        /////[spec setProperty:@"ColorDisplayCell"  forKey:@"headerCellClass"];
        /////[spec setProperty:@"2" forKey:@"alignment"];
        ////[spec setProperty:@"(Tap to update color)"  forKey:@"footerText"];
        ////[self insertSpecifier:spec atIndex:0];
        
        
        [self speciferPerformedAction:spec];
        //[self updateColor];
        
        // CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), (__bridge void *)self, toggle, CFSTR("com.jontelang.boover/colorupdated"), NULL, CFNotificationSuspensionBehaviorCoalesce);
        //[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateColor) name:@"com.jontelang.boover/colorupdated" object:nil];
    }
    return _specifiers;
}





-(void)speciferPerformedAction:(PSSpecifier*)specifier {
    

    //アラートの表示
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                       message:@"テスト成功！！"
                                      delegate:self
                             cancelButtonTitle:nil
                             otherButtonTitles:nil
             ];
    [alert show];
    
    //アラートを自動的に閉じる
    [alert dismissWithClickedButtonIndex:0 animated:NO];
    
   
}
@end

// vim:ft=objc