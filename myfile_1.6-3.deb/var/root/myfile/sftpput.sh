#!/bin/bash

/var/root/myfile/sftp_put.sh "$1" "$2" "$3" "$4"
