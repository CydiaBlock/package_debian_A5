#!/bin/bash

/var/root/myfile/sftp_rm.sh "$1" "$2" "$3"
