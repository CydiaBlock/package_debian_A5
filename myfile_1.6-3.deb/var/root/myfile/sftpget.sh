#!/bin/bash

/var/root/myfile/sftp_get.sh "$1" "$2" "$3" "$4"
