//
//  ___FILENAME___
//  ___PACKAGENAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

#import "___FILEBASENAME___.h"

@implementation ___FILEBASENAMEASIDENTIFIER___

-(NSArray*)buttons {
    return [NSArray arrayWithObject:[[LSCEButton alloc] init]];
}
-(void)buttonWillAppear:(LSCEButton*)button {
    /*
    if (something)
        [button setImage:[UIImage imageNamed:@"Image1.png"]];
    else
        [button setImage:[UIImage imageNamed:@"Image2.png"]];
    */
}
-(void)buttonWasPressed:(LSCEButton*)button {
    // Do some stuff
}
-(void)buttonWillDisappear:(LSCEButton*)button {
    // Release what should be released
}

@end
