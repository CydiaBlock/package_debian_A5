//
//  LSCEListener.h
//  LSCEListener
//
//  Created by Nicolas Montvernay on 21/03/12.
//  Copyright (c) 2012 DiAifU. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LSCEButton.h"

@protocol LSCEListener <NSObject>

@required
-(NSArray*)buttons;
-(void)buttonWillAppear:(LSCEButton*)button;

@optional
-(void)buttonWasPressed:(LSCEButton*)button;
-(void)buttonWillDisappear:(LSCEButton*)button;

@end