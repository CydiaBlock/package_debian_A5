//
//  LSCEButton.h
//  LSCEListener
//
//  Created by Nicolas Montvernay on 21/03/12.
//  Copyright (c) 2012 DiAifU. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface LSCEButton : NSObject {
@private
    UIButton* _button;
    BOOL _longPressSet;
    BOOL _canSetLongPress;
}
@property(nonatomic, readonly)BOOL canSetLongPress;
@property(nonatomic, readonly)UILongPressGestureRecognizer* longPressGestureRecognizer;
-(void)setImage:(UIImage*)image;
-(void)setLongPressGestureRecognizer:(UILongPressGestureRecognizer *)recognizer;
@end