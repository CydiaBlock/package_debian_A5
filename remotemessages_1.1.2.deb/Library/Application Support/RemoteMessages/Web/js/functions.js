/*! * Remote Messages v1.1.2
 * Shared Functions
 * Copyright (c) 2013 Beast Soft - http://beastsoft.co.uk/ 
 */
var $curSelectionRange;

function pushError (message, type) {
	var paragraph = $("<p>", {
		'text': message,
		'class' : type ? type : null
	});
	var span = $("<span>", {
		'html': '&#x00d7;'
	});
	$(paragraph).append($(span));
	$("#flash").append(paragraph);
}

function clearErrors (type) {
	if (type) {
		$("#flash p[class='"+ type +"']").remove();
	} else {
		$("#flash").empty();
	}
}

$.fn.getPreText = function () {
	var ce = $("<pre />").html(this.html());
	if ($.browser.webkit)
		ce.find("br").replaceWith(function() { return "\n" + this.innerHTML; });
		ce.find("div").replaceWith(function() { return "\n" + this.innerHTML; });
	if ($.browser.msie)
		ce.find("p").replaceWith(function() { return this.innerHTML + "<br>"; });
	if ($.browser.mozilla || $.browser.opera || $.browser.msie)
		ce.find("br").replaceWith("\n");
	return ce.text();
};

function getMinutesDiffBetweenDates (dt1, dt2) {
	var d1 = new Date(dt1 * 1000);
	var d2 = new Date(dt2 * 1000);
	var diffMS = Math.abs(d1 - d2);
	return Math.floor((diffMS/1000)/60);
}

function getDateString (dt) {
	var date = new Date(dt * 1000);
	var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
	var hours = date.getHours();
	var minutes = date.getMinutes();
	var ampm = hours >= 12 ? 'PM' : 'AM';
	var hours = hours % 12;
		hours = hours ? hours : 12;
	var datePretty =
		("0" + date.getUTCDate()).slice(-2) + " " +
		months[date.getMonth()] + " " +
		date.getUTCFullYear() + " " +
		("0" + hours).slice(-2) + ":" +
		("0" + date.getMinutes()).slice(-2) + " " + ampm;
	return datePretty;
}

function insertAtCaret (object) {
	var node = $(object).get(0);
	var editor = $("#editor").get(0);
	restoreSelection($curSelectionRange);
	editor.focus();
	if (typeof window.getSelection != "undefined") {
		var sel = window.getSelection();
		if (sel.getRangeAt && sel.rangeCount) {
			var range = sel.getRangeAt(0);
			range.deleteContents();
			range.insertNode(node);
			range = range.cloneRange();
			range.setStartAfter(node);
			range.collapse(true);
			sel.removeAllRanges();
			sel.addRange(range);
			$curSelectionRange = range;
		}
	} else if (document.selection && document.selection.createRange) {
		range = document.selection.createRange();
		range.pasteHTML(text);
		range.select();
	}
}

function saveSelection () {
	$curSelectionRange = 0;
	if (window.getSelection) {
		sel = window.getSelection();
		if (sel.getRangeAt && sel.rangeCount) {
			$curSelectionRange = sel.getRangeAt(0);
		}
	} else if (document.selection && document.selection.createRange) {
		$curSelectionRange = document.selection.createRange();
	}
}

function restoreSelection (range) {
	if (range) {
		if (window.getSelection) {
			sel = window.getSelection();
			sel.removeAllRanges();
			sel.addRange(range);
		} else if (document.selection && range.select) {
			range.select();
		}
	}
}

var extToMimes = {
	'jpeg': 'image/jpeg',
	'jpg': 'image/jpeg',
	'jpe': 'image/jpeg',
	'png': 'image/png',
	'gif': 'image/gif',
	'bmp': 'image/bmp',
	'mov': 'video/quicktime',
	'3gp': 'video/3gpp',
	'ogg': 'video/ogg',
	'mp4': 'video/mp4',
	'm4v': 'video/x-m4v',
	'mpg': 'video/mpeg',
	'avi': 'video/x-msvideo',
	'mkv': 'video/x-matroska'
}

function supportsVideo () {
	return !!document.createElement('video').canPlayType;
}

function canShowMediaFile (filename) {
	var mimeType;
	if (extToMimes.hasOwnProperty(getExtension(filename))) {
		mimeType =  extToMimes[getExtension(filename)];
	} else {
		return false;
	}
	if (mimeType.substring(0, 5) == 'image') {
		return true;
	}
	if (mimeType.substring(0, 5) == 'video') {
		if ($.browser.chrome && mimeType == 'video/quicktime') {
			return true;
		}
		if (!supportsVideo()) {
			return false;
		}
		var video = document.createElement('video');
		if (video.canPlayType && video.canPlayType(mimeType)) {
			return true;
		} else {
			return false;
		}
	}
	return false;
}