WEB_SOCKET_SWF_LOCATION = "/js/socket_ie.swf";
WEB_SOCKET_DEBUG = false;

var $wsWebSocketConnectionUrl = "%%WEBSOCKET_URL%%";
var $wsReconnectionAttemptsCounter = 0;
var ws = 0;

function wsOnClose() {
	$("#status").animate({'opacity': 0.1}, 250);
	clearErrors('errRetry');
	pushError("Connection to iPhone lost. Retrying connection (attempt " + $wsReconnectionAttemptsCounter + ")", 'errRetry');
	setTimeout(function() {
		attemptReconnect();
	}, (Math.pow(1.5, $wsReconnectionAttemptsCounter) -1) * 1000);
}

function initWebSocket() {
	ws = new WebSocket($wsWebSocketConnectionUrl);

	ws.onopen = function() {
		clearErrors();
		$wsReconnectionAttemptsCounter = 0;
		loadConversations();
	}

	ws.onmessage = function(evt) {
		onMessage(evt);
	}

	ws.onclose = wsOnClose;

	ws.onerror = function(evt) {
		$("#status").animate({'opacity': 0.1}, 250);
		attemptReconnect();
	}
}

function attemptReconnect() {
	$wsReconnectionAttemptsCounter++; 
	initWebSocket();
}