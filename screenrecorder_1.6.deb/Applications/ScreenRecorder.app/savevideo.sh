#!/bin/bash
cd /var/mobile/Media/ScreenRecorder/


if [ -e ./0.mov ] ; then

if [ -e ./audio.aiff ] ; then

videoName=$(ls [0-9]* | sed 's/_/ _/' | sort -rn | awk '{printf "%d", $1 + 1; exit}')

/usr/local/bin/ffmpeg -r 2 -i ./image%d.png -i ./audio.aiff ./$videoName.mov

fi

if [ ! -e ./audio.aiff ] ; then

videoName=$(ls [0-9]* | sed 's/_/ _/' | sort -rn | awk '{printf "%d", $1 + 1; exit}')

/usr/local/bin/ffmpeg -r 2 -i ./image%d.png ./$videoName.mov

fi

fi

if [ ! -e ./0.mov ] ; then

if [ -e ./audio.aiff ] ; then


/usr/local/bin/ffmpeg -r 2 -i ./image%d.png -i ./audio.aiff ./0.mov

fi

if [ ! -e ./audio.aiff ] ; then


/usr/local/bin/ffmpeg -r 2 -i ./image%d.png ./0.mov

fi

fi

rm *png
rm ./audio.aiff