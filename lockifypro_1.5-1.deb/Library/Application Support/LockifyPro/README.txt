Place your .png’s here and they will show up on:
settings —> Lockify Pro —> Slider —> Slider

Image must be transparent and must be a .png file to show up on the list.
Regular sizes are:
26x56
20x46

If you upload some images to cydia for others to download, please be sure to install at the correct directory.
/Library/Application Support/LockifyPro/