Etched Glass
Created by Foundforgood89

Descriptions: 
Who Knew Perfection could be Beaten?
Presenting Chapter 2 in the iDevice Theming store by FoundForGood89: The brand new theme "Etched Glass". This amazing new theme uses transparent class images to take full advantage of the amazing weather widgets provided. Using a modded combination of "Engraved Wood"s unique fullscreen weather widgets and Ian Nicoll's revolutionary UniAW animated weather widgets, I have created a unique and amazing theme. Never need to look out of a window again with this animated weather widget with over 30 unique forecasts! Not to mention the beautiful glassy feel of this ideal theme for any user!

Features:
-5 different weather widgets!: -homescreen animated WW
-lockscreen animated WW (for both lockinfo and non-lockinfo users),
-homescreen non-animated WW,
-lockscreen non-animated WW for lockinfo
-lockscreen non-animated WW for those not using lockinfo
-glass icons for all stock icons (more to come)
-glassy masking for all appstore apps!
-perpagehtml customization for fluid movement of pages and spotlight customization
-flashing page indicators
-Basic UI Interface: more to come
-SpringJump ready
-Optimized for Folder Enhancer, Iconoclasm, and Shrink
-Each page can hold 11 icons and each folder page can hold up to 20 icons!

More features to come in subsequent updates.

Preview Video: http://www.youtube.com/watch?v=gNcAImz7Xuo

Update Log:
V0.9
-Initial Release
V0.95
-UIImages addition
-adjust default WW refresh rate to 5min rather than 1
-adjust LS clock position
-adjust clouds presence
-Page indicator shift fix
-separated icons into new addon (Original icons)
-created new addon with AppStore masked stock/Cydia icons (masked icons
-Phone app themed
-added alternative layout for messages (original saved)
-SBSettings addon
-loaders layout
-added no lockinfo clock stylesheet to LS AniWW
-added a no page indicator option to perpagehtmls
-FAQ section to forum
-icon making videos on forum
-Icons small by default

Installation Guides (videos):

1/4: http://www.youtube.com/watch?v=r93kZ-OWFOU

2/4: http://www.youtube.com/watch?v=b3M5duR_CoY

3/4: http://www.youtube.com/watch?v=WlD09ZZIMd0

4/4: http://www.youtube.com/watch?v=QH5hxh4yTPw

Add-Ons:

HD Etched Glass Extras
HD Etched Glass SBSettings

Weather Widgets:
-HD Etched Glass HS AniWW
-HD Etched Glass LS AniWW
-HD Etched Glass HS WW
-HD Etched Glass LS WW
-HD Etched Glass LS WW for LI

Note: Icons have been removed from theme and put into 2 add-ons. The reason for this is so users can have their choice of 2 Icon sets.  Below are the two sets along with a short description describing each. Find them in Cydia.  Names are their Cydia package labels for easy looking up:

HD Etched Glass Original Icon Set:
  -This icon set is the one that was originally contained in the theme. It uses clear and colorless icons in glassy representations.  

HD Etched Glass Masked Icon Set:
  -This is an icon set that complements the theme's AppStore Icon masking. I creates masks for Stock Apple Apps and Cydia apps that are similar to the ones made by masking the AppStore apps.

Screeshots in both addons...

FAQ:
1) What iDevice software is needed to get the most of the Etched Glass Theme?
-The Paid "Required" (but not dependent) software for Etched Glass is Shrink , Iconoclasm, Folder Enhancer, and Gridlock (iBlanks should work but is not tested). These apps/tweaks are pricy, but are commonly used for themeing iDevices, and will definitely be continuously used over the course of Winterboard theme development. You would not need to pay for these each time you bought a new theme that needed them.
-The Free "Required" software is SpringJumps, PerPageHTML (PerPageHTML + should work but is untested), and Winterboard. 
-The "Optional" (themed but not necessary for full use of the theme) software is Lockinfo, iAcces, and OpenNotifier (free)
-I recommend buying iFiles aswell for easier installation. The option to SSH into the phone is also adaquit....
-To get the Five Day Weather Forcast, you must have Lockinfo and must download the extra plugin "Weather Plugin for Lockinfo" from Cydia

2) Before I enable the theme, how should I layout my pages and applications?
-This is best displayed in installation video 1. Essentially, the theme is equipped to use 5 (4 and 6 are also possible, but I have only made a limited number of SpringJumps icons so far) SpringJump icons placed in the iDevice Dock. Each page layout contains a slot for 1 large icon (the main app for that page (ex. phone in the screenshots), followed by 2 rows of 5 icons. The 2 rows of five can be apps or folders, while the Large icons and the Dock are not recommended to be Folders. Within folders, each page is equipped with a 5x4 (20 icon total) layout. 

3) How do I install?
-Use the 4 installation videos provided on this page.

4) There are so many Weather Widgets! What Weather Widgets should I download?
-There are a total of 5 weather widgets. Each individual only needs two, based on what features they wish to have. To make it easy, I have identified here which of the five are needed for each situation (iThemeSky users can delete un-needed WW's)
--If you want to have Animated Weather Widgets on both the lock screen and the Homescreen, use "HD Etched Glass HS AniWW" and "HD Etched Glass LS AniWW"
--If you want to have Animated Weather Widgets on the lock screen only, use "HD Etched Glass HS WW" and "HD Etched Glass LS AniWW"
--If you want to have Animated Weather Widgets on the Homescreen only, and ARE using Lockinfo, use "HD Etched Glass HS AniWW" and "HD Etched Glass LS WW for LI"
--If you don't want to use Animated Weather Widgets at all, and ARE using Lockinfo, use "HD Etched Glass HS WW" and "HD Etched Glass LS WW for LI"
--If you want to have Animated Weather Widgets on the Homescreen only, and ARE NOT using Lockinfo, use "HD Etched Glass HS AniWW" and "HD Etched Glass LS WW"
--If you don't want to use Animated Weather Widgets at all, and ARE NOT using Lockinfo, use "HD Etched Glass HS WW" and "HD Etched Glass LS WW"

5) I have a box for Lockinfo on my Lockscreen when I start up "HD Etched Glass LS AniWW, but I don't use Lockinfo. How do I get rid of it?
-To change from Lockinfo Mode to Non-Lockinfo mode with the Animated LS WW, open iFiles. Navigate to "/var/stash/theme.xxx/EG Lock Weather++(@2x).theme/Widgets/UniAW/" In this location there are three ".png" files. Find and delete "HomeBackground.png". Then find "HomeBackground_noLI.png" and rename it "HomeBackground.png" by removing the "_noLI" portion of its name. Then simply respring.

6) Where can I find my Location code (if using a zip code is not an option)
-step 1: go to http://weather.yahoo.com/
-step 2: look up you location using the "Enter City or Zip Code" Bar
-step 3: after having found your location, look for an orange button along the right side of the page with the letters "RSS" in it. Press it.
-step 4: After the page is loaded, look at the URL bar. at the very end, it will have a sequence that looks like this: "p=_ _ _ _ _ _ _ _%...". The gap of 8 digits is equal to your location code. enter those 8 digits into the theme. See how to put your location codes in below... 

7) How do I set my location code?
-There are several files that need to be modified to set your location code, dependent on which WW's you have. Below will display each.
-ALL USERS: all users much change the location code in each page of the perpageHTML widgets. To do this, after having moved the perpageHTML pages from the Extras theme (see installation videos if this hasn't been done yet), navigate to "/var/mobile/Library/PerPageHTML/EG-PageX/Configs/" Open the "Weather-Config.js" file. Look for the line near the top stating "var locale = "30033" and replace the 30033 with your desired location code. NOTE THAT I USED "X" TO REPRESENT ALL 5 PAGES! THIS STEP MUST BEEN DONE FOR EACH PAGE SEPRATELY AS THEY DO NOT RELY ON EACH OTHER!
-For those using the Animated WW's, navigate to "/var/stash/theme.xxx/EG ("Lock" if LS) Weather++@2x.theme/Widgets/UniAW/" and open "locationHere.js". Look for the line near the top stating "var locale = "30033" and replace the 30033 with your desired location code. 
-For those with Non-Animated WW's, navigate to "/var/stash/theme.xxx/EG ("Lock" if LS) Weather ("LI" if the LI LS WW)@2x.theme/Widgets/Configs/" and open "Weather-Config.js". Look for the line near the top stating "var locale = "30033" and replace the 30033 with your desired location code.

8) How do I change the fahrenheit to celsius? 
-To do this, after having moved the perpageHTML pages from the Extras theme (see installation videos if this hasn't been done yet), navigate to "/var/mobile/Library/PerPageHTML/EG-PageX/Configs/" Open the "Weather-Config.js" file. Look for the line near the top stating "var isCelsius = false" and change false to true. NOTE THAT I USED "X" TO REPRESENT ALL 5 PAGES! THIS STEP MUST BEEN DONE FOR EACH PAGE SEPRATELY AS THEY DO NOT RELY ON EACH OTHER!

9) My page indicators aren't lining up with the five page indentations. How do I fix this?
-I still have not found the reason for this bug. However, I have created a fix for those who are experiencing this problem. Please follow the steps below: navigate to "var/mobile/Library/PerPageHTML/EG-PageX/PageIndicator/Private/" Find and delete the file "Animation.css". Then find the file "Animation.shift.css" and rename it to "Animation.css" removing the ".shift" from it. NOTE THAT I USED "X" TO REPRESENT ALL 5 PAGES! THIS STEP MUST BEEN DONE FOR EACH PAGE SEPRATELY AS THEY DO NOT RELY ON EACH OTHER!

10) I don't like the Page Indicators. How Do I turn them off?
-I have created a quick fix for this aswell. Follow the steps below: navigate to "var/mobile/Library/PerPageHTML/EG-PageX/Weather/" Find and delete the file "Weather.html". Then find the file "Weather.noPI.html" and rename it to "Weather.html" removing the ".noPI" from it. NOTE THAT I USED "X" TO REPRESENT ALL 5 PAGES! THIS STEP MUST BEEN DONE FOR EACH PAGE SEPRATELY AS THEY DO NOT RELY ON EACH OTHER!

11) I do not see the "Large" and "Small" Folders from the installation video that contains the Large and Small Icons. Where are they?
-That was a glitch on my part where I forgot to include them in v0.9 beta. This will be fixed in v0.95.

12) I no longer have any icons in the theme. Where did they go?
-I have decided to make two Icon sets for the theme. They are now both separate downloads. The first is "HD Etched Glass Original Icon Set". These are the icons that were originally included in the theme. The second is "HD Etched Glass Masked Icon Set". These are stock and cydia icons themed to look like the Appstore Masks. Because the Masked icon set is easier to make, I recommend using it until I find time to make more Original Icon set icons which are far harder. AGAIN both icon sets are now ADDONS so you can find them in Cydia after v0.95 is released.

13) How can I make my own Icons?
-Below is 2 videos for making icons for each icon set. Please post your work here so everyone can enjoy it :-)

14) How should I request new Icons for SpringJumps or other Applications?
-Easy! You have two options: you can request theme on this forum or by emailing me at FoundForGood89@yahoo.com. Regardless of where you place the request, it is REQUIRED that you do two things: 1-Give the EXACT name of the Application on the springboard (not required for SpringJumps icons; screenshots of apps with labels are adaquit replacements) and 2-Provide either a description of the desired icon or if it is modeled off an Existing icon, a 512x512 px copy of the original icon artwork.

15) How can I support this theme and your work?
-In Lots of ways: Tell your friends; advertise it on Twitter and Facebook, Make Icons for the theme and post them here; Support users having trouble by helping them on this forum; Donate (contact me with how to do so); recommend this theme for Cydia's Featured Theme Section, Recommend this theme for MMI's Theme of the Month/Year; Like the youtube videos; and Rate the Forum with 5 stars

Support:
 for support, post your question on the MMI forum below:
http://modmyi.com/forums/iphone-4-new-skins-themes-launches/753954-release-foundforgood89s-etched-glass.html
Alternatively you can contact me by emailing me at Foundforgood89@yahoo.com

Copyright: Foundforgood89