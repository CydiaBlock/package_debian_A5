To set up the theme, 
open Config.js
and follow the instructions!

Hugs 'n kisses,
ImLemonPartying
