Set everything up via...
SETUP.js

Hugs 'n kisses,
ImLemonPartying
