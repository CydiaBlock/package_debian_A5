//  Configuration brought to you
//  by ImLemonPartying
//  Hugs 'n kisses!
//
// -------------------------------
//  Change theme color here.
//
//  Blue = 1
//  Cyan = 2
//  Green = 3
//  Orange = 4
//  Purple = 5
//  Red = 6
//  White = 7
//  Yellow = 8
//  Black = 9
var theme = "2";
//
//  RESPRING AFTER MAKING CHANGES!!
//
// -------------------------------
//  Do you want Chronos to glow?
//
//  Glow = true
//  No Glow = false
var glow = true;
//
//  How much glow?
//
//  A litte = 1
//  A lot = 2
var glowValue = "1";
//
//  RESPRING AFTER MAKING CHANGES!!
//
// -------------------------------
//  Change clock position here.
//
//  Top = 1
//  Really High = 2
//  Higher = 3
//  High = 4
//  Mid-High = 5
//  Mid = 6
//  Mid-Low = 7
//  Low = 8
//  Lower = 9
//  Really Low = 10
//  Bottom = 11
var position = "3";
//
//  RESPRING AFTER MAKING CHANGES!!
//
// -------------------------------
//  Change the size of the clock here.
//
//  Big = 1
//  Standard = 2
//  Small = 3
var clocksize = "1";
//
//  RESPRING AFTER MAKING CHANGES!!
//
// -------------------------------
//  Change time format here.
//
//  12-hour = true
//  24-hr = false
var makeit12hr = false;
//
//  RESPRING AFTER MAKING CHANGES!!
//
// -------------------------------
//  Change date format here.
//
//  dd/mm/yy = true
//  mm/dd/yy = false
var EuroDate = false;
//
//  RESPRING AFTER MAKING CHANGES!!
//
//  -------------------------------
//  Change weather settings here
//
//  Display the temperature?
//  Yes = true, No = false
var showtemp = true;
//
//  ***If showtemp=true, configure it here.
//  
//  Try your zip code first.
//  If that doesn't work, 
//  try your Weather Code (NOT WOEID)
//  from weather.com (found in the URL)
//  For Wichita, KS:  var locale = "USKS0620";
//  For Toronto, ON:  var locale = "CAXX0504";
//  
var locale = "VMXX0006";
//
//
//  celsius = true
var isCelsius = true;
//
//
//  Prefer wind chill?
var useRealFeel = true;
//
//  RESPRING AFTER MAKING CHANGES!!
//
// -------------------------------
//  Notification/media handling here.
//
//  When a notification arrives,
//  Do nothing = 0
//  Move up 300px = 1
//  Move up 200px = 2
//  Move up 100px = 3
//  Move down 100px = 4
//  Move down 200px = 5
//  Move down 300px = 6
//  Disappear = 7
var notif = "4";
//
//  When media controls are opened,
//  Do nothing = 0
//  Move up 300px = 1
//  Move up 200px = 2
//  Move up 100px = 3
//  Move down 100px = 4
//  Move down 200px = 5
//  Move down 300px = 6
//  Disappear = 7
var media = "4";
//
//  When media controls are open
//  and a notification arrives,
//  Do nothing = 0
//  Move up 300px = 1
//  Move up 200px = 2
//  Move up 100px = 3
//  Move down 100px = 4
//  Move down 200px = 5
//  Move down 300px = 6
//  Disappear = 7
var notifmedia = "4";
//
//  RESPRING AFTER MAKING CHANGES!!
//
// -------------------------------
//  Change language here.
//
//  EN = English
//  SP = Spanish
//  FR = French
//  DE = German 
//  IT  =Italian 
//  NL = Dutch 
//  TR = Turkish
var lang = "EN";
//
//  RESPRING AFTER MAKING CHANGES!!
