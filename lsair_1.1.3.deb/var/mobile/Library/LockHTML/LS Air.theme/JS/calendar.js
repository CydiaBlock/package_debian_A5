function buildCal(m, y, cM, cH, cDW, cD){
/* ENGLISH DEFAULT */
var this_weekday_name_array = new Array("Sun&nbsp;","Mon&nbsp;","Tue&nbsp;","Wed&nbsp;","Thu&nbsp;","Fri&nbsp;","Sat&nbsp;")
/* Seiva Extra Translation */
switch (lang) {
/* DUTCH */
case "nl":
var this_weekday_name_array = new Array("Zon&nbsp;","Maa&nbsp;","Din&nbsp;","Woe&nbsp;","Don&nbsp;","Vri&nbsp;","Zat&nbsp;")
break;
/* FRENCH */
case "fr":
var this_weekday_name_array = new Array("Dim&nbsp;","Lun&nbsp;","Mar&nbsp;","Mer&nbsp;","Jeu&nbsp;","Ven&nbsp;","Sam&nbsp;")
break;
/* GERMAN */
case "de":
var this_weekday_name_array = new Array("Son&nbsp;","Mon&nbsp;","Die&nbsp;","Mit&nbsp;","Don&nbsp;","Fre&nbsp;","Sam&nbsp;")
break;
/* ITALIAN */
case "it":
var this_weekday_name_array = new Array("Dom&nbsp;","Lun&nbsp;","Mar&nbsp;","Mer&nbsp;","Gio&nbsp;","Ven&nbsp;","Sab&nbsp;")
break;
/* SPANISH */
case "sp":
var this_weekday_name_array = new Array("Dom&nbsp;","Lun&nbsp;","Mar&nbsp;","Mie&nbsp;","Jue&nbsp;","Vie&nbsp;","Sab&nbsp;")
break;
}

/* Months Below Translated In Seiva Clock.js */
var mn=['January','February','March','April','May','June','July','August','September','October','November','December'];

var dim=[31,0,31,30,31,30,31,31,30,31,30,31];
var oD = new Date(y, m-1, 1);
oD.od=oD.getDay()+1; 
var todaydate=new Date()
var this_weekday = todaydate.getDay()
var this_month = todaydate.getMonth()
var this_date = todaydate.getDate()
var this_year = todaydate.getYear()
if (this_year < 2000){this_year = this_year + 1900;}
dim[1]=(((oD.getFullYear()%100!=0)&&(oD.getFullYear()%4==0))||(oD.getFullYear()%400==0))?29:28;
var t = '';
days_TM=dim[this_month];
if (this_month==0)
	days_PM=dim[11];
else
	days_PM=dim[this_month-1];
if (this_month==11)
	days_NM=dim[0];
else
	days_NM=dim[this_month+1];
k=0;
do{
	k2=this_date-k;
	if(k2<=0)
		wkstart=days_PM+k2;
	else
		wkstart=k2;
	k++;
}
while(k<=this_weekday)
for (s=0;s<7;s++){
	if (s==this_weekday){
		t+='<span id="today">'+this_weekday_name_array[s]+'</span>';
       }
	else{
		t+='<span id="daysofweek">'+this_weekday_name_array[s]+'</span>';
	}
}
	t+='<span id="daysofweek"></span>';//<span id="today">'+this_date+'</span>';
for (L=0;L<this_weekday;L++){
	L2=L+wkstart;
	if(L2>days_PM) L2=L2-days_PM;
	if(L2==this_date) t+='<span id="today">'+L2+'</span>';
}
t+='<div class="month">'+mn[this_month]+'</div>';
t+='<div class="year">'+this_year+'</div>';
return t;
}