// Seiva Lockscreen Setup //

// Settings - Please change to your liking :



// Clock Related

var Clock = "24h";				// Enter 12h between "" to change to 12h clock, or "24h" for military time.



// Change Language For Complete Lockscreen / Day of the week / Month / Forecast Days / Weather Condition 

var lang = "en";		// fr=French // de=German // sp=Spanish // it=Italian // en=English // nl=Dutch



// Weather Related

var gps = true; 			       // GPS Disabled to save battery.

var locale = 733075;		// Yahoo WOEID Weather code, check http://woeid.rosselliot.co.nz/ and search for your city, copy it's WOEID to this file.  Rotterdam-South Holland-Netherlands- -> 733075 <-

var updateInterval = 30;	// Weather update time - In minutes, save battery by increasing to at least 30minutes.

var tempUnit = "c";		// Change to : C - Celcius or F - Fahrenheit.



// Theme Related - Current icons created by : Andreas-Hellqvist // http://andreas-hellqvist.deviantart.com // Thanks!

var IconSet = "Weather";	    // Icons - You can change this to your own icon set and copy your icons to the Images/*youriconset* directory.