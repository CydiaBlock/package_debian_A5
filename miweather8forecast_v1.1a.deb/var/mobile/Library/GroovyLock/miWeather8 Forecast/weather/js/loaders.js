function getwidgetvalues(name,width,height) {

    wname = name;
    wwidth = width;
    wheight = height;

    loadiwidgets(wname, wwidth, wheight);
}


function loadiwidgets(widget, width, height) {
    var widgetname, objiwidget, savedwidget, name, preparedwidget, container, swipecontain, link, widgetframe, widgetdiv, moverdiv, isLocked;
    widgetname = widget.replace(/\s+/g, '');
    widgetname = widgetname.replace(/[^\w\s]/g, '');



    container = document.getElementById('iwidgetcontainer');
    $('<div id="' + widgetname + '" style="position:absolute;"></div>').appendTo(container);
   
    link = 'weather/'+widget + "/Widget.html";
    widgetframe = document.createElement('iframe');
    widgetframe.frameBorder = 0;
    widgetframe.style.left = "0px";
    widgetframe.style.top = "100px";
    widgetframe.style.position = "absolute";
    widgetframe.style.width = width + "px";
    widgetframe.style.height = height + "px";
    widgetframe.style.backgroundColor = "transparent";
    widgetframe.id = widgetname;
    widgetframe.setAttribute("src", link);
    widgetframe.setAttribute("class", "iwidgetclass");
    document.getElementById('iwidgetcontainer').appendChild(widgetframe);

  
    $("#" + widgetname).addClass(' widget');

   
 
}