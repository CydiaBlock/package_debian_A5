
  if(Curlanguage=="en"){
  var name = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
  var month=["January","February","March","April","May","June","July","August","September","October","November","December"];
  var smonth=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  var sday=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
  }
  else if(Curlanguage=="it"){
  var name = ["Domenica", "Lunedi", "Martedì", "Mercoledì", "Giovedi", "Venerdì", "Sabato"];
  var month=["Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre"];
  var smonth=["Gen","Feb","Mar","Apr","Mag","Giu","Lug","Ago","Set","Ott","Nov","Dic"];
  var sday=["Sun", "Mon", "Mar", "Mer", "Gio", "Ven", "Sat"];
  }
  else if(Curlanguage=="sp"){
  var name = ["Domingo","Lunes","Martes","Miércoles","Jueves","Viernes","Sábado"];
  var month=["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
  var smonth=["Ene","Feb","Mar","Abr","Mayo","Jun","Jul","Aug","Sep","Oct","Nov","Dic"];
  var sday=["Sol","Mon","Mar","Mie","Jue","Vie","Sat"];
  }
  else if(Curlanguage=="de"){
  var name = ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
  var month=["Januari","Februari","Maart","April","Kunnen","Juni","Juli","Augustus","September","Oktober","November","Dezember"];
  var smonth=["Jan", "Feb", "Maa", "Apr", "Kun", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez "];
  var sday=["Son","Mon","Die","Mit","Don","Fre","Sam"];
  }
  else if(Curlanguage=="fr"){
  var name = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
  var month=["Janvie","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"];
  var smonth=["Jan", "Fév", "Mar", "Avr", "Mai", "Jui", "Jui", "Aoû", "Sep", "Oct", "Nov", "Déc"];
  var sday=["Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"];
  }
  else{
  var name = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
  var month=["January","February","March","April","May","June","July","August","September","October","November","December"];
  var smonth=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  var sday=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
  }



