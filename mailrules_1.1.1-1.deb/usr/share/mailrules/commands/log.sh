#!/bin/sh

subject="$1"
senderName="$2"
senderAddress="$3"
recipientAddress="$4"
account="$5"
messageID="$6"

echo "MailRules: [$account:$messageID] New mail from $senderAddress to $recipientAddress: $subject"
