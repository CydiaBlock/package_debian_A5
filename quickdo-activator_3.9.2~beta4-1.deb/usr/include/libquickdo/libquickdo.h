#import <UIKit/UIKit.h>

@interface QDGesture : NSObject<NSCoding> {
@private
	NSString *_name;
	NSString *_mode;
    BOOL _handled;
}
@property (nonatomic, readonly) NSString *name;
@property (nonatomic, readonly) NSString *mode;
@property (nonatomic, getter = isHandled) BOOL handled;
+ (id)gestureWithName:(NSString *)name;
+ (id)gestureWithName:(NSString *)name mode:(NSString *)mode;
- (id)initWithName:(NSString *)name;
- (id)initWithName:(NSString *)name mode:(NSString *)mode;
@end

@protocol QDAction;

@interface LibQuickDo : NSObject

@property (nonatomic, readonly) NSArray *actionNames;
@property (nonatomic, readonly) NSString *uniqueIdentifier;

+ (LibQuickDo *)sharedInstance;
- (void)addAction:(id<QDAction>)action name:(NSString *)actionName;
- (void)removeAction:(NSString *)actionName;

- (void)handleAction:(NSString *)actionName gesture:(QDGesture *)gesture;

- (void)assignGesture:(QDGesture *)gesture toAction:(NSString *)actionName;
- (void)unassignGesture:(QDGesture *)gesture;
- (NSArray *)gesturesAssignedToAction:(NSString *)actionName;

- (NSString *)actionTitle:(NSString *)actionName;
- (NSString *)actionDescription:(NSString *)actionName;
- (UIImage *)actionIcon:(NSString *)actionName;
@end

@protocol QDAction <NSObject>
@optional
- (void)quickdo:(LibQuickDo *)quickdo handleAction:(QDGesture *)gesture;
@end

@interface QDSettingsViewController : UIViewController <UITableViewDataSource, UITableViewDelegate> {
@protected
    UITableView *_tableView;
	NSString *_actionName;
}
@property(nonatomic, retain) NSString *actionName;
@end

@interface QDModeViewController : QDSettingsViewController {
    NSMutableArray *_modes;
}
@end

@interface QDGestureViewController : QDSettingsViewController {
@protected
	NSString *_mode;
    NSArray *_gestureGroups;
	NSArray *_gestures;
}
@property(nonatomic, retain) NSString *mode;
@end

// Gesture Mode
extern NSString * const QDGestureModeAnywhere;
extern NSString * const QDGestureModeSpringBoard;
extern NSString * const QDGestureModeApplication;
extern NSString * const QDGestureModeLockScreen;

// FingerPrint Sensor
extern NSString * const QDGestureFingerPrintSensorPressSingle;
extern NSString * const QDGestureFingerPrintSensorPressDouble;
extern NSString * const QDGestureFingerPrintSensorHold;

// StatusBar
extern NSString * const QDGestureStatusBarSwipeLeft;
extern NSString * const QDGestureStatusBarSwipeRight;
extern NSString * const QDGestureStatusBarSlideInTopLeft;
extern NSString * const QDGestureStatusBarSlideInTop;
extern NSString * const QDGestureStatusBarSlideInTopRight;
extern NSString * const QDGestureStatusBarHoldLeft;
extern NSString * const QDGestureStatusBarHold;
extern NSString * const QDGestureStatusBarHoldRight;
extern NSString * const QDGestureStatusBarTapDoubleLeft;
extern NSString * const QDGestureStatusBarTapDouble;
extern NSString * const QDGestureStatusBarTapDoubleRight;
extern NSString * const QDGestureStatusBarTapSingleLeft;
extern NSString * const QDGestureStatusBarTapSingle;
extern NSString * const QDGestureStatusBarTapSingleRight;

// QuickDoBar
extern NSString * const QDGestureBarSwipeShortLeft;
extern NSString * const QDGestureBarSwipeLongLeft;
extern NSString * const QDGestureBarSwipeShortRight;
extern NSString * const QDGestureBarSwipeLongRight;
extern NSString * const QDGestureBarSwipeLeftUp;
extern NSString * const QDGestureBarSwipeCenterUp;
extern NSString * const QDGestureBarSwipeRightUp;
extern NSString * const QDGestureBarHoldLeft;
extern NSString * const QDGestureBarHoldCenter;
extern NSString * const QDGestureBarHoldRight;
extern NSString * const QDGestureBarDoubleTapLeft;
extern NSString * const QDGestureBarDoubleTapCenter;
extern NSString * const QDGestureBarDoubleTapRight;

// Full Screen Gestures
extern NSString * const QDGestureHomeScreenBlankAreaSingleTap;
extern NSString * const QDGestureFullScreenBlankAreaDoubleTap;
extern NSString * const QDGestureHomeScreenBlankAreaHold;
extern NSString * const QDGestureFullScreenSwipeUp;
extern NSString * const QDGestureFullScreenSwipeDown;

// Motion
extern NSString * const QDGestureMotionShake;

// Date View
extern NSString * const QDGestureLockScreenDateViewSwipeLeft;
extern NSString * const QDGestureLockScreenDateViewSwipeRight;
extern NSString * const QDGestureLockScreenDateViewSwipeUp;
extern NSString * const QDGestureLockScreenDateViewSwipeDown;
extern NSString * const QDGestureLockScreenDateViewDoubleTap;

// Headset
extern NSString * const QDGestureHeadsetConnected;
extern NSString * const QDGestureHeadsetDisconnected;

// Power Connect
extern NSString * const QDGesturePowerConnected;
extern NSString * const QDGesturePowerDisconnected;
extern NSString * const QDGestureWifiConnected;
extern NSString * const QDGestureWifiDisconnected;
extern NSString * const QDGestureBluetoothConnected;
extern NSString * const QDGestureBluetoothDisconnected;
extern NSString * const QDGestureLockStateLocked;
extern NSString * const QDGestureLockStateUnlocked;

// Volume Button
extern NSString * const QDGestureVolumeDownButtonHoldShort;
extern NSString * const QDGestureVolumeUpButtonHoldShort;
extern NSString * const QDGestureVolumeDownButtonPress;
extern NSString * const QDGestureVolumeUpButtonPress;
extern NSString * const QDGestureVolumeHUDViewSingleTap;
extern NSString * const QDGestureVolumeToggleMuteTwice;

// Menu button
extern NSString * const QDGestureMenuPressSingle;
extern NSString * const QDGestureMenuPressDouble;
extern NSString * const QDGestureMenuPressTriple;
extern NSString * const QDGestureMenuHoldShort;

// Lock button
extern NSString * const QDGestureLockHoldShort;
extern NSString * const QDGestureLockPressDouble;
extern NSString * const QDGestureLockPressSingle;

// Slide In
extern NSString * const QDGestureSlideInFromLeft;
extern NSString * const QDGestureSlideInFromRight;

// Slide Out
extern NSString * const QDGestureSlideOutToLeft;
extern NSString * const QDGestureSlideOutToRight;
extern NSString * const QDGestureSlideOutToTopLeft;
extern NSString * const QDGestureSlideOutToTop;
extern NSString * const QDGestureSlideOutToTopRight;
extern NSString * const QDGestureSlideOutToBottomLeft;
extern NSString * const QDGestureSlideOutToBottom;
extern NSString * const QDGestureSlideOutToBottomRight;

// Two fingers
extern NSString * const QDGestureTwoFingerSwipeUp;
extern NSString * const QDGestureTwoFingerSwipeDown;
extern NSString * const QDGestureTwoFingerSwipeLeft;
extern NSString * const QDGestureTwoFingerSwipeRight;
extern NSString * const QDGestureTwoFingerPinch;
extern NSString * const QDGestureTwoFingerSpread;
extern NSString * const QDGestureTwoFingerRotateClockwise;
extern NSString * const QDGestureTwoFingerRotateAnticlockwise;
extern NSString * const QDGestureTwoFingerTapDouble;
extern NSString * const QDGestureTwoFingerHold;

// Three fingers
extern NSString * const QDGestureThreeFingerSwipeLeft;
extern NSString * const QDGestureThreeFingerSwipeRight;
extern NSString * const QDGestureThreeFingerSwipeUp;
extern NSString * const QDGestureThreeFingerSwipeDown;
extern NSString * const QDGestureThreeFingerPinch;
extern NSString * const QDGestureThreeFingerSpread;
extern NSString * const QDGestureThreeFingerRotateClockwise;
extern NSString * const QDGestureThreeFingerRotateAnticlockwise;
extern NSString * const QDGestureThreeFingerTapDouble;
extern NSString * const QDGestureThreeFingerHold;
