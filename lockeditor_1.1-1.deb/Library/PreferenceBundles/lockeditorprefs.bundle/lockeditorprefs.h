#import <Preferences/Preferences.h>
#import <Preferences/PSListController.h>
#import <UIKit/UIKit.h>
#import <Preferences/PSTableCell.h>
#import <Preferences/PSSpecifier.h>
#import <Social/SLComposeViewController.h>
#import <Social/SLServiceTypes.h>

static UIColor *const kTintColor = [UIColor colorWithRed:67.0f/255.0f green:67.0f/255.0f blue:74.0f/255.0f alpha:1.0];

@interface LockEditorListController : PSListController {
	UIWindow *settingsView;
	UIBarButtonItem *composeTweet;
}
@end

@interface LESettingsListController : PSListController {
	UIWindow *settingsView;
	UIBarButtonItem *composeTweet;
}
@end

@interface LELockSettingsListController : PSListController {
}
@end

@interface LESTUSettingsListController : PSListController {
}
@end

@interface LEDevListController : PSListController {
}
@end
