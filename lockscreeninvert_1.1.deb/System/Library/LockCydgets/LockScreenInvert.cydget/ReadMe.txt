                                                                        M~M.    
                                MMM.            MM.                    MM.M     
                      .MM      MMMM           MMMMMM                 IMMMMM     
      MM~             .MNMMM           M        MM             MMM     MM       
     MM MMM.           MM .M=   MM    MM MM.    MM            MM :M,   MM       
    MM. ZMM M.        :MD .MM   MM M. MMMMM  M.+MM .M         MM  MM   MM       
    MM  MM? M         ?MM MM    M$.M  MMMMM N. ~M$.M         .MM  M    MM       
    MM  MMMM          DMMMM.    MMM   MM .MM    MMM+          .MMM    .MM       
     MMM              MM                        ~M.                    MM       
                      MM                                                        
                                                                                
     .      .     .           ..         .   ..               ..    ..    ..    
    MMMMMMMMM.  .MMMMMMMMM   .MMMMMM7   DMMMMM,           MMMMMM   .MMMMMMM.    
    MMMMMMMMM.  MMMMMMMMMM   .MM  MM,   DMMMMM,           MMMMMM  ~MMMMMMM      
    MMMMMMMMMM  MMMMMMMMMM   $M.  ,MM   DMMMMM,           MMMMMM MMMMMMMM       
    MMMMMMMMMM. MMMMMMMMMM  .MMMMMMNM   DMMMMM,           MMMMMMMMMMMMMM        
    MMMMMMMMMMMMMMMMMMMMMM  NM MMMMMMM  DMMMMM,           MMMMMMMMMMMMM.        
    MMMMMMMMMMMMMMMMMMMMMM  MMMMMMMMMM  DMMMMM,           MMMMMMMMMMMI          
    MMMMMMMMMMMMMMMMMMMMMM  MMMMMMMMIM  DMMMMM,           MMMMMMMMMMM.          
    MMMMMMDMMMMMMMM.MMMMMM  MMMMMMMMIM  DMMMMM,           MMMMMMMMMMMM,         
    MMMMMM MMMMMMMM MMMMMM  MMMMMMMMIM  DMMMMM,           MMMMMMMMMMMMM~        
    MMMMMM MMMMMMMM MMMMMM  MMMMMMMMIM  DMMMMM~           MMMMMMMMMMMMMM,       
    MMMMMM  MMMMMM  MMMMMM  MMMMMMMMIM  DMMMMMMMMMMMMMM   MMMMMM  MMMMMMM=      
    MMMMMM  MMMMMM  MMMMMM  MMMMMMMMIM  DMMMMMMMMMMMMMM.  MMMMMM   MMMMMMM$     
    MMMMMM  MMMMM   MMMMMM  MMZ77777MM. DMMMMMMMMMMMMMM.  MMMMMM    MMMMMMMN    
     MMMM   ,DMM=   7MMMM.  .?MMMMMMM    MMMMMMMMMMMMM    =MMMM.    .$MMMMM.    

Thank you for purchasing this LockScreen theme, "LockScreen Invert".
Whilst we can not prevent you stealing this code, redistributing it or giving
it to your mates. We would appreciate you actually purchased it from the Cydia
store. This way, we can devote time to supporting, upgrading and adding
additional features. If you have stolen this script, please either purchase
it from the Cydia store or buy us a coffee. PayPal: payment@apintofmilk.com.

This is version 1.1
Support at: http://themes.apintofmilk.com/support/

****************************************
Change Log

Version 1.1
Added 5 day forecast.
Bug Fix for iPhone 4 screen size.

Version 1.0
Initial Release.
****************************************