/*
  _____ ____  ___ ___  ____  _        ___       _____   ___ ______  ______  ____  ____    ____  _____
 / ___/|    ||   |   ||    \| |      /  _]     / ___/  /  _]      ||      ||    ||    \  /    |/ ___/
(   \_  |  | | _   _ ||  o  ) |     /  [_     (   \_  /  [_|      ||      | |  | |  _  ||   __(   \_
 \__  | |  | |  \_/  ||   _/| |___ |    _]     \__  ||    _]_|  |_||_|  |_| |  | |  |  ||  |  |\__  |
 /  \ | |  | |   |   ||  |  |     ||   [_      /  \ ||   [_  |  |    |  |   |  | |  |  ||  |_ |/  \ |
 \    | |  | |   |   ||  |  |     ||     |     \    ||     | |  |    |  |   |  | |  |  ||     |\    |
  \___||____||___|___||__|  |_____||_____|      \___||_____| |__|    |__|  |____||__|__||___,_| \___|
Creates iOS style toggles. Must be used with sset.css.
Example: sset.create('TwentyFour','twentyfour','blue');
Website: http://junesiphone.com
Creator: JunesiPhone
 */
(function () {
    'use strict';
    var sset = {
        save: function (el, value) {
            localStorage.setItem(value, el.checked);
            setTimeout(function () {
                location.reload();
            }, 1000);
        },
        check: function (save) {
            var checked;
            if (localStorage.getItem(save)) {
                if (localStorage.getItem(save) === "true") {
                    checked = "checked";
                } else {
                    checked = "";
                }
            } else {
                checked = "";
            }
            return checked;
        },
        colors: function (color) {
            var css, sectionDiv;
            css = "input[type='checkbox'].color.sswitch:checked + div {background-color: " + color + ";border: 1px solid rgba(0, 0, 0,1);box-shadow: inset 0 0 0 10px " + color + "}";
            sectionDiv = document.createElement('div');
            sectionDiv.innerHTML = '<p>foo</p><style>' + css + '</style>';
            document.getElementsByTagName('head')[0].appendChild(sectionDiv.childNodes[1]);
        },
        create: function (label, save, color) {
            var elemDiv;
            if (!document.querySelector('.sset')) {
                elemDiv = document.createElement('section');
                elemDiv.className = 'sset';
                document.body.appendChild(elemDiv);
            }
            document.querySelector('.sset').innerHTML += "<label><input onchange='sset.save(this,\"" + save + "\")' type='checkbox' class='sswitch color bigswitch' " + this.check(save) + " /><div><div></div></div><p>" + label + "</p>";
            this.colors(color);
        }
    };
    window.sset = sset;
}());