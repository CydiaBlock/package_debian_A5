var iOS = /(iPad|iPhone|iPod)/g.test(navigator.userAgent);
(function weather() {
    'use strict';
    var celsius, weatherInterval, cvtF, cvtK, cvtS, loadWeather, init;
    celsius = (localStorage.celsius) ? JSON.parse(localStorage.celsius) : false;            // *** Set Celsius ***
    weatherInterval = 60000 * 15; //                            *** set update interval 15 minutes ***
    cvtF = function (temp) { //convert to fareinheit
        if (temp === "--") {
            return "--";
        }
        return Math.round(temp * 1.8 + 32);
    };
    cvtK = function (wind) { //convert from mph to kph
        var conversion, kp;
        conversion = 1.609344;
        kp = wind * conversion;
        kp = Math.round(kp * 100) / 100;
        kp = Math.round(kp);
        return kp;
    };
    cvtS = function (time) { //convert sunrise time to 12hr
        var timecut, timeE, cvtt;
        if (String(time).length > 3) {
            timecut = String(time).slice(0, 2);
            timeE = String(time).slice(2, 4);
        } else {
            timeE = String(time).slice(1, 3);
            timecut = String(time).slice(0, 1);
        }
        if (timecut === "00") { //if 00 change to 12
            return 12;
        }
        cvtt = (timecut > 12) ? timecut - 12 : timecut;
        return cvtt + ":" + timeE;
    };
    loadWeather = function () {
        var WC;
        WC = getWeather(); // contains all weather elements do DOM changes here.
        document.getElementById('weather').innerHTML = WC.name + "<img id='icon' src='./svg/" + WC.conditionCode + ".svg'/>" + (celsius ? WC.temperature + "&deg;" : cvtF(WC.temperature) + "&deg;");
        if (iOS) { showSVG('.weathericon', true); }
    };
    init = function () {
        var currentTime;
        currentTime = new Date().getTime(); //current time
        if (currentTime > Number(localStorage.getItem('lastUpdate'))) { //compare between last update
            loadWeather(); // load cached weather while updating weather
            updateWeather(); //update gps location and get new weather
            localStorage.setItem('lastUpdate', currentTime + weatherInterval); //save new refresh time
            setTimeout(function () {
                loadWeather(); // load weather that contains update
            }, 2500); //delay to make sure gps returns.
        } else {
            loadWeather();
        }
    };
    setTimeout(function () {weather(); }, weatherInterval);
    return init();
}());



if (window.innerWidth === 375) {
    document.querySelector("meta[name=viewport]").setAttribute('content', 'width=device-width, initial-scale=1.18, maximum-scale=1.18, user-scalable=0');
} else if (window.innerWidth === 414) {
    document.querySelector("meta[name=viewport]").setAttribute('content', 'width=device-width, initial-scale=1.3, maximum-scale=1.3, user-scalable=0');
}



